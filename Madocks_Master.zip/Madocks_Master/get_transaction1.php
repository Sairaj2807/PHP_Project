<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit();
}

require 'dbConnect.php';

$user_id = $_SESSION['user']['id'];

try {
    $stmt = $pdo->prepare("SELECT * FROM records WHERE user_id = :user_id ORDER BY transaction_time DESC");
    $stmt->execute(['user_id' => $user_id]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($records);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $e->getMessage()]);
}
?>
