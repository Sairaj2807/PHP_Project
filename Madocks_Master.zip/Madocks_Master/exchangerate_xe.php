<?php
header("Content-Type: application/json");

$url = "https://www.xe.com/api/protected/midmarket-converter/";
$auth = "Basic bG9kZXN0YXI6cHVnc25heA=="; // Replace with your actual API auth key

$filename = 'xe_rates.json';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Accept: application/json",
    "Authorization: $auth"
]);

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

// Define the list of currency codes you're interested in
$currencies = ["USD", "SGD", "THB", "MYR", "INR", "JPY", "EUR", "HKD", "CNY", "RMB", "AUD", "GBP", "PHP", "USDT"];

$exchangeRates = [];

foreach ($currencies as $code) {
    $exchangeRates["exchangeRate_$code"] = $data['rates'][$code] ?? 1;
}

// Save the exchange rates to JSON file
file_put_contents($filename, json_encode($exchangeRates, JSON_PRETTY_PRINT));

// Output the exchange rates as JSON
echo json_encode($exchangeRates);
?>
