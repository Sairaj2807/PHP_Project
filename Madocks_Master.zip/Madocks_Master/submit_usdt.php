<?php
require 'dbConnect.php';
require 'vendor/autoload.php'; // Ensure PHPMailer is installed via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


use Twilio\Rest\Client;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Debugging - Check if reference code is received
        error_log("Reference Code Received: " . $_POST['referenceCode']);

        // Prepare values
        $apa_employee = $_POST['apaEmployee'];
        $full_name = $_POST['fullName'];
        $dob = date('Y-m-d', strtotime($_POST['dob']));
        $nationality = $_POST['nationality'];
        $address1 = $_POST['address1'];
        $address2 = $_POST['address2'] ?? null;
        $address3 = $_POST['address3'] ?? null;
        $postcode = $_POST['postcode'];
        $mobile = $_POST['mobile'];
        $passport_id = $_POST['passportId'];
        $country = $_POST['country'];
        $occupation = $_POST['occupation'];
        $email = $_POST['email'];
        $currencies = $_POST['currencies'];
        $annual_volume = $_POST['annualVolume'];
        $account_reason = $_POST['accountReason'];
        $reference_code = $_POST['referenceCode'] ?? ''; // Ensure it's set

        if (empty($reference_code)) {
            echo json_encode(["status" => "error", "message" => "Reference Code is missing!"]);
            exit;
        }

        // File uploads
        $uploadDir = "uploads/";
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $source_wealth = $_FILES['sourceWealth']['name'] ? $uploadDir . basename($_FILES['sourceWealth']['name']) : null;
        $proof_identity = $_FILES['proofIdentity']['name'] ? $uploadDir . basename($_FILES['proofIdentity']['name']) : null;
        $proof_address = $_FILES['proofAddress']['name'] ? $uploadDir . basename($_FILES['proofAddress']['name']) : null;
        $source_funds = $_FILES['sourceFunds']['name'] ? $uploadDir . basename($_FILES['sourceFunds']['name']) : null;

        move_uploaded_file($_FILES['sourceWealth']['tmp_name'], $source_wealth);
        move_uploaded_file($_FILES['proofIdentity']['tmp_name'], $proof_identity);
        move_uploaded_file($_FILES['proofAddress']['tmp_name'], $proof_address);
        move_uploaded_file($_FILES['sourceFunds']['tmp_name'], $source_funds);

        // Insert into database
        $stmt = $pdo->prepare("INSERT INTO info 
            (apa_employee, full_name, dob, nationality, address1, address2, address3, postcode, mobile, passport_id, country, occupation, email, currencies, source_wealth, proof_identity, proof_address, source_funds, annual_volume, account_reason, reference_code) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->execute([
            $apa_employee,
            $full_name,
            $dob,
            $nationality,
            $address1,
            $address2,
            $address3,
            $postcode,
            $mobile,
            $passport_id,
            $country,
            $occupation,
            $email,
            $currencies,
            $source_wealth,
            $proof_identity,
            $proof_address,
            $source_funds,
            $annual_volume,
            $account_reason,
            $reference_code
        ]);

        // Send email
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge'; // Use App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com');

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'New USDT Onboarding Submission';
        $mail->Body = "
            <h3>New Usdt Onboarding Submission Details</h3>
            <p><strong>Reference Code:</strong> $reference_code</p>
            <p><strong>APA Employee:</strong> $apa_employee </p>
            <p><strong>Name:</strong> $full_name</p>
            <p><strong>DOB:</strong> $dob</p>
            <p><strong>Nationality:</strong> $nationality</p>
            <p><strong>Address:</strong> $address1 $address2 $address3 </p>
            <p><strong>Post Code:</strong> $postcode </p>
            <p><strong>Mobile:</strong>$mobile</p>
            <p><strong>Passport ID:</strong>$passport_id</p>
            <p><strong>Country :</strong>$country</p>
            <p><strong>Occupation: </strong> $occupation </p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Currencies:</strong> $currencies </p>
            <p><strong>Annual Volume :</strong> $annual_volume </p>
            <p><strong>Account Reason:</strong> $account_reason </p>

            <p>below attached documnets are as Follows 1. Source of Wealth 2. Proof of Identity 3. Proof of address 4. Source Funds 
            
            
        ";

        // Attach files if available
        if ($source_wealth)
            $mail->addAttachment($source_wealth);
        if ($proof_identity)
            $mail->addAttachment($proof_identity);
        if ($proof_address)
            $mail->addAttachment($proof_address);
        if ($source_funds)
            $mail->addAttachment($source_funds);

        if ($mail->send()) {
            echo json_encode(["status" => "success", "message" => "Data stored and email sent successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Email sending failed"]);
        }

        sendWhatsAppMessagetoapa_kyc();
        
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}

function sendWhatsAppMessagetoapa_kyc()
        {
            $sid = "AC123ed9e921a2f70fa480229231503368";
            $token = "5e8163958ae2e29d3757b261f62b072b";
            $twilio = new Client($sid, $token);

            $body = "User has submited Kyc please check mail ";

            $message = $twilio->messages->create("whatsapp:+917588345894", [
                "from" => "whatsapp:+14155238886",
                "body" => $body
            ]);
        }


/*<?php
require 'dbConnect.php';
require 'vendor/autoload.php'; // Ensure PHPMailer is installed via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Prepare values
        $apa_employee = $_POST['apaEmployee'];
        $full_name = $_POST['fullName'];
        $dob = date('Y-m-d', strtotime($_POST['dob']));
        $nationality = $_POST['nationality'];
        $address1 = $_POST['address1'];
        $address2 = $_POST['address2'] ?? null;
        $address3 = $_POST['address3'] ?? null;
        $postcode = $_POST['postcode'];
        $mobile = $_POST['mobile'];
        $passport_id = $_POST['passportId'];
        $country = $_POST['country'];
        $occupation = $_POST['occupation'];
        $email = $_POST['email'];
        $currencies = $_POST['currencies'];
        $annual_volume = $_POST['annualVolume'];
        $account_reason = $_POST['accountReason'];
        $reference_code = $_POST['referenceCode']; // Example, dynamically generate if needed

        // File uploads
        $uploadDir = "uploads/";
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $source_wealth = $_FILES['sourceWealth']['name'] ? $uploadDir . basename($_FILES['sourceWealth']['name']) : null;
        $proof_identity = $_FILES['proofIdentity']['name'] ? $uploadDir . basename($_FILES['proofIdentity']['name']) : null;
        $proof_address = $_FILES['proofAddress']['name'] ? $uploadDir . basename($_FILES['proofAddress']['name']) : null;
        $source_funds = $_FILES['sourceFunds']['name'] ? $uploadDir . basename($_FILES['sourceFunds']['name']) : null;

        move_uploaded_file($_FILES['sourceWealth']['tmp_name'], $source_wealth);
        move_uploaded_file($_FILES['proofIdentity']['tmp_name'], $proof_identity);
        move_uploaded_file($_FILES['proofAddress']['tmp_name'], $proof_address);
        move_uploaded_file($_FILES['sourceFunds']['tmp_name'], $source_funds);

        // Insert into database
        $stmt = $pdo->prepare("INSERT INTO info 
            (apa_employee, full_name, dob, nationality, address1, address2, address3, postcode, mobile, passport_id, country, occupation, email, currencies, source_wealth, proof_identity, proof_address, source_funds, annual_volume, account_reason, reference_code) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->execute([
            $apa_employee, $full_name, $dob, $nationality, $address1, $address2, $address3, $postcode, $mobile, $passport_id, $country, $occupation, $email, $currencies,
            $source_wealth, $proof_identity, $proof_address, $source_funds, $annual_volume, $account_reason, $reference_code
        ]);

        // Send email
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge'; // Use App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com');

        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'New USDT Onboarding Submission';
        $mail->Body = "
            <h3>New Submission Details</h3>
            <p><strong>Name:</strong> $full_name</p>
            <p><strong>DOB:</strong> $dob</p>
            <p><strong>Nationality:</strong> $nationality</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Occupation:</strong> $occupation</p>
            <p><strong>Reference Code:</strong> $reference_code</p>
        ";

        // Attach files if available
        if ($source_wealth) $mail->addAttachment($source_wealth);
        if ($proof_identity) $mail->addAttachment($proof_identity);
        if ($proof_address) $mail->addAttachment($proof_address);
        if ($source_funds) $mail->addAttachment($source_funds);

        if ($mail->send()) {
            echo json_encode(["status" => "success", "message" => "Data stored and email sent successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Email sending failed"]);
        }
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}
?>*/

?>