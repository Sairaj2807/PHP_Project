<?php
include 'dbConnect.php';
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

$userId = $_SESSION['user']['id']; // or ['user_id'] depending on your database column

$stmt = $pdo->prepare("SELECT * FROM kyc WHERE user_id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($user ?: ["error" => "No KYC record found"]);
?>
