<?php
session_start();
require_once __DIR__ . '/vendor/autoload.php';
require 'dbConnect.php'; // your PDO connection
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Twilio\Rest\Client;

if (!isset($_SESSION['user'])) {
    echo json_encode(["message" => "User not authenticated."]);
    exit;
}


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$user = $_SESSION['user'];

// Ensure POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        // Handle Signature
        $signatureData = $_POST['signature'] ?? '';
        $signaturePath = null;

        $selected_currencies = isset($_POST['currencies']) ? $_POST['currencies'] : [];
        $currencies_string = implode(', ', $selected_currencies);
        $currencies_json = json_encode($selected_currencies);


        // e.g. "USD, EUR, INR"

        $country_code = $_POST['countryCode']; // e.g. "+91"
        $mobile = $_POST['mobile'];            // e.g. "9876543210"
        $full_mobile = $country_code . $mobile;


        if ($signatureData) {
            $signatureData = str_replace('data:image/png;base64,', '', $signatureData);
            $signatureData = str_replace(' ', '+', $signatureData);
            $signatureImage = base64_decode($signatureData);
            $signaturePath = tempnam(sys_get_temp_dir(), 'sig_') . '.png';
            file_put_contents($signaturePath, $signatureImage);
        }

        // Prepare PDF
        $pdf = new \TCPDF();
        $pdf->SetMargins(15, 15, 15);
        $pdf->AddPage();

        $html = "<h2>KYC Submission</h2>
        <h2>Confirmation and Submission</h2>
                        <p>By submitting this form to the APA Group, you confirm and agree:</p>
                        <ol>
                            <li>This Individual Application form, together with the Terms and Conditions (the “Terms”) and the Supplemental Terms and Conditions (as applicable) (the “Supplemental Terms”), comprise the entire agreement between the Company and the APA Group related to the Services (the “Agreement”). This Agreement is entered into by and between the Individual and APA Canada Tech Limited, a company incorporated under the laws of the Province of Alberta, Canada (Individual Access Number 2025006178) with its registered address of 428-1001 1st Street SE, Calgary, Alberta, T2G 5G3, Canada, which is registered as an MSB in Canada with the Financial Transactions and Reports Analysis Centre of Canada (Canadian MSB Registration Number M23328908) (“APA”). You acknowledge that APA may engage other companies within the APA Group to perform services under this agreement. For the purposes of this Agreement, the “APA Group” shall refer to APA and its’ affiliates, including: (i) Atlantic Partners Asia (SG) Pte Limited, a company incorporated in Singapore (Company Number 201841045G) with its registered office at 7A Stanley Street, Singapore 068726 (Major Payment Institute License No. 20200516), (ii) Atlantic Partners Asia PS Limited, a company incorporated in Hong Kong SAR (Company Number 2816539) with its registered office at Flat/RM 2005 20/F Kinwick Centre 31 Hollywood Road Mid-Levels Central, Hong Kong, which holds an MSO License in Hong Kong (License No. 20-12-02993), (iii) Atlantic Partners Asia (MY) SDN BHD, a company incorporated in Malaysia (Company Number 202201040529 (1486226X) with its registered address at Unit 25-13, Q Sentral, Jalan Stesen Sentral 2, KL Sentral, 50470 W.P. Kuala Lumpur, Malaysia, (iv) Atlantic Partners Asia Management (Cayman) Limited, a company incorporated in the Cayman Islands (Company Number 270943) with its registered address at Floor 4, Willow House, Cricket Square, Grand Cayman KYl-9010, Cayman Islands, (v) Atlantic Partners Asia Canada Limited, a company incorporated under the laws of the Province of Ontario, Canada (Ontario Corporation Number 1000612208), with a registered address of 120 Adelaide Street West, Suite 2500, Toronto, Ontario, M5H 1T1, Canada (Canadian MSB Registration Number M23484752), (vi) Redbanx Limited, a company incorporated in England and Wales (Company Number 10452111) with its registered address at 11 Woodford Avenue, Ilford, England, IG2 6UF, which holds a UK EMI License (License No. 900897), (vii) Atlantic Partners Africa (Pty) Ltd, a company incorporated in South Africa (Company Number K2019340083) with its registered address at Office 09, 1st Floor, 35 Ferguson, 35 Ferguson Road, Illovo, Johannesburg, 2196, Gauteng, South Africa, which holds an FSP (Financial Services Provider) Category II (Discretionary) License (License No: 36823), and (viii) Atlantic Partners Asia PS Pty Ltd, a company incorporated in New South Wales (Company Number 633 838 481) with its registered address at 10.02, Level 10, 109 Pitt Street, Sydney, NSW, 2000, Australia.</li>

                            <li>References in this Agreement to “you”, “your”, “yours” and “Client” are to you, the customer of APA.</li>

                            <li>In this Agreement, you and the APA Group are referred to jointly as the Parties and each a Party in the singular.</li>

                            <li>Notwithstanding any other authorization or instruction provided by you to the APA Group, the APA Group is authorized to act on the authorizations or instructions provided in this form without further checks, even if the authorizations or instructions may contradict any other instructions provided by you to the APA Group.</li>

                            <li>You have read and understood the APA Group’s prevailing Terms and Supplemental Terms (as applicable), a copy of which has been provided to you, and you agree to be bound by all the terms therein and any amendments or variation thereof. You further agree and acknowledge that there are other terms and conditions and agreement(s) intended or expressed to govern the use of other relevant products and services offered by APA and you confirm your agreement and acceptance of the same, including but not necessarily limited to the Supplemental Terms (as applicable). We reserve the right to amend, remove, or add to this Agreement, the Terms and Supplemental Terms (as applicable) at any time, and from time to time, in our sole discretion. Your use of any product or service after the posting of modifications to this Agreement, the Terms and Supplemental Terms (as applicable) constitutes your acceptance of this Agreement, as modified. A copy of APA’s prevailing Terms and Supplemental Terms (as applicable) and can be obtained upon request.</li>

                            <li>You may provide personal information to APA in connection with your establishing and maintaining your relationship with the APA Group. You confirm that all information provided, and documents submitted by you are true, complete and accurate and that you have consent and authority to share such information with us. When providing any personal information to the APA Group, you confirm that you are lawfully providing the data for the APA Group to use and disclose for the purposes of:
 
                                <ul>
            
                                <li>providing products or services to you;</li>
            
                                <li>managing the operational, administrative and risk management requirements</li>
            
                                <li>meeting the operational, administrative and risk management requirements of the APA Group; and</li>
            
                                <li>complying with any requirement, as APA Group reasonably deems necessary, under any law or of any court, government authority or regulator</li>
        
                                </ul>
    
                                </li>

    
                                <li>All of your personal information will be collected by us in accordance [with the above and not for any other purpose without your express consent /OR/ the Privacy Policy at [link]. The Privacy Policy is incorporated in its entirety into and should be read in conjunction with this Agreement. We reserve the right to update the Privacy Policy at any time, and from time to time, in our sole discretion.</li>

    
                                <li>This Agreement represents an agreement made by and between you and the APA Group and has the binding effect of a legal contract and should be read carefully and in its entirety, prior to using any product or service. Your access to, and use of, any product or service is conditional upon your acceptance of, and compliance with, this Agreement.</li>

                                </ol>


                                <p>I/we have read and understood APA’s prevailing Terms and Condition and agree to be bound by all the terms therein and any amendments or variation thereof. I/we further agree and acknowledge that there are other terms and conditions and agreement(s) intended or expressed to govern the use of other relevant products and services offered by APA and I/we confirm my/our agreement and acceptance of the same. Copies of APA’s prevailing terms and conditions can be obtained upon request.</p>


                                <p>I/we may provide personal data to APA in connection with me/us establishing and maintaining my/our relationship with the APA. I/We confirm that all information provided, and documents submitted by me/us are true, complete and accurate. When providing any personal data to APA, I/we confirm that I am/we are lawfully providing the data for APA to use and disclose for the purposes of:</p>

                                <ul>
    
                                <li>providing products or services to me/us;</li>

                                </ul>";

        $fields = [
            'Reference Code' => $_POST['referenceCode'],

            'Name' => $_POST['fullName'],
            'DOB' => $_POST['dob'],
            'Nationality' => $_POST['nationality'],
            'Address' => $_POST['address1'] . ' ' . $_POST['address2'] . ' ' . $_POST['address3'],
            'Postcode' => $_POST['postcode'],
            'Mobile' => $full_mobile,
            'Passport ID' => $_POST['passportId'],
            'Country' => $_POST['country'],
            'Occupation' => $_POST['occupation'],
            'Email' => $_POST['email'],
            'currencies' => $currencies_json,
            'Annual Volume' => $_POST['annualVolume'],
            'Account Reason' => $_POST['accountReason'],

            'date' => $_POST['date']
        ];
        foreach ($fields as $label => $value) {
            $html .= "<p><strong>$label:</strong> $value</p>";
        }

        $pdf->writeHTML($html, true, false, true, false, '');

        if ($signaturePath) {
            $pdf->Ln(10);
            $pdf->Image($signaturePath, 15, $pdf->GetY(), 50, 20, 'PNG');
            unlink($signaturePath);
        }

        // Save PDF
        $pdfDir = __DIR__ . '/kyc_pdfs/';
        if (!is_dir($pdfDir))
            mkdir($pdfDir, 0777, true);
        $pdfFileName = 'kyc_' . $_POST['referenceCode'] . '.pdf';
        $pdfFilePath = $pdfDir . $pdfFileName;
        $pdf->Output($pdfFilePath, 'F');

        // === Save to DB ===
        $uploadDir = "uploads/";
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Handle file uploads
        $source_wealth = $_FILES['sourceWealth']['name'] ? $uploadDir . basename($_FILES['sourceWealth']['name']) : null;
        $proof_identity = $_FILES['proofIdentity']['name'] ? $uploadDir . basename($_FILES['proofIdentity']['name']) : null;
        $proof_address = $_FILES['proofAddress']['name'] ? $uploadDir . basename($_FILES['proofAddress']['name']) : null;
        $source_funds = $_FILES['sourceFunds']['name'] ? $uploadDir . basename($_FILES['sourceFunds']['name']) : null;

        move_uploaded_file($_FILES['sourceWealth']['tmp_name'], $source_wealth);
        move_uploaded_file($_FILES['proofIdentity']['tmp_name'], $proof_identity);
        move_uploaded_file($_FILES['proofAddress']['tmp_name'], $proof_address);
        move_uploaded_file($_FILES['sourceFunds']['tmp_name'], $source_funds);

        // Insert the data into the database
        $stmt = $pdo->prepare("INSERT INTO kyc (user_id, apa_employee, full_name, dob, nationality, address1, address2, address3, postcode, mobile, passport_id, country, occupation, email, currencies, source_wealth, proof_identity, proof_address, source_funds, annual_volume, account_reason, date , reference_code, status) 
            VALUES (:user_id, :apa_employee, :full_name, :dob, :nationality, :address1, :address2, :address3, :postcode, :mobile, :passport_id, :country, :occupation, :email, :currencies, :source_wealth, :proof_identity, :proof_address, :source_funds, :annual_volume, :account_reason, :date , :reference_code, 'pending')");

        $stmt->execute([
            ':user_id' => $user['id'],
            ':apa_employee' => $_POST['apaEmployee'],
            ':full_name' => $_POST['fullName'],
            ':dob' => $_POST['dob'],
            ':nationality' => $_POST['nationality'],
            ':address1' => $_POST['address1'],
            ':address2' => $_POST['address2'],
            ':address3' => $_POST['address3'],
            ':postcode' => $_POST['postcode'],
            ':mobile' => $full_mobile,
            ':passport_id' => $_POST['passportId'],
            ':country' => $_POST['country'],
            ':occupation' => $_POST['occupation'],
            ':email' => $_POST['email'],
            ':currencies' => $currencies_json,
            ':source_wealth' => $source_wealth,
            ':proof_identity' => $proof_identity,
            ':proof_address' => $proof_address,
            ':source_funds' => $source_funds,
            ':annual_volume' => $_POST['annualVolume'],
            ':account_reason' => $_POST['accountReason'],
            ':date' => $_POST['date'],
            ':reference_code' => $_POST['referenceCode']
        ]);

        // Update the status to "processing"
        $updateStmt = $pdo->prepare("UPDATE kyc SET status = 'processing' WHERE reference_code = :reference_code");
        $updateStmt->execute([':reference_code' => $_POST['referenceCode']]);


        // === Email ===
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge'; // app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com');
        //$mail->addAddress('harveyong.wv@gmail.com');
        //$mail->addAddress('Jeremy.zhou@atlanticpartnersasia.com');
        //$mail->addAddress('harvey@madocks.ai');
        //$mail->addAddress('rahul@madocks.ai');

        $mail->Subject = 'New USDT Onboarding Submission';
        $mail->Body = 'Please find the attached KYC submission.';
        $mail->addAttachment($pdfFilePath);
        if ($source_wealth)
            $mail->addAttachment($source_wealth);
        if ($proof_identity)
            $mail->addAttachment($proof_identity);
        if ($proof_address)
            $mail->addAttachment($proof_address);
        if ($source_funds)
            $mail->addAttachment($source_funds);

        $mail->send();
        //sendWhatsAppMessagetoapa_kyc($_POST['referenceCode']);


        echo json_encode(["status" => "success", "message" => "KYC submitted, PDF generated and emailed."]);

        // === WhatsApp if needed ===


    } catch (Exception $e) {
        echo json_encode([
            "status" => "error",
            "message" => "An error occurred during submission.",
            "error" => $e->getMessage()
        ]);
    }


}
function sendWhatsAppMessagetoapa_kyc($referenceCode)
{
    $sid = "AC9190bc9fbd44a7714951db78b5e902f8";
    $token = "fef74e8a8617e37530a3891c47800e30";
    $twilio = new Client($sid, $token);

    $body = "User with Reference Code: $referenceCode has submitted KYC. Please check mail.";

    $twilio->messages->create("whatsapp:+639398014213", [
        "from" => "whatsapp:+14155238886",
        "body" => $body
    ]);
}



/*session_start();
require_once __DIR__ . '/vendor/autoload.php';
require 'dbConnect.php'; // your PDO connection
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Twilio\Rest\Client;

if (!isset($_SESSION['user'])) {
    echo json_encode(["message" => "User not authenticated."]);
    exit;
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$user = $_SESSION['user'];

// Ensure POST request
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        // Handle Signature
        $signatureData = $_POST['signature'] ?? '';
        $signaturePath = null;

        $selected_currencies = isset($_POST['currencies']) ? $_POST['currencies'] : [];
        $currencies_string = implode(', ', $selected_currencies);
        $currencies_json = json_encode($selected_currencies);

        $country_code = $_POST['countryCode'];
        $mobile = $_POST['mobile'];
        $full_mobile = $country_code . $mobile;

        if ($signatureData) {
            $signatureData = str_replace('data:image/png;base64,', '', $signatureData);
            $signatureData = str_replace(' ', '+', $signatureData);
            $signatureImage = base64_decode($signatureData);
            $signaturePath = tempnam(sys_get_temp_dir(), 'sig_') . '.png';
            file_put_contents($signaturePath, $signatureImage);
        }

        $pdf = new \TCPDF();
        $pdf->SetMargins(15, 15, 15);
        $pdf->AddPage();
        $html = "<h2>KYC Submission</h2>";
        $fields = [
            'Reference Code' => $_POST['referenceCode'],
            'Name' => $_POST['fullName'],
            'Mobile' => $full_mobile
        ];
        foreach ($fields as $label => $value) {
            $html .= "<p><strong>$label:</strong> $value</p>";
        }
        $pdf->writeHTML($html, true, false, true, false, '');

        if ($signaturePath) {
            $pdf->Ln(10);
            $pdf->Image($signaturePath, 15, $pdf->GetY(), 50, 20, 'PNG');
            unlink($signaturePath);
        }

        $pdfDir = __DIR__ . '/kyc_pdfs/';
        if (!is_dir($pdfDir)) mkdir($pdfDir, 0777, true);
        $pdfFileName = 'kyc_' . $_POST['referenceCode'] . '.pdf';
        $pdfFilePath = $pdfDir . $pdfFileName;
        $pdf->Output($pdfFilePath, 'F');

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com');
        $mail->Subject = 'New USDT Onboarding Submission';
        $mail->Body = 'Please find the attached KYC submission.';
        $mail->addAttachment($pdfFilePath);

        $mail->send();

        sendWhatsAppMessagetoapa_kyc($_POST['referenceCode']);

        echo json_encode(["status" => "success", "message" => "KYC submitted, PDF generated, emailed, and WhatsApp notification sent."]);

    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "An error occurred.", "error" => $e->getMessage()]);
    }
}

function sendWhatsAppMessagetoapa_kyc($referenceCode)
{
    $sid = "AC123ed9e921a2f70fa480229231503368";
    $token = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $body = "User with Reference Code: $referenceCode has submitted KYC. Please check mail.";

    $twilio->messages->create("whatsapp:+917588345894", [
        "from" => "whatsapp:+14155238886",
        "body" => $body
    ]);
} */
?>