<?php
session_start();
require_once __DIR__ . '/vendor/autoload.php';
require 'dbConnect.php'; // Your PDO connection

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Twilio\Rest\Client;

// Check session user
if (!isset($_SESSION['user'])) {
    echo json_encode(["message" => "User not authenticated."]);
    exit;
}

$user = $_SESSION['user'];
$user_id = $user['id'];
$user_name = $user['name'] ?? 'Unknown User';

// Decode JSON input
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || empty($data['content']) || empty($data['signature'])) {
    echo "Invalid data!";
    exit;
}

$content = $data['content'];
$signatureData = $data['signature'];

// Decode and save signature
$signatureData = str_replace('data:image/png;base64,', '', $signatureData);
$signatureData = str_replace(' ', '+', $signatureData);
$signatureImage = base64_decode($signatureData);
$signatureFile = tempnam(sys_get_temp_dir(), 'sig_') . '.png';
file_put_contents($signatureFile, $signatureImage);

// Generate PDF
$pdf = new TCPDF();
$pdf->SetMargins(15, 15, 15);
$pdf->AddPage();
$pdf->writeHTML($content, true, false, true, false, '');
$pdf->Ln(10);
$pdf->Image($signatureFile, 15, $pdf->GetY(), 50, 20, 'PNG');
unlink($signatureFile); // Cleanup

// Save PDF
$outputDir = __DIR__ . '/agreements/';
if (!is_dir($outputDir)) {
    mkdir($outputDir, 0777, true);
}
$filename = 'liquidity_agreement_' . time() . '.pdf';
$filePath = $outputDir . $filename;
$pdf->Output($filePath, 'F');

// Save to database
try {
    $stmt = $pdo->prepare("INSERT INTO liquidity_agreements (user_id, agreement_file, status, uploaded_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$user_id, $filename, 'processing']);
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => "DB Error: " . $e->getMessage()]);
    exit;
}

// Send Email
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'madocks.ai@gmail.com'; // Your email
    $mail->Password = 'uexurwwgwuotfcge';     // Your App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
    $mail->addAddress('sdbangar2807@gmail.com');
    //$mail->addAddress('harveyong.wv@gmail.com'); // Replace with actual recipient
    $mail->addAttachment($filePath, $filename);

    $mail->isHTML(true);
    $mail->Subject = 'New Liquidity Agreement Submitted';
    $mail->Body = "
        <h3>New Liquidity Agreement Submitted</h3>
        <p><strong>User:</strong> {$user_name} (ID: {$user_id})</p>
        <p>Please find the agreement attached.</p>
    ";

    $mail->send();

    sendWhatsAppMessagetoapa_kyc();
} catch (Exception $e) {
    echo json_encode(["success" => false, "error" => "Mailer Error: " . $mail->ErrorInfo]);
    exit;
}

// Final Response
echo json_encode([
    "success" => true,
    "message" => "Agreement submitted and emailed successfully.",
    "file" => "agreements/" . $filename
]);

function sendWhatsAppMessagetoapa_kyc()
        {
            $sid = "AC9190bc9fbd44a7714951db78b5e902f8";
            $token = "fef74e8a8617e37530a3891c47800e30";
            $twilio = new Client($sid, $token);

            $body = "User has submited New Liquidity Agrement  ";

            $message = $twilio->messages->create("whatsapp:+639398014213", [
                "from" => "whatsapp:+14155238886",
                "body" => $body
            ]);
        }
