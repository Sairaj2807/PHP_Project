<?php
session_start();
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: new_index.php");
    exit();
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy & Sell USDT</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <link rel="manifest" href="./mainfest.webmanifest">
    <meta name="theme-color" content="#0d6efd">


    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />

    <style>
        body {
            font-family: 'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', Arial, sans-serif;
            padding: 40px;
            background-color: #f5f5f5;
        }

        .converter {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .box-row {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .box {
            background-color: #f9f9f9;
            padding: 20px;
            width: 260px;
            height: 120px;
            border-radius: 10px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .box2 {
            background-color: #f9f9f9;
            padding: 20px;
            width: 260px;
            height: 120px;
            border-radius: 10px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            margin-left: auto;
        }

        .box label {
            font-size: 14px;
            color: #666;
        }

        .amount {
            font-size: 22px;
            font-weight: bold;
            color: #000;
        }

        .select1-box1 select {
            font-size: 16px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 100%;
            margin-top: 5px;
            font-family: 'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', Arial, sans-serif;

        }

        .switch {
            position: relative;
            top: 5px;
            z-index: 1;
            margin-left: -20px;
            margin-right: -20px;
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .switch:active {
            transform: rotate(180deg);
        }

        .convert-btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
        }

        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
        }

        .convert-btn:hover {
            background-color: #0056b3;
        }

        .amount-input {
            display: flex;
            align-items: center;
            gap: 5px;
            border: 1px solid #ccc;
            padding: 6px 10px;
            border-radius: 5px;
            font-size: 16px;
        }

        .amount-input input {
            border: none;
            outline: none;
            width: 100%;
            font-size: 16px;
        }

        #amountSymbol {
            font-weight: bold;
        }
    </style>
    <style>
        .modal2 {
            display: none;
            position: fixed;
            z-index: 9999;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.6);
            /* Semi-transparent background */
        }

        /* ===== Modal Content Box ===== */
        .modal2-content {
            background-color: #fff;
            margin: auto;
            padding: 0;
            border-radius: 10px;
            width: 90%;
            max-width: 1000px;
            max-height: 80vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;

        }

        /* ===== Modal Header (Sticky) ===== */
        .modal2-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            /* Opaque background for sticky */
            position: sticky;
            top: 0;
            z-index: 2;
            padding: 15px 20px;
            border-bottom: 1px solid #ddd;
        }

        /* ===== Close Button ===== */
        .close-btn {
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            color: #333;
        }

        .close-btn:hover {
            color: #e60000;
        }

        /* ===== Section with Scrollable Table ===== */
        .modal2-content section {
            overflow-y: auto;
            padding: 20px;
            /* This creates white space around the table */
            flex: 1;
            background-color: #fff;
            /* Ensures white space */
        }


        /* ===== Table Styling ===== */
        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin: 0;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
            word-wrap: break-word;
            white-space: normal;
            font-size: 14px;
        }

        /* Sticky table header */
        thead th {
            position: sticky;
            top: 0;
            background-color: #c0c0c0;
            z-index: 1;
        }

        thead {
            margin-top: 10px;
            /* Optional, won't affect layout much */
        }


        .table-wrapper {
            flex: 1;
            background-color: #fff;
            padding: 20px;
            display: flex;
            flex-direction: column;
        }

        /* Scrollable div around the table */
        .scrollable-table {
            overflow-y: auto;
            max-height: 60vh;
            /* or whatever height works best for your modal */
        }
    </style>
    <style>
        @media screen and (max-width: 768px) {

            body {
                padding: 20px;
            }

            .converter {
                gap: 15px;
            }

            .box-row {
                flex-direction: column;
                align-items: stretch;
            }

            .box,
            .box2 {
                width: 100%;
                height: auto;
            }

            .switch {
                margin: 10px auto;
                position: static;
            }

            .convert-btn,
            .btn {
                font-size: 16px;
                padding: 12px;
                width: 100%;
            }

            .modal2-content {
                width: 95%;
                height: 90vh;
            }

            .modal2-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .close-btn {
                align-self: flex-end;
                margin-top: 10px;
            }

            .modal2-content section {
                padding: 10px;
            }

            table {
                font-size: 13px;
            }

            th,
            td {
                padding: 6px;
            }

            .scrollable-table {
                max-height: 50vh;
            }

            .select1-box1 select {

                font-size: 16px;
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 8px;
                width: 100%;
                margin-top: 5px;
                font-family: 'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', Arial, sans-serif;
            }

            .amount-input {
                flex-direction: column;
                gap: 8px;
            }

            .amount-input input {
                width: 100%;
            }
        }
    </style>

</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!--<div class="loader-wrap">
<div class="preloader">
<div class="preloader-close">x</div>
<div id="handle-preloader" class="handle-preloader">
    <div class="animation-preloader">
        <div class="spinner"></div>
        <div class="txt-loading">
            <span data-text-preloader="M" class="letters-loading">
                M
            </span>
            <span data-text-preloader="A" class="letters-loading">
                A
            </span>
            <span data-text-preloader="D" class="letters-loading">
                D
            </span>
            <span data-text-preloader="O" class="letters-loading">
                O
            </span>
            <span data-text-preloader="C" class="letters-loading">
                C
            </span>
            <span data-text-preloader="K" class="letters-loading">
                K
            </span>
            <span data-text-preloader="S" class="letters-loading">
                S
            </span>
        </div>
    </div>
</div>
  </div>
</div>-->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
<div class="popup-inner">
<div class="upper-box clearfix">
<figure class="logo-box pull-left"><a href="new_index.php"><img src="assets/images/logonew.png"
        alt=""></a></figure>
<div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
</div>
<div class="overlay-layer"></div>
<div class="auto-container">
<div class="search-form">
<form method="post" action="new_index.php">
    <div class="form-group">
        <fieldset>
            <input type="search" class="form-control" name="search-input" value=""
                placeholder="Type your keyword and hit" required>
            <button type="submit"><i class="flaticon-loupe"></i></button>
        </fieldset>
    </div>
</form>
</div>
</div>
</div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                    Us</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="new_index.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
        <li>
            <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
            <a href="logout.php">Logout</a>
        </li>
        <li>
            <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
            <a href="register.php">Signup</a>
        </li>
    </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="new_index.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="dropdown"><a href="new_index.php">Home</a>
                                            <!---<ul>
                        <li><a href="new_index.php">Home One</a></li>
                        <li><a href="new_index.php">Home Two</a></li>
                        <li><a href="new_index.php">Home Three</a></li>
                    </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                        <li><a href="marketsl.php">Markets</a></li>
                        <li><a href="market-details.html">Details Page</a></li>
                    </ul>--->
                                        </li>
                                        <!--<li class="dropdown"><a href="platform.php">Referral Code</a>--->
                                        <!---<ul>
                        <li><a href="platform.php">Platform</a></li>
                        <li><a href="account.html">Our Accounts</a></li>
                        <li><a href="account-details.html">Standard Account</a></li>
                        <li><a href="account-details-2.html">Commision Account</a></li>
                        <li><a href="account-details-3.html">STP Pro Account</a></li>
                    </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="new_index.php">Education</a>
                    <ul>
                        <li><a href="education.html">Education</a></li>
                        <li><a href="education-details.html">Detail Page</a></li>
                    </ul>
                </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                        <li><a href="about.html">Company</a></li>
                        <li><a href="history.html">History</a></li>
                        <li><a href="team.html">Team</a></li>
                        <li class="dropdown"><a href="new_index.php">Blog</a>
                            <ul>
                                <li><a href="blog.html">3 Columns</a></li>
                                <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                <li><a href="blog-3.html">List View 01</a></li>
                                <li><a href="blog-4.html">List View 02</a></li>
                                <li><a href="blog-details.html">Single Post</a></li>
                            </ul>
                        </li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="faq.html">Faq’s</a></li>
                        <li><a href="error.html">404</a></li>
                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="current dropdown"><a href="usdt_main_page_change2.php">USDT</a>
                                        <li class="dropdown"><a href="#" onclick="openTransactionModal()">Transaction
                                                History</a></li>

                                        </li>
                                    </ul>
                                </div>
                            </nav>
                            <div class="menu-right-content">

                                <div class="search-box-outer search-toggler">
                                    <!--<i class="flaticon-search"></i></div>-->
                                    <!---<div class="btn-box"><a href="" class="theme-btn btn-one">
                
            </a></div>--->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--sticky Header-->
                <div class="sticky-header">
                    <div class="auto-container">
                        <div class="outer-box">
                            <div class="logo-box">
                                <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                            alt=""></a>
                                </figure>
                            </div>
                            <div class="menu-area">
                                <nav class="main-menu clearfix">
                                    <!--Keep This Empty / Menu will come through Javascript-->
                                </nav>
                                <div class="menu-right-content">
                                    <div class="search-box-outer search-toggler">
                                        <!--<i class="flaticon-search"></i></div>-->
                                        <!---<div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                



            </a></div>--->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="new_index.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="new_index.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact Us</a>
                        </li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="new_index.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->
        <!--- existing section -->
        <section class="banner-style-three centred">

            <div class="converter">
                <!-- Exchange Rate Display -->
                <div id="exchangeRateDisplay" style="margin-top: 20px; font-size: 16px; color: #333;">
                    <!-- Exchange rate will be shown here -->
                </div>

                <div class="box-row">
                    <!-- Amount to Send -->
                    <div class="box">
                        <label for="amountSend">Amount to Send</label>
                        <div class="amount-input">
                            <span id="amountSymbol">S$</span>
                            <input type="number" id="amountSend" placeholder="Enter amount" min="0">
                        </div>

                    </div>

                    <!-- From Currency -->
                    <div class="box select1-box1">
                        <label for="from">From</label>
                        <select id="from" onchange="updateAmountSymbol()">
                            <option value="SGD" selected>🇸🇬 SGD - Singapore Dollar</option>
                            <option value="USD">🇺🇸 USD - US Dollar</option>
                            <option value="THB">🇹🇭 THB - Thai Baht</option>
                            <option value="MYR">🇲🇾 MYR - Malaysian Ringgit</option>
                            <option value="INR">🇮🇳 INR - Indian Rupee</option>
                            <option value="JPY">🇯🇵 JPY - Japanese Yen</option>
                            <option value="EUR">🇪🇺 EUR - Euro</option>
                            <option value="HKD">🇭🇰 HKD - Hong Kong Dollar</option>
                            <option value="CNY">🇨🇳 CNY - Chinese Yuan</option>
                            <option value="RMB">🇨🇳 RMB - Renminbi</option>
                            <option value="AUD">🇦🇺 AUD - Australian Dollar</option>
                            <option value="GBP">🇬🇧 GBP - British Pound</option>
                            <option value="PHP">🇵🇭 PHP - Philippine Peso</option>
                            <option value="USDT">🌐 USDT - Tether</option>
                        </select>
                    </div>

                    <!-- Switch -->
                    <div class="switch" onclick="swapCurrencies()">⇄</div>

                    <!-- To Currency -->
                    <div class="box select1-box1">
                        <label for="to">To</label>
                        <select id="to">
                            <option value="USD" selected>🇺🇸 USD - US Dollar</option>
                            <option value="SGD">🇸🇬 SGD - Singapore Dollar</option>
                            <option value="THB">🇹🇭 THB - Thai Baht</option>
                            <option value="MYR">🇲🇾 MYR - Malaysian Ringgit</option>
                            <option value="INR">🇮🇳 INR - Indian Rupee</option>
                            <option value="JPY">🇯🇵 JPY - Japanese Yen</option>
                            <option value="EUR">🇪🇺 EUR - Euro</option>
                            <option value="HKD">🇭🇰 HKD - Hong Kong Dollar</option>
                            <option value="CNY">🇨🇳 CNY - Chinese Yuan</option>
                            <option value="RMB">🇨🇳 RMB - Renminbi</option>
                            <option value="AUD">🇦🇺 AUD - Australian Dollar</option>
                            <option value="GBP">🇬🇧 GBP - British Pound</option>
                            <option value="PHP">🇵🇭 PHP - Philippine Peso</option>
                            <option value="USDT">🌐 USDT - Tether</option>
                        </select>
                    </div>

                    <!-- Amount to Receive -->
                    <div class="box">
                        <label for="amountReceive">Amount to Receive</label>
                        <div id="amountReceive" class="amount">US$72.80</div>
                    </div>
                </div>

                <!-- Convert Button -->
                <!--<button class="convert-btn">Convert</button>-->

                <button class="btn">Next</button>


            </div>
        </section>

        <div id="transactionModal" class="modal2" style="display: none;">
            <div class="modal2-content">
                <div class="modal2-header">
                    <h2>Your Transaction History</h2>
                    <span class="close-btn" onclick="closeTransactionModal()">×</span>
                </div>

                <section class="table-wrapper">
                    <div class="scrollable-table">
                        <table id="transactionTable">
                            <thead>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Amount Sent</th>
                                    <th>Source Currency</th>
                                    <th>Amount Received</th>
                                    <th>Target Currency</th>
                                    <th>Transaction Date and Time</th>
                                    <th>Money Sent Status</th>
                                    <th>Money Receive Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Transactions will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                </section>

            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>
        <script>
            new Choices('#currency', {
                searchEnabled: false
            });
        </script>



        <script>
            const currencySymbols = {
                SGD: "S$",
                USD: "$",
                THB: "฿",
                MYR: "RM",
                INR: "₹",
                JPY: "¥",
                EUR: "€",
                HKD: "HK$",
                CNY: "¥",
                RMB: "¥",
                AUD: "A$",
                GBP: "£",
                PHP: "₱",
                USDT: "₮"
            };

            let rates = {};

            async function fetchExchangeRates() {
                try {
                    const res = await fetch('exchangerate1.php');
                    const data = await res.json();
                    rates = data;
                    convertCurrency();
                } catch (error) {
                    console.error("Failed to fetch exchange rates:", error);
                }
            }

            function convertCurrency() {
                const from = document.getElementById('from').value;
                const to = document.getElementById('to').value;

                // Update currency symbol for input
                document.getElementById('amountSymbol').textContent = currencySymbols[from] || '';

                const sendDisplay = document.getElementById('amountSend');
                const receiveDisplay = document.getElementById('amountReceive');
                const rateDisplay = document.getElementById('exchangeRateDisplay');

                const sendAmount = parseFloat(sendDisplay.value) || 0;

                const fromRate = rates[`exchangeRate_${from}`] || 1;
                const toRate = rates[`exchangeRate_${to}`] || 1;

                const baseConverted = (sendAmount / fromRate) * toRate;
                const chargePercentage = 0.0202; // 0.2%
                const finalAmount = baseConverted * (1 - chargePercentage); // Deduct charge

                const oneUnitRate = (toRate / fromRate).toFixed(4);
                const finaloneUnitRate = oneUnitRate * (1 - chargePercentage);


                sendDisplay.value = sendAmount.toFixed(2);
                receiveDisplay.textContent = `${currencySymbols[to] || ''}${finalAmount.toFixed(2)}`;
                rateDisplay.textContent = `1 ${from} = ${finaloneUnitRate.toFixed(4)} ${to} `;
            }

            function updateAmountSymbol() {
                convertCurrency();
            }

            function swapCurrencies() {
                const fromSelect = document.getElementById('from');
                const toSelect = document.getElementById('to');
                const temp = fromSelect.value;
                fromSelect.value = toSelect.value;
                toSelect.value = temp;
                convertCurrency();
            }

            window.onload = () => {
                fetchExchangeRates();
                setInterval(fetchExchangeRates, 120000);

                document.getElementById('amountSend').addEventListener('input', convertCurrency);
                document.getElementById('from').addEventListener('change', convertCurrency);
                document.getElementById('to').addEventListener('change', convertCurrency);
            };

            document.querySelector('.btn').addEventListener('click', () => {
                const amountSend = parseFloat(document.getElementById('amountSend').value) || 0;
                const currencySend = document.getElementById('from').value;
                const amountReceiveText = document.getElementById('amountReceive').textContent;
                const currencyReceive = document.getElementById('to').value;

                const amountReceive = parseFloat(amountReceiveText.replace(/[^\d.]/g, ''));

                if (amountSend <= 0 || isNaN(amountReceive)) {
                    alert("Please enter a valid amount.");
                    return;
                }

                saveTransaction(amountSend.toFixed(2), currencySend, amountReceive.toFixed(2), currencyReceive);
            });


            function saveTransaction(amountSend, currencySend, amountReceive, currencyReceive) {
                fetch('saveTransaction.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        amountSend,
                        currencySend,
                        amountReceive,
                        currencyReceive
                    })
                })
                    .then(res => res.json())
                    .then(data => {
                        console.log("Transaction saved:", data);
                        if (data.status === "success") {
                            checkKYCAndRedirect(); // Now call this
                        } else {
                            alert("Failed to save transaction: " + data.message);
                        }
                    })
                    .catch(err => console.error("Error saving transaction:", err));
            }

            function checkKYCAndRedirect() {
                fetch('kyc_check1.php')
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'completed') {
                            window.location.href = data.redirect;
                        } else {
                            window.location.href = 'kyc6.php';
                        }
                    })
                    .catch(error => {
                        console.error('Error checking KYC status:', error);
                        alert('Could not verify KYC status. Please try again later.');
                    });
            }




        </script>

        <script>
            function openTransactionModal() {
                document.getElementById("transactionModal").style.display = "block";
                loadTransactionData();
            }

            function closeTransactionModal() {
                document.getElementById("transactionModal").style.display = "none";
            }

            function loadTransactionData() {
                fetch("get_transaction1.php")
                    .then(response => response.json())
                    .then(data => {
                        const tableBody = document.querySelector("#transactionTable tbody");
                        tableBody.innerHTML = ""; // clear table

                        data.forEach(row => {
                            const tr = document.createElement("tr");

                            tr.innerHTML = `
                        <td>${row.id}</td>
                        <td>${row.amount_send}</td>
                        <td>${row.currency_send}</td>
                        <td>${row.amount_receive}</td>
                        <td>${row.currency_receive}</td>
                        <td>${row.transaction_time}</td>
                        <td>${row.deposit_status}</td>
                        <td>${row.receive_status}</td>
                    `;
                            tableBody.appendChild(tr);
                        });
                    })
                    .catch(err => {
                        console.error("Failed to load transactions", err);
                    });
            }

            // Optional: close modal on outside click
            window.onclick = function (event) {
                const modal = document.getElementById("transactionModal");
                if (event.target === modal) {
                    closeTransactionModal();
                }
            };
        </script>

<script>
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker
      .register("./sw.js")
      .then((reg) => console.log("Service Worker registered", reg))
      .catch((err) => console.error("Service Worker registration failed:", err));
  }
</script>




        <!-- main-js -->
        <script src="assets/js/script.js"></script>




</body>

</html>