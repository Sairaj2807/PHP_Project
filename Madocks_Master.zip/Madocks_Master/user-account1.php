<?php

require_once 'dbConnect.php';
require 'vendor/autoload.php'; // Ensure you have Endroid/qr-code installed via Composer

use Endroid\QrCode\Builder\Builder; // Import Endroid QR Code Builder
use Endroid\QrCode\Writer\PngWriter;
use Twilio\Rest\Client; 

session_start();

$errors = [];

$account_sid = 'AC123ed9e921a2f70fa480229231503368';
$auth_token = '5e8163958ae2e29d3757b261f62b072b';
$twilio_phone_number = '+15393525772';



// Store OTP in session
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sendOtp'])) {
    $phone = $_POST['phone'];
    $countryCode = $_POST['country_code'];
    $fullPhoneNumber = $countryCode . $phone;

    // Generate a random 6-digit OTP
    $otp = mt_rand(100000, 999999);

    // Store the OTP in the session
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_phone'] = $fullPhoneNumber;

    // Send the OTP using Twilio
    try {
        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
            $fullPhoneNumber,
            [
                'from' => $twilio_phone_number,
                'body' => "Your OTP for registration is: $otp"
            ]
        );
        echo "OTP sent successfully!";
    } catch (Exception $e) {
        echo "Error sending OTP: " . $e->getMessage();
    }
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $name = $_POST['name'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $countryCode = $_POST['country_code'];
    $phone = $_POST['phone'];
    $otp = $_POST['otp'];
    $created_at = date('Y-m-d H:i:s');

    // Concatenate full phone number
    $fullPhoneNumber = $countryCode . $phone;

    // Validate input fields
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    if (empty($name)) {
        $errors['name'] = 'Name is required';
    }
    if (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters long.';
    }
    if ($password !== $confirmPassword) {
        $errors['confirm_password'] = 'Passwords do not match';
    }
    if (empty($phone)) {
        $errors['phone'] = 'Phone number is required';
    }
    if ($otp != $_SESSION['otp']) {
        $errors['otp'] = 'Invalid OTP';
    }

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    if ($stmt->fetch()) {
        $errors['user_exist'] = 'Email is already registered';
    }

    // Redirect back with errors if validation fails
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: login_otp.php');
        exit();
    }

    // Generate unique referral code
    $referralCode = substr(str_pad(mt_rand(0, 99999999), 8, '0', STR_PAD_LEFT), 0, 8);
    $referralLink = "www.madocks.ai/register.php?code=" . $referralCode;

    // Generate QR Code for the referral link
    $qrImagePath = 'qr_codes/' . $referralCode . '.png'; // Path to save QR code
    $qrCode = Builder::create()
        ->writer(new PngWriter())
        ->data($referralLink) // QR code will now store the referral link
        ->size(300)
        ->margin(10)
        ->build();

    // Save the QR code as a PNG file
    $qrCode->saveToFile($qrImagePath);

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert user into database
    $stmt = $pdo->prepare("INSERT INTO users (email, password, name, phone, created_at, referral_code, referral_link, phone_verified) 
                           VALUES (:email, :password, :name, :phone, :created_at, :referral_code, :referral_link, :phone_verified)");
                           
    $stmt->execute([
        'email' => $email,
        'password' => $hashedPassword,
        'name' => $name,
        'created_at' => $created_at,
        'referral_code' => $referralCode,
        'referral_link' => $referralLink, // Storing the referral link
        'phone' => $fullPhoneNumber,
        'phone_verified' => 1 // Mark phone as verified after OTP is validated
    ]);

    // Clear OTP from session and redirect to success page
    unset($_SESSION['otp']);
    unset($_SESSION['phone']);

    header('Location: index.html');
    exit();
}



if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signin'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // Validate login fields
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    if (empty($password)) {
        $errors['password'] = 'Password cannot be empty';
    }

    // Redirect back with errors if validation fails
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: login.php');
        exit();
    }

    // Check for user in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    // Verify password and set session
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'created_at' => $user['created_at'],
            'referral_code' => $user['referral_code'],
            'referral_link' => $user['referral_link'] // Store referral link in session
        ];

        header('Location: indexl.php');
        exit();
    } else {
        $errors['login'] = 'Invalid email or password';
        $_SESSION['errors'] = $errors;
        header('Location: login.php');
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['usdt_login'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // Validate login fields
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    if (empty($password)) {
        $errors['password'] = 'Password cannot be empty';
    }

    // Redirect back with errors if validation fails
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: login_usdt.php');
        exit();
    }

    // Check for user in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    // Verify password and set session
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'created_at' => $user['created_at'],
            'referral_code' => $user['referral_code'],
            'referral_link' => $user['referral_link'] // Store referral link in session
        ];

        header('Location: usdt.php');
        exit();
    } else {
        $errors['login'] = 'Invalid email or password';
        $_SESSION['errors'] = $errors;
        header('Location: login_usdt.php');
        exit();
    }
}


?>
