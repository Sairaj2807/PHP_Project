<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in."]);
    exit();
}

$user_id = $_SESSION['user']['id'];
$data = json_decode(file_get_contents("php://input"), true);

$amountSend = $data['amountSend'];
$currencySend = $data['currencySend'];
$amountReceive = $data['amountReceive'];
$currencyReceive = $data['currencyReceive'];

$xe_rates = json_decode(file_get_contents('xe_rates.json'), true);
$xe_send_rate = $xe_rates['exchangeRate_' . strtoupper($currencySend)] ?? 1;
$xe_receive_rate = $xe_rates['exchangeRate_' . strtoupper($currencyReceive)] ?? 1;

// Calculate fixed rate
$rate1 = $xe_receive_rate / $xe_send_rate;

$rates = json_decode(file_get_contents('exchangeRates.json'), true);
$send_rate = $rates['exchangeRate_' . strtoupper($currencySend)] ?? 1;
$receive_rate = $rates['exchangeRate_' . strtoupper($currencyReceive)] ?? 1;

// Calculate fixed rate
$rate = $receive_rate / $send_rate;

// Calculate financial values
$new_apa = $rate1 * 0.004;
$new_apa2 = $rate1 - $new_apa;

$new_mad = $rate1 * 0.006;
$new_madocks = $rate1 - $new_mad;

$abc = $rate1 * $amountSend;
$xyz = $new_apa2 * $amountSend;

$profit_apa = $abc - $xyz;

$pqr = $new_apa2 * $amountSend;
$stu = $new_madocks * $amountSend;

$profit_madocks = $pqr - $stu;

if ($currencySend === 'USDT' && $rate1 != 0) {
    $profit_apa = $profit_apa / $rate1;
    $profit_madocks = $profit_madocks / $rate1;
}

try {
    $stmt = $pdo->prepare("INSERT INTO records (user_id, amount_send, currency_send, amount_receive, currency_receive, profit_apa, profit_madocks) 
                           VALUES (:user_id, :amount_send, :currency_send, :amount_receive, :currency_receive, :profit_apa, :profit_madocks)");
    $stmt->execute([
        ':user_id' => $user_id,
        ':amount_send' => $amountSend,
        ':currency_send' => $currencySend,
        ':amount_receive' => $amountReceive,
        ':currency_receive' => $currencyReceive,
        ':profit_apa' => $profit_apa,
        ':profit_madocks' => $profit_madocks,
    ]);

    echo json_encode(["status" => "success", "message" => "Transaction saved."]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
