<?php
// Fetch exchange rates

$exchangeRateUrl = 'exchangerate1.php';
$ch = curl_init($exchangeRateUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

if ($response !== false) {
    echo "<h4>Raw Response:</h4>";
    echo '<pre>' . htmlspecialchars($response) . '</pre>';
} else {
    echo "<h4>Error: Failed to fetch exchange rates via CURL.</h4>";
}

