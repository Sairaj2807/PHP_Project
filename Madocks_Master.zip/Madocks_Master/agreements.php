<?php
require 'vendor/autoload.php';
include 'dbConnect.php'; // Include the database connection file

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Twilio\Rest\Client;



header('Content-Type: application/json'); // Send response as JSON

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES['agreement']) && $_FILES['agreement']['error'] == 0) {
        
        $uploadDir = "uploads/"; // Directory for storing uploads
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Create if not exists
        }

        $fileName = basename($_FILES['agreement']['name']);
        $filePath = $uploadDir . time() . "_" . $fileName; // Unique filename

        // Move uploaded file to the directory
        if (move_uploaded_file($_FILES['agreement']['tmp_name'], $filePath)) {
            // Store file info in the database
            $stmt = $pdo->prepare("INSERT INTO agreements (user_id, file_name, file_path) VALUES (:user_id, :file_name, :file_path)");
            $stmt->execute([
                ':user_id' => 1, // Replace with actual user ID
                ':file_name' => $fileName,
                ':file_path' => $filePath
            ]);

            // Send the uploaded file via email
            if (sendEmailWithAttachment($filePath, $fileName)) {
                echo json_encode(["message" => "File uploaded and email sent successfully!"]);
            } else {
                echo json_encode(["message" => "File uploaded, but email failed to send!"]);
            }

        } else {
            echo json_encode(["message" => "Error uploading file!"]);
        }
    } else {
        echo json_encode(["message" => "No file uploaded!"]);
    }

    sendWhatsAppMessagetoapa_Agreement();

    
}

function sendEmailWithAttachment($filePath, $fileName) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';  // Your email
        $mail->Password = 'uexurwwgwuotfcge';  // Your App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com'); // Recipient email
        $mail->addAttachment($filePath, $fileName); // Attach the uploaded file

        $mail->isHTML(true);
        $mail->Subject = 'New Agreement Uploaded';
        $mail->Body = '<h3>A new agreement has been uploaded. Please find the attachment.</h3>';

        return $mail->send();
    } catch (Exception $e) {
        return false;
    }
}

function sendWhatsAppMessagetoapa_Agreement()
        {
            $sid = "AC123ed9e921a2f70fa480229231503368";
            $token = "5e8163958ae2e29d3757b261f62b072b";
            $twilio = new Client($sid, $token);

            $body = "User has Submitted agreement please check mail ";

            $message = $twilio->messages->create("whatsapp:+917588345894", [
                "from" => "whatsapp:+14155238886",
                "body" => $body
            ]);
        }
