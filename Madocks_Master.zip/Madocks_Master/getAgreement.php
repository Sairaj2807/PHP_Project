<?php
require 'dbConnect.php';
$userId = $_GET['user_id'];

$stmt = $pdo->prepare("SELECT * FROM kyc WHERE user_id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

$address = "{$user['address1']}, {$user['address2']}, {$user['address3']}";
$today = date('j F Y');

$agreement = "
<p><strong>Liquidity Agreement</strong><br>$today</p>
<p>Between</p>
<p><strong>{$user['full_name']}</strong>, holder of Passport ID: {$user['passport_id']}, with the address of $address.</p>
<p>And</p>
<p><strong>ATLANTIC PARTNERS SPC FUND</strong>...</p>
<!-- Rest of the agreement text here -->
<p><em>This agreement is generated dynamically...</em></p>
";

echo $agreement;
?>
