<?php
// Run this once to get the hash
echo password_hash('admin123', PASSWORD_DEFAULT);
?>
