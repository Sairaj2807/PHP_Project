<?php
session_start();
require 'dbConnect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    try {
        $stmt = $pdo->prepare("SELECT id, password_hash FROM admin_users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $user['id'];
            header("Location: admin.php");
            exit();
        } else {
            header("Location: login.html?error=Invalid+username+or+password");
            exit();
        }
    } catch (PDOException $e) {
        header("Location: login.html?error=Something+went+wrong");
        exit();
    }
} else {
    header("Location: login.html");
    exit();
}
