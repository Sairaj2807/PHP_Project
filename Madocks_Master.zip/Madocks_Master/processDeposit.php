<?php
/*include 'dbConnect.php';
session_start(); // Ensure the session is started

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if user is logged in
    if (!isset($_SESSION['user']['id'])) {
        die(json_encode(['status' => 'error', 'message' => 'User not logged in.']));
    }

    $user_id = $_SESSION['user']['id'];

    // Check if file is uploaded and USDT address is provided
    if (isset($_FILES['receipt']) && isset($_POST['usdt_address'])) {
        $usdt_address = trim($_POST['usdt_address']);

        // Create uploads directory if it doesn't exist
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Save the uploaded file
        $fileName = basename($_FILES['receipt']['name']);
        $filePath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['receipt']['tmp_name'], $filePath)) {
            // File uploaded successfully, now store in the database
            $query = "INSERT INTO transactions (user_id, transaction_type, receipt_file, usdt_address, transaction_time) 
                      VALUES (:user_id, 'deposit', :receipt_file, :usdt_address, NOW())";

            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':receipt_file', $filePath, PDO::PARAM_STR);
            $stmt->bindParam(':usdt_address', $usdt_address, PDO::PARAM_STR);

            if ($stmt->execute()) {
                // Return success response
                echo json_encode(['status' => 'success', 'message' => 'Data stored successfully.']);
                exit;
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to store data in the database.']);
                exit;
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to upload file.']);
            exit;
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'File or USDT address not provided.']);
        exit;
    }
}*/



// for same entry 
/*include 'dbConnect.php';
session_start(); 


if (!isset($_SESSION['user']['id'])) {
    die("Error: User not logged in.");
}

// Retrieve user ID correctly
$user_id = $_SESSION['user']['id'];

// Check if form is submitted and files are uploaded
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['receipt']) && isset($_POST['usdt_address'])) {
    // Sanitize and fetch the USDT address
    $usdt_address = htmlspecialchars($_POST['usdt_address']);

    // Handle file upload
    $upload_dir = 'uploads/';
    $filename = basename($_FILES['receipt']['name']);
    $target_file = $upload_dir . $filename;

    if (move_uploaded_file($_FILES['receipt']['tmp_name'], $target_file)) {
        // Fetch the latest 'buy' transaction for the user
        $query = "SELECT id FROM transactions 
                  WHERE user_id = :user_id AND transaction_type = 'buy' 
                  ORDER BY transaction_time DESC LIMIT 1";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($transaction) {
            $transaction_id = $transaction['id'];

            // Update the transaction with the uploaded file path and USDT address
            $update_query = "UPDATE transactions 
                             SET receipt_file = :receipt_file, usdt_address = :usdt_address 
                             WHERE id = :transaction_id";
            $update_stmt = $pdo->prepare($update_query);
            $update_stmt->bindParam(':receipt_file', $target_file, PDO::PARAM_STR);
            $update_stmt->bindParam(':usdt_address', $usdt_address, PDO::PARAM_STR);
            $update_stmt->bindParam(':transaction_id', $transaction_id, PDO::PARAM_INT);

            if ($update_stmt->execute()) {
                echo "success";
            } else {
                echo "Error: Failed to update the transaction.";
            }
        } else {
            echo "Error: No transactions found.";
        }
    } else {
        echo "Error: Failed to upload the receipt file.";
    }
} else {
    echo "Error: Invalid form submission.";
}*/

// with send mail and smae entry 

include 'dbConnect.php';
session_start(); // Ensure session is started

// Include PHPMailer
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Twilio\Rest\Client;



// Check if the session user data exists
if (!isset($_SESSION['user']['id'])) {
    die("Error: User not logged in.");
}

// Retrieve user ID correctly
$user_id = $_SESSION['user']['id'];

// Check if form is submitted and files are uploaded
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['receipt']) && isset($_POST['usdt_address'])) {
    // Sanitize and fetch the USDT address
    $usdt_address = htmlspecialchars($_POST['usdt_address']);

    // Handle file upload
    $upload_dir = 'uploads/';
    $filename = basename($_FILES['receipt']['name']);
    $target_file = $upload_dir . $filename;

    if (move_uploaded_file($_FILES['receipt']['tmp_name'], $target_file)) {
        // Fetch the latest 'buy' transaction for the user
        $query = "SELECT id FROM transactions 
                  WHERE user_id = :user_id AND transaction_type = 'buy' 
                  ORDER BY transaction_time DESC LIMIT 1";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($transaction) {
            $transaction_id = $transaction['id'];

            // Update the transaction with the uploaded file path and USDT address
            $update_query = "UPDATE transactions 
                             SET receipt_file = :receipt_file, usdt_address = :usdt_address 
                             WHERE id = :transaction_id";
            $update_stmt = $pdo->prepare($update_query);
            $update_stmt->bindParam(':receipt_file', $target_file, PDO::PARAM_STR);
            $update_stmt->bindParam(':usdt_address', $usdt_address, PDO::PARAM_STR);
            $update_stmt->bindParam(':transaction_id', $transaction_id, PDO::PARAM_INT);

            if ($update_stmt->execute()) {
                // Send email with receipt file attachment
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'madocks.ai@gmail.com'; // Your email
                    $mail->Password = 'uexurwwgwuotfcge'; // Your App Password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
                    $mail->addAddress('sdbangar2807@gmail.com');
                    $mail->addAttachment($target_file); // Attach receipt file

                    $mail->isHTML(true);
                    $mail->Subject = 'New USDT Transaction Receipt';
                    $mail->Body = "<h3>New USDT transaction receipt uploaded.</h3>
                                   <p><strong>User ID:</strong> $user_id</p>
                                   <p><strong>USDT Address:</strong> $usdt_address</p>
                                   <p>The receipt file is attached.</p>";

                    if ($mail->send()) {
                        echo "success";
                    } else {
                        echo "Error: Failed to send email.";
                    }
                } catch (Exception $e) {
                    echo "Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                echo "Error: Failed to update the transaction.";
            }
        } else {
            echo "Error: No transactions found.";
        }
    } else {
        echo "Error: Failed to upload the receipt file.";
    }

    sendWhatsAppMessagetoapa_Deposit($user_id, $usdt_address);

} else {
    echo "Error: Invalid form submission.";
}

function sendWhatsAppMessagetoapa_Deposit($user_id, $usdt_address)
        {
            $sid = "AC123ed9e921a2f70fa480229231503368";
            $token = "5e8163958ae2e29d3757b261f62b072b";
            $twilio = new Client($sid, $token);

            $body = "UserID - $user_id has Deposited money USDT address - $usdt_address, please check mail ";

            $message = $twilio->messages->create("whatsapp:+917588345894", [
                "from" => "whatsapp:+14155238886",
                "body" => $body
            ]);
        }


?>







