<?php
session_start();

// Capture the referral code from the URL if it exists
$referralCode = isset($_GET['code']) ? htmlspecialchars($_GET['code']) : '';

if (isset($_SESSION['errors'])) {
    $errors = $_SESSION['errors'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>

    <div class="container" id="signup">
        <h1 class="form-title">Register</h1>

        <?php
        if (isset($errors['user_exist'])) {
            echo '<div class="error-main">
                    <p>' . $errors['user_exist'] . '</p>
                  </div>';
            unset($errors['user_exist']);
        }
        ?>

        <form method="POST" action="user-account1.php">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="name" id="name" placeholder="Name" required>
                <?php
                if (isset($errors['name'])) {
                    echo '<div class="error">
                            <p>' . $errors['name'] . '</p>
                          </div>';
                }
                ?>
            </div>

            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" id="email" placeholder="Email" required>
                <?php
                if (isset($errors['email'])) {
                    echo '<div class="error">
                            <p>' . $errors['email'] . '</p>
                          </div>';
                    unset($errors['email']);
                }
                ?>
            </div>

            <div class="input-group password">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" id="password" placeholder="Password">
                <i id="eye" class="fa fa-eye"></i>
                <?php
                if (isset($errors['password'])) {
                    echo '<div class="error">
                            <p>' . $errors['password'] . '</p>
                          </div>';
                    unset($errors['password']);
                }
                ?>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                <?php
                if (isset($errors['confirm_password'])) {
                    echo '<div class="error">
                            <p>' . $errors['confirm_password'] . '</p>
                          </div>';
                    unset($errors['confirm_password']);
                }
                ?>
            </div>

            <!-- Phone Number Section -->
            <!---<div class="input-group">
                <i class="fas fa-phone"></i>
                <input type="tel" name="phone" id="phone" placeholder="Phone Number (with country code)" required>
                <?php
                //if (isset($errors['phone'])) {
                //echo '<div class="error">
                // <p>' . $errors['phone'] . '</p>
                //</div>';
                //}
                ?>
            </div>--->

            <!-- Country Code Dropdown Section -->
            <div class="input-group">

                <label for="country_code" class="sr-only">Country Code</label>
                <select name="country_code" id="country_code" required
                    style="width: 25px; text-align: center; padding: 5px;">
                    <option value="+1">(+1)United States</option>
                    <option value="+91" selected>(+91) India</option>
                    <option value="+44">United Kingdom (+44)</option>
                    <option value="+61">Australia (+61)</option>
                    <option value="+81">Japan (+81)</option>
                    <option value="+49">Germany (+49)</option>
                    <option value="+33">France (+33)</option>
                    <option value="+86">China (+86)</option>
                    <option value="+7">Russia (+7)</option>
                    <option value="+55">Brazil (+55)</option>
                    Add more countries as needed
                </select>
                <input type="tel" name="phone" id="phone" placeholder="Phone Number" required>
                <?php
                if (isset($errors['phone'])) {
                    echo '<div class="error">
                <p>' . $errors['phone'] . '</p>
              </div>';
                }
                ?>
            </div>


            <!-- OTP Section -->
            <div class="input-group">
                <i class="fas fa-key"></i>
                <input type="text" name="otp" id="otp" placeholder="Enter OTP" required>
                <?php
                if (isset($errors['otp'])) {
                    echo '<div class="error">
                            <p>' . $errors['otp'] . '</p>
                          </div>';
                }
                ?>
            </div>
            <!--<button type="button" id="sendOtp" class="btn">Send OTP</button>-->
            <button type="button" id="sendOtp" class="btn">Send OTP</button>


            <!-- Referral Code Section -->
            <div class="input-group">
                <i class="fas fa-share-alt"></i>
                <input type="text" name="referral_code" id="referral_code" placeholder="Referral Code"
                    value="<?php echo $referralCode; ?>" readonly>
                <?php
                if (isset($errors['referral_code'])) {
                    echo '<div class="error">
                            <p>' . $errors['referral_code'] . '</p>
                          </div>';
                }
                ?>
            </div>

            <input type="submit" class="btn" value="Sign Up" name="signup">
        </form>

        <p class="or">
            ----------or--------
        </p>

        <div class="links">
            <p>Already Have an Account?</p>
            <a href="login.php">Sign In</a>
        </div>
    </div>

    <script>
        document.getElementById("sendOtp").addEventListener("click", function (e) {
        e.preventDefault(); // Prevent form submission
        let phone = document.getElementById("phone").value;
        let countryCode = document.getElementById("country_code").value;

        if (!phone) {
            alert("Please enter a valid phone number.");
            return;
        }

        let formData = new FormData();
        formData.append("sendOtp", true);
        formData.append("phone", phone);
        formData.append("country_code", countryCode);

        fetch("user-account.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => alert(data))
        .catch(error => alert("Error sending OTP: " + error));
    });
    </script>
</body>

</html>

<?php
if (isset($_SESSION['errors'])) {
    unset($_SESSION['errors']);
}
?>