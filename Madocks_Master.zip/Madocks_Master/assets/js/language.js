const translations = {
	en: {
	  welcome: "Welcome to MADOCKS",
	  intro: "At madocks, we empower traders with smart solutions through our three core offerings:"
	},
	zh: {
	  welcome: "欢迎来到 MADOCKS",
	  intro: "在 madocks，我们通过三项核心产品为交易者提供智能解决方案："
	},
	hi: {
	  welcome: "MADOCKS में आपका स्वागत है",
	  intro: "Madocks में, हम अपने तीन मुख्य प्रस्तावों के माध्यम से व्यापारियों को स्मार्ट समाधान प्रदान करते हैं:"
	}
  };
  
  function translatePage(language) {
	document.querySelectorAll("[data-translate]").forEach((el) => {
	  const key = el.getAttribute("data-translate");
	  if (translations[language] && translations[language][key]) {
		el.textContent = translations[language][key];
	  }
	});
  }
  
  document.getElementById("language-selector").addEventListener("change", function () {
	const selectedLang = this.value;
	translatePage(selectedLang);
  });
  