<?php
session_start();
require 'dbConnect.php';



try {
    $stmt = $pdo->prepare("SELECT id, user_id,referred_by, amount_send, currency_send, amount_receive, currency_receive, profit_apa, profit_madocks FROM records");
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["status" => "success", "records" => $records]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
