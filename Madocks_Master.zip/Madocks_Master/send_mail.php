<?php
require 'dbConnect.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

use Twilio\Rest\Client;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $mail_type = $_POST['mail_type'];

    if (empty($user_id) || empty($mail_type)) {
        echo json_encode(["status" => "error", "message" => "User ID and mail type are required"]);
        exit;
    }

    try {
        // Fetch user's email
        $query = "SELECT email FROM users WHERE id = :user_id";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['user_id' => $user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            echo json_encode(["status" => "error", "message" => "User not found"]);
            exit;
        }

        $email = $user['email'];

        if ($mail_type === 'kyc' || $mail_type === 'liquidity') {
            $query = $mail_type === 'kyc' ? "SELECT status FROM kyc WHERE user_id = :user_id" : "SELECT status FROM liquidity_agreements WHERE user_id = :user_id";
            $stmt = $pdo->prepare($query);
            $stmt->execute(['user_id' => $user_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $status = $result ? $result['status'] : 'Not Available';

            $subject = "KYC and Liquidity Agreement Update";
            $body = "<p>Dear User,</p><p>Your $mail_type status is: <b>$status</b></p>
            <p>Click <a href='https://www.madocks.ai/login.php' style='color: #007bff; text-decoration: none; font-weight: bold;'>here </a> to log in to your account for more details.</p>
            <p>Thank you!</p>";
        } elseif ($mail_type === 'deposit' || $mail_type === 'receiveMoney') {
            // Fetch latest 'buy' transaction for the user
            $query = "SELECT amount_send, currency_send, amount_receive, currency_receive, deposit_status, receive_status
          FROM transactions 
          WHERE user_id = :user_id AND transaction_type = 'buy' 
          ORDER BY transaction_time DESC 
          LIMIT 1";
            $stmt = $pdo->prepare($query);
            $stmt->execute(['user_id' => $user_id]);
            $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$transaction) {
                echo json_encode(["status" => "error", "message" => "No transactions found"]);
                exit;
            }

            $amount_send = number_format($transaction['amount_send'], 6);
            $currency_send = $transaction['currency_send'];
            $amount_receive = number_format($transaction['amount_receive'], 6);
            $currency_receive = $transaction['currency_receive'];
            $deposit_status = ucfirst($transaction['deposit_status']); // Capitalizing first letter
            $receive_status = ucfirst($transaction['receive_status']); // Capitalizing first letter

            if ($mail_type === 'deposit') {
                $subject = "Deposit Status Updated";
                $body = "Dear User, <br><br>
            Your transaction status has been updated:<br><br>
            <strong>Update Type:</strong> Deposit Status <br>
            <strong>Status:</strong> $deposit_status <br>
            <strong>Currency Sent:</strong> $currency_send <br>
            <strong>Amount Sent:</strong> $amount_send <br><br>
            <p>Click <a href='https://www.madocks.ai/login.php' style='color: #007bff; text-decoration: none; font-weight: bold;'>here </a> to log in to your account for more details.</p>
            <p>Thank you!</p>";
            } elseif ($mail_type === 'receiveMoney') {
                $subject = "Receive Money Status Updated";
                $body = "Dear User, <br><br>
            Your transaction status has been updated:<br><br>
            <strong>Update Type:</strong> Receive Status <br>
            <strong>Status:</strong> $receive_status <br>
            <strong>Currency Sent:</strong> $currency_send <br>
            <strong>Amount Sent:</strong> $amount_send <br>
            <strong>Currency Received:</strong> $currency_receive <br>
            <strong>Amount Received:</strong> $amount_receive <br><br>
            <p>Click <a href='https://www.madocks.ai/login.php' style='color: #007bff; text-decoration: none; font-weight: bold;'>here </a> to log in to your account for more details.</p>
            <p>Thank you!</p>";
            }

        } else {
            echo json_encode(["status" => "error", "message" => "Invalid mail type"]);
            exit;
        }

        // Send email
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;

        if ($mail->send()) {
            // WhatsApp message content
            $whatsappMessage = "";
        
            if ($mail_type === 'kyc') {
                $whatsappMessage = "KYC status updated. Current status: $status. Please check email for more details.";
            } elseif ($mail_type === 'liquidity') {
                $whatsappMessage = "Liquidity Agreement status updated. Current status: $status. Please check email for more details.";
            } elseif ($mail_type === 'deposit') {
                $whatsappMessage = "Deposit status updated.\nStatus: $deposit_status\nSent: $amount_send $currency_send , Please check email for more details." ;
            } elseif ($mail_type === 'receiveMoney') {
                $whatsappMessage = "Receive Money status updated.\nStatus: $receive_status\nSent: $amount_send $currency_send\nReceived: $amount_receive $currency_receive , Please check email for more details.";
            }
        
            // Send WhatsApp message
            if (!empty($whatsappMessage)) {
                sendWhatsAppMessage($whatsappMessage);
            }
        
            echo json_encode(["status" => "success", "message" => "Email and WhatsApp message sent successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to send email"]);
        }
        
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "Error: " . $e->getMessage()]);
    }
}

function sendWhatsAppMessage($messageBody)
{
    $sid = "AC123ed9e921a2f70fa480229231503368";
    $token = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $twilio->messages->create("whatsapp:+917588345894", [
        "from" => "whatsapp:+14155238886",
        "body" => $messageBody
    ]);
}

