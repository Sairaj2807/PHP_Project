<?php
session_start();
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <style>
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            z-index: 1000;
            /* Ensure it's above everything else */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            /* Dark overlay */
            overflow-y: auto;
            /* Allow scrolling within the modal */
        }

        /* Prevent background from scrolling when modal is open */
        body.modal-open {
            overflow: hidden;
        }


        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }

        .close-btn {
            cursor: pointer;
            font-size: 24px;
        }

        .modal-body {
            padding: 20px 0;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input,
        select textarea {

            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;

        }






        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .clicked {
            background-color: #28a745 !important;
            /* Green color to indicate success */
            transform: scale(0.95);
        }

        .reference-code {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .circle {
            width: 200px;
            height: 200px;
            background: white;
            border-radius: 50%;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            position: relative;
        }

        .circle span {
            color: #007bff;
        }

        .options {
            color: black;
            display: flex;
            flex-direction: column;
            gap: 30px;
            margin-left: 80px;
        }

        .option {
            color: black;
            display: flex;
            align-items: center;
            background: white;
            padding: 15px;
            border-radius: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            justify-content: space-between;
            position: relative;
        }

        .icon {
            width: 40px;
            height: 40px;
            background: #f0f8ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
        }

        .text {
            text-align: left;
            flex: 1;
        }

        .text h3 {
            margin: 0;
            font-size: 16px;
            color: #007bff;
        }

        .text p {
            margin: 5px 0 0;
            font-size: 14px;
            color: #555;
        }

        .btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .modaldeposit {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modaldeposit-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modaldeposit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        input[type="file"],
        input[type="text"] {
            display: block;
            margin: 10px 0;
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }


        .modal2 {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        /*.modal2-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }*/

        .modal2-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;

            overflow-y: auto;
            /* Enable vertical scrolling */
            max-height: 80vh;
        }

        .modal2-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .reference-code2 {
            font-weight: bold;
            color: black;
            font-size: 16px;
            margin-top: 10px;
            text-align: left;
        }

        .btn:disabled {
            background: gray;
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!---<div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>--->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
    <div class="popup-inner">
        <div class="upper-box clearfix">
            <figure class="logo-box pull-left"><a href="new_index.php"><img src="assets/images/logonew.png"
                        alt=""></a></figure>
            <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <div class="overlay-layer"></div>
        <div class="auto-container">
            <div class="search-form">
                <form method="post" action="new_index.php">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value=""
                                placeholder="Type your keyword and hit" required>
                            <button type="submit"><i class="flaticon-loupe"></i></button>
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                    Us</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                                <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="new_index.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                            <a href="logout.php">Logout</a>
                        </li>
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                            <a href="register.php">Signup</a>
                        </li>
                    </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="new_index.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="current dropdown"><a href="new_index.php">Home</a>
                                            <!---<ul>
                                        <li><a href="new_index.php">Home One</a></li>
                                        <li><a href="new_index.php">Home Two</a></li>
                                        <li><a href="new_index.php">Home Three</a></li>
                                    </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                        <li><a href="marketsl.php">Markets</a></li>
                                        <li><a href="market-details.html">Details Page</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                        <li><a href="platform.php">Platform</a></li>
                                        <li><a href="account.html">Our Accounts</a></li>
                                        <li><a href="account-details.html">Standard Account</a></li>
                                        <li><a href="account-details-2.html">Commision Account</a></li>
                                        <li><a href="account-details-3.html">STP Pro Account</a></li>
                                    </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="new_index.php">Education</a>
                                    <ul>
                                        <li><a href="education.html">Education</a></li>
                                        <li><a href="education-details.html">Detail Page</a></li>
                                    </ul>
                                </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                        <li><a href="about.html">Company</a></li>
                                        <li><a href="history.html">History</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li class="dropdown"><a href="new_index.php">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">3 Columns</a></li>
                                                <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                <li><a href="blog-3.html">List View 01</a></li>
                                                <li><a href="blog-4.html">List View 02</a></li>
                                                <li><a href="blog-details.html">Single Post</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                        <li><a href="faq.html">Faq’s</a></li>
                                        <li><a href="error.html">404</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="dropdown"><a href="usdt_main.php">USDT</a>

                                        </li>
                                        <!--<li class="dropdown"><a href="sneat/html/index.html">Dashboard</a> </li>-->
                                    </ul>
                                </div>
                            </nav>
                            <!--<div class="menu-right-content">

                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="" class="theme-btn btn-one">
                                
                            </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                            <!--<div class="menu-right-content">
                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                                



                         </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="new_index.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="new_index.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                Here</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="new_index.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- banner-style-three -->
        <section class="banner-style-three centred">

            <div class="container">
                <!-- Circular Infographic -->
                <div class="circle">
                    KYC <br> <span></span>
                </div>

                <!-- Connecting Lines -->
                <div class="line-container">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>

                <!-- Option Boxes -->
                <div class="options">
                    <!-- Option A -->
                    <div class="option">
                        <div class="icon">👤</div>
                        <div class="text">
                            <h3>Step1: KYC submission</h3>
                            <p>Status: <span id="kyc-status" style="color: orange;">Pending</span></p>
                        </div>
                        <button class="btn" id="kyc-btn" onclick="openModal()">Select</button>
                    </div>

                    <!-- Option B -->
                    <div class="option">
                        <div class="icon">🎫</div>
                        <div class="text">
                            <h3>Step2: Liquidity agreement</h3>
                            <p>Status: <span id="agreement-status" style="color: orange;">Pending</span> </p>

                        </div>
                        <button class="btn" id="step2-btn" onclick="openModal2()" disabled>Select</button>
                    </div>



                </div>
            </div>

        </section>


        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode();
            });

            function generateReferenceCode() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });

        </script>

        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode2();
            });

            function generateReferenceCode2() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay2").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode2").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode2").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });
        </script>

        <div id="usdtModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>USDT Onboarding</h2>
                    <span class="close-btn" onclick="closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <h3>KYC APPLICATION</h3>
                    <h4>INDIVIDUAL DETAILS</h4>

                    <form id="usdtOnboardingForm">
                        <div class="reference-code"><strong id="referenceCodeDisplay"></strong></div>
                        <input type="hidden" id="referenceCode" name="referenceCode">

                        <label for="apaEmployee">Name of the MADOCKS employee spoken to </label>
                        <input type="text" id="apaEmployee" name="apaEmployee">

                        <label for="fullName">Full Name as per Passport/ID *</label>
                        <input type="text" id="fullName" name="fullName" required>

                        <label for="dob">Date of Birth *</label>
                        <input type="text" id="dob" name="dob" placeholder="DDMMYYYY" required>

                        <label for="nationality">Nationality *</label>
                        <select id="nationality" name="nationality" required>
                            <option value="">Select Country</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                            <option value="UK">United Kingdom</option>
                        </select>

                        <label for="address1">Address Line 1 *</label>
                        <input type="text" id="address1" name="address1" required>

                        <label for="address2">Address Line 2</label>
                        <input type="text" id="address2" name="address2">

                        <label for="address3">Address Line 3</label>
                        <input type="text" id="address3" name="address3">

                        <label for="postcode">Postcode *</label>
                        <input type="text" id="postcode" name="postcode" required>

                        <label for="mobile">Mobile Number *</label>
                        <input type="text" id="mobile" name="mobile" required>

                        <label for="passportId">Passport/ID Number *</label>
                        <input type="text" id="passportId" name="passportId" required>

                        <label for="country">Country *</label>
                        <select id="country" name="country" required>
                            <option value="">Select Country</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                            <option value="UK">United Kingdom</option>
                        </select>

                        <label for="occupation">Occupation *</label>
                        <input type="text" id="occupation" name="occupation" required>

                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required>

                        <label for="currencies">Currencies Required *</label>
                        <input type="text" id="currencies" name="currencies" required>

                        <label for="sourceWealth">Source of Wealth *</label>
                        <input type="file" id="sourceWealth" name="sourceWealth" required>

                        <label for="proofIdentity">Proof of Identity *</label>
                        <input type="file" id="proofIdentity" name="proofIdentity" required>

                        <label for="proofAddress">Proof of Address (issued within 3 months) *</label>
                        <input type="file" id="proofAddress" name="proofAddress" required>

                        <label for="sourceFunds">Source of Funds *</label>
                        <input type="file" id="sourceFunds" name="sourceFunds" required>

                        <label for="annualVolume">Estimated Annual Transaction Volume (USD) *</label>
                        <input type="text" id="annualVolume" name="annualVolume" required>

                        <label for="accountReason">Reason for Account Opening *</label>
                        <textarea id="accountReason" name="accountReason" required></textarea>

                        <button type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>




        <div id="Modal2" class="modal2">
            <div class="modal2-content">
                <div class="modal2-header">
                    <h2>Liquidity Agreement</h2>
                    <span class="close-btn" onclick="closeModal2()">×</span>
                </div>
                <div class="modal2-body" id="agreement-content"
                    style="max-height: 500px; overflow-y: auto; padding: 10px;">
                    <!-- Agreement text will be inserted here -->
                </div>
                <h2>Signature:</h2>
                <canvas id="signature-pad" width="300" height="100" style="border: 1px solid #000;"></canvas>
                <br>
                <button class="btn" onclick="clearSignature()">Clear</button>
                <br><br>
                <button class="btn" onclick="submitAgreement()">Submit</button>
            </div>
        </div>


        <script>
            function completeKYC() {
                let kycStatus = document.getElementById("kyc-status");

                // Simulate KYC completion
                kycStatus.innerText = "Completed";
                kycStatus.style.color = "green";

                // Save KYC status in localStorage
                localStorage.setItem("kycStatus", "Completed");
            }

            let step2Button = document.getElementById("step2-btn");
            let step1Button = document.getElementById("kyc-btn");
            let kycStatusElement = document.getElementById("kyc-status");
            let agreementStatusElement = document.getElementById("agreement-status");

            // Function to update button states dynamically
            function updateButtonStates() {
                let kycStatus = kycStatusElement.innerText.trim();
                let agreementStatus = agreementStatusElement.innerText.trim();

                if (kycStatus === "Pending" && agreementStatus === "Pending") {
                    step2Button.disabled = true;
                    step1Button.disabled = false;
                }
                else if (kycStatus === "Completed" && agreementStatus === "Pending" || agreementStatus === "Processing") {
                    step1Button.disabled = true;
                    step2Button.disabled = false;
                }
                else if (kycStatus === "Completed" && agreementStatus === "Completed") {
                    step1Button.disabled = true;
                    step2Button.disabled = true;
                }
                else {
                    step1Button.disabled = false;
                    step2Button.disabled = true;
                }
            }

            // Observe changes in the KYC and Agreement status elements
            let observer = new MutationObserver(updateButtonStates);
            observer.observe(kycStatusElement, { childList: true, subtree: true });
            observer.observe(agreementStatusElement, { childList: true, subtree: true });

            // Run the function initially to set the correct state
            updateButtonStates();


            function checkKYCStatusOnLoad() {
                let savedKYCStatus = localStorage.getItem("kycStatus");
                let kycStatusSpan = document.getElementById("kyc-status");

                if (savedKYCStatus === "Completed") {
                    kycStatusSpan.innerText = "Completed";
                    kycStatusSpan.style.color = "green";
                }

                enableStep2Button();
            }

            window.onload = function () {
                checkKYCStatusOnLoad();

                // Start observing the KYC status text for changes
                observer.observe(document.getElementById("kyc-status"), { childList: true, subtree: true });

                // Attach event listener to the KYC button
                document.getElementById("kyc-btn").addEventListener("click", function () {
                    completeKYC();
                });
            };





            function openModal() {
                document.getElementById("usdtModal").style.display = "block";


            }








            function closeModal() {
                document.getElementById("usdtModal").style.display = "none";
            }

            /*function openModal2() {
                document.getElementById("Modal2").style.display = "block";


            }

            function closeModal2() {
                document.getElementById("Modal2").style.display = "none";
            }*/

        </script>



        <script>

            let signaturePad;

            window.onload = function () {
                const canvas = document.getElementById("signature-pad");
                signaturePad = new SignaturePad(canvas, {
                    backgroundColor: 'rgba(255, 255, 255, 0)', // Transparent background
                    penColor: 'black'
                });
            };

            function clearSignature() {
                signaturePad.clear();
            }

            function submitAgreement() {
                const canvas = document.getElementById("signature-pad");
                const signature = canvas.toDataURL("image/png");
                const content = document.getElementById("agreement-content").innerHTML;

                fetch("save_agreement.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ content, signature })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert("Agreement saved successfully!");
                            window.open(data.file, '_blank'); // Open PDF
                        } else {
                            alert("Something went wrong saving the agreement.");
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        alert("Error communicating with server.");
                    });
            }



            function openModal2() {
                document.getElementById("Modal2").style.display = "block";

                fetch("kyc_modal.php")
                    .then(res => res.json())
                    .then(user => {
                        const today = new Date().toLocaleDateString("en-GB");
                        const address = `${user.address1}, ${user.address2}, ${user.address3}`;

                        const agreementHTML = `
                        <!--<h1>Individual Liquidity Agreement</h1>-->                              
                        <p><strong>${today}</strong></p>
                        <p>Between</p> 
                        <p><strong>${user.full_name}</strong>, holder of Passport ID: <strong>${user.passport_id}</strong>, with the address of <strong>${address}</strong> ("Client")</p>
                        <p>ATLANTIC PARTNERS SPC FUND on behalf of the Atlantic Partners Asia Fund Segregated Portfolio, a company incorporated under the laws of Cayman Island (Company Number 270942), with its registered office at Willow House, Cricket Square, George Town, Grand Cayman KY1-1104, Cayman Islands (“APA”) </p>
                        <p> (together the Parties each a Party) </p>
                        <p>WHEREAS:</p>
                        <p>A. Client proposes to provide APA with short term liquidity in certain agreed jurisdictions and currencies, and APA shall repay these funds to Client on the terms and conditions contained in this Agreement.</p>
                        <p>B. The purpose of this Agreement is to establish parameters for the co-operation of the Parties on a best endeavours basis.</p>
                        <p>C. The Agreement does not modify or supersede any laws or regulatory requirements in force with regard to, or applying to, any of the Parties. </p>
                        <p>THEREFORE THE PARTIES AGREE AS FOLLOWS:  </p>
                        <p> 1. Definitions </p>
                        <p>               In this agreement, unless the context requires otherwise: 
APA Nominated Account has the meaning given in the Liquidity Request.  
Available Local Funds has the meaning given in the Liquidity Request.  
Business Day means a day that banks are open for business in Hong Kong.  
Commencement Date means the date of this agreement.  
Fees has the meaning given in the Liquidity Request.  
KYC Pack means APA’s standard application form as provided to the Client.  
Liquidity Request means the form contained in Schedule 1. 
Loss(es) means all liabilities, losses (including consequential, special or indirect damages, economic 
loss, loss of profits or opportunities), costs (on a full indemnity basis), expenses (including any legal 
expenses on a full indemnity basis) and damages arising directly or indirectly from or in relation with 
this agreement, including any liability for taxes (including value-added taxes) in respect of any of the 
foregoing.</p>

<p>Settlement Amount has the meaning given in the Liquidity Request. </p>
<p>Settlement Details has the meaning given in the Liquidity Request. </p>
<p>Transaction means a liquidity transaction under this Agreement. </p>
<h3> Confidentiality </h3>
<p>a) Each Party may or will provide the other Party with information that is not publicly known and that is 
confidential or proprietary in nature and shall include technical and financial information. Such 
information and any other information concerning the disclosing Party’s business affairs, or any 
negotiations taking place concerning the Transaction and the status of those discussions and 
negotiations, furnished to the receiving Party by the disclosing Party, whether in writing, orally or by any 
other means, are herein collectively referred to as the Confidential Information.. </p>

<p>b) The Confidential Information shall be kept strictly confidential and shall not without the prior written 
consent of the disclosing Party be disclosed, revealed or permitted to be disclosed or revealed in whole 
or in part to any person other than the receiving Party and its directors, officers, employees, advisors 
and representatives to whom it is necessary to reveal the Confidential Information for the purpose of 
this agreement, provided such persons are bound by confidentiality obligations substantially similar to 
the ones contained in this agreement. The receiving Party shall use its best endeavours to prevent 
disclosure of the Confidential Information and the fact that it has been disclosed to the disclosing Party. </p>
<p> c) The Confidential Information shall not be used for any purpose other than to identify, evaluate, develop, 
commercialise and advise on matters contemplated by this agreement. </p>
<p> d) The foregoing undertakings shall be continuing obligations and shall continue in full force and effect, 
provided that such undertakings shall not apply to such of the Confidential Information as:
    i) was lawfully in possession of the receiving Party prior to the execution of this agreement; or 
   ii)was already publicly known at the time of disclosure; or 
   iii) becomes publicly known other than by reason of breach of the undertakings contained in this agreement; or 
   iv) is properly received by the receiving Party from a third party who is, insofar as is known to the receiving Party after reasonable inquiry, rightfully in possession of it and is not bound by any obligation of confidence or secrecy to the disclosing Party; or
   v) is required to be disclosed by any law, governmental authority or agency, by the regulations of,or at the request of, any regulatory or supervisory authority having jurisdiction over the receiving Party, or by an order of any court of competent jurisdiction, provided that the receiving Party will notify the disclosing Party of such a disclosure requirement to the extent this is permitted under applicable law; or 
   vi) is disclosed with the prior written consent of the providing Party.  </p>
   <p> e) Any intellectual property provided by either Party shall remain the property of the disclosing Party. </p>
   <p>f) 
Any intellectual property produced jointly as a result of this agreement shall remain the property of 
both Parties and cannot be disclosed or assigned without the express written consent of both Parties. </p>
<p>g) The obligations of confidentiality contained in this clause shall also apply and extend to any directors, 
officers, employees, agents, professional advisors, consultants and third party agents of each Party 
(together the Affiliates), and each Party shall be obliged to ensure their Affiliates’ compliance with this 
clause. Each Party shall have recourse directly to the other Party in respect of any breach of 
confidentiality or compliance with this agreement by the other Party’s Affiliates. </p>
</p>
<p>h) No Party shall make, or permit any person to make, any public announcement concerning this 
agreement without the prior written consent of the other Party, except as required by law. </p>
<p>i) 
For the avoidance of doubt, the provisions of this clause 1 shall survive any termination of this 
agreement. </p>

<h3>Transaction process </h3>
<p>a) The Parties agree that each Transaction shall be completed as follows: 
i)Following discussions between APA and Client, and upon the KYC Pack being been verified by APA, 
APA and Client shall agree upon the Liquidity Request, or confirm a similar arrangement with all 
material terms agreed via other electronic means. 
ii)Following completion of clause 2(a)(i), Client shall remit the Available Local Funds to the APA 
Nominated Account via electronic funds transfer or as otherwise agreed. Client shall provide APA 
with a copy of the remittance or transfer receipt immediately thereafter. 
iii) Upon receipt by and availability of the Available Local Funds to APA, APA shall proceed to facilitate 
the settlement of the Settlement Amount in accordance with the Settlement Details. 
iv) The Settlement Amount will be remitted to the nominated account(s) of Client as specified in the 
Settlement Details, and APA shall provide Client with a copy of the remittance or transfer receipt 
immediately upon processing. APA may conduct such settlement in its own capacity, via 
regulated providers, or other partner entities, in its discretion. 
v) APA shall otherwise provide any and all necessary transactional support to facilitate the 
successful completion of the Transaction. 
vi) The Parties acknowledges that where any Transaction is concluded, the Fees shall be deducted 
by APA in accordance with the Transaction Terms. </p>
<p>b) Each Party shall be responsible for its own costs and expenses with relation to any Transaction and this 
agreement. </p>
<h3>Communication and Dealings </h3>
<p>a) Each Party agrees that without the prior consent of the other Party, they shall not: 
i) 
ii) 
independently undertake any Transaction contemplated by this agreement (either directly or 
indirectly) other than with each other; 
negotiate or enter into an agreement with any person or company introduced by one Party in 
relation to all or part of any Transaction contemplated by this agreement (Introduced Person); 
or 
iii) accept any direct or indirect benefit from another person in respect of all or part of any 
Transaction contemplated by this agreement, or in return for another person entering into 
dealings with any Introduced Person.</p>
<p>b) Each Party shall exercise its powers and perform its duties, functions and obligations under this 
agreement or any future agreement with all reasonable professional care and diligence, in good faith, 
with fairness, honesty and efficiency and in accordance with all applicable laws.</p>
<h3>Acknowledgements</h3>
<p>a) Each Party will be responsible for obtaining its own professional advice on legal, accounting, taxation 
and any other matters pertaining to this agreement or a Transaction. </p>
<p>b) Each Party accepts and acknowledges that it is aware of, fully understands and shall assume all risks 
involved in relation to a Transaction, including market risks, regulatory risks and the impact of prevailing 
market conditions. </p>
<p>c) No representation or warranty is or can be made as to the economic return that may accrue to a Party 
as a result of this agreement. Neither Party in any way warrants or represents that successful 
completion of the process contemplated by this agreement will be achieved. The Parties will, however, 
use their best endeavours to undertake the Transaction and obtain the best possible outcome for each 
other in accordance with this agreement.</p>
<p>d) Each Party represents and warrants to the other Party: 
i) that is validly existing and in good standing in the jurisdictions in which it is incorporated; 
ii) that it is in compliance with all relevant laws and regulations related to any Transaction 
contemplated herein, including but not necessarily limited to the laws of the governing 
jurisdiction; and 
iii) that the KYC Pack shall at all times be valid and up to date for the duration of the term of this 
agreement. 
iv) The Client acknowledges that any Transaction including the Funds subject of any Transaction 
may be restricted, suspended, confiscated or withheld permanently or indefinitely by law 
enforcement or other regulatory or government agency, and that APA has no liability for such 
action. </p>
<p>Commencement and Termination </p>
  <p>a) This agreement will take effect on the date it has been duly executed by both Parties and shall continue 
in full force and effect until the earlier of 2 years, or termination in accordance with this clause. </p>
<p> b) Without affecting any other right or remedy available to it, either Party may terminate this agreement 
with immediate effect by giving written notice to the other Party if the other Party: 
i)commits a material breach of any term of this agreement and such breach is irremediable or (if 
such breach is remediable) fails to remedy that breach within a period of 30 days after being 
notified in writing to do so; 
ii)repeatedly breaches any of the terms of this agreement in such a manner as to reasonably justify 
the opinion that its conduct is inconsistent with it having the intention or ability to give effect to 
the terms of this agreement; 
iii) goes into liquidation or insolvency (or any analogous procedure), whether compulsory or 
voluntary; 
iv) has an administrator or receiver and manager or judicial manager or similar officer appointed 
over any part of its assets; 
v) becomes insolvent or is unable to pay its debts or admits in writing its inability to pay its debts as 
they fall due or enters into any composition or arrangement with its creditors or makes a general 
assignment for the benefit of its creditors; 
vi) ceases or threatens to cease to carry on the whole or any substantial part of its business other 
than in the course of reconstruction or amalgamation; 
vii) sells, transfers, leases or otherwise disposes of the whole or substantially the whole of its assets, 
rights and undertaking either pursuant to a court order for compulsory acquisition or otherwise; 
or 
viii) suffers any distress, execution, sequestration or other process being levied or enforced upon its 
property, pursuant to a law suit or otherwise, which is not discharged within 5 days.</p>
<p> c) Either Party may terminate this agreement at any time upon 15 Business Days’ written notice to the 
other Party. </p>
<p> d) Termination of this agreement shall not affect any rights, remedies, obligations or liabilities of the 
Parties that have accrued up to the date of termination.</p>
<h3> Limitation of Liability and Indemnity </h3>
<p>a) This clause 6 applies to the maximum extent permitted by law and sets out, and the Parties accept, 
the limitations which apply to one Party’s liability to the other Party, should either a Party or any other 
person have reason to make a claim against a Party. The limitations and exclusions are accepted by 
the Parties to be fair and reasonable. </p>
<p>b) The Parties agree: 
i)to indemnify and hold harmless each other against; and 
ii)that a Party shall not have any liability to another Party in relation to,  
any Losses, however caused, arising directly or indirectly from or in connection with the activities 
contemplated in this agreement.</p>
<p>c) If any of the limitations of liability and indemnities set out in this agreement are not effective, do not 
apply or are not available to a Party (for any reason whatsoever), the Parties agree that the maximum 
liability of one Party to another Party for Losses will not exceed US$1,000, except that there should be no 
limit in the event of gross negligence, fraud or misconduct of the either Party.</p>
<p>d) Nothing in this agreement excludes, restricts or modifies the application of the provisions of any statute 
where to do so would contravene that statute or cause any part of the agreement to be void.</p>
<p>e) In the event that a Transaction or Funds are restricted, suspended, confiscated or withheld 
permanently or indefinitely or otherwise subject to any similar restrictive action by a financial 
institution, governmental authority, law enforcement agency, or any other entity possessing judicial or 
lawful authority over the funds or the Transaction, APA and any of its affiliates, subsidiaries, or related 
entities shall bear no liability or responsibility for the completion of the Transaction or Losses arising 
therefrom. </p>
<h3>Notices</h3>
<p>a) All notices and communications to either Party under this agreement shall be made in writing and by 
means of registered mail (or courier) or email with acknowledgment of receipt and shall be deemed 
given on the date of the respective receipt, to the following addresses: 
APA: 
Atlantic Partners Asia 
Email: compliance@atlanticpartnersasia.com  </p>
<p>b) All notices should also be sent by email to the relevant email address as indicated above.</p>
<h3> Consultation and Disputes </h3>
<p>a) The Parties will keep the operation of this agreement under review and will consult when necessary: 
i)in the event of a dispute over the meaning of any term used in the agreement; 
ii)in the event of a substantial change in the laws, regulations or practices affecting the operation 
of the agreement; 
iii) in the event of any Party proposing to withdraw from the agreement; and 
iv) whenever necessary, with a view to improving its operation and resolving any matters.</p>
<p>b) Any dispute, controversy or claim arising out of, or relating to, this agreement including any dispute 
regarding its existence, its validity or termination (Dispute) shall in the first instance be submitted to 
one senior representative appointed by each Party, who will meet to discuss a resolution to the Dispute 
within 5 Business Days of a dispute notice being filed in writing.</p>
<p>c) If the appointed senior representatives are unable to resolve the Dispute within 10 Business Days of a 
dispute notice being filed, the Dispute shall be referred to and finally resolved by arbitration 
administered by the Singapore International Arbitration Centre (“SIAC”) in accordance with the 
Arbitration Rules of the Singapore International Arbitration Centre ("SIAC Rules") for the time being in 
force, which rules are deemed to be incorporated by reference in this clause.</p>
<p>d) The Parties acknowledge and agree that they:  
i) may be irreparably harmed by the breach of the terms of this agreement and damages may not 
be an adequate remedy; 
ii)may be granted an injunction or specific performance for any threatened or actual breach of the 
provisions of this agreement by a Party; and 
iii) may apply to the courts in any relevant jurisdiction in order to seek injunctive relief to enforce (or 
to prevent a breach of) any of their rights pursuant to this agreement.</p>
<h3>General</h3>
<p>a) The Parties agree and understand that the basis of their respective understanding contained herein is 
and will be subject to all applicable laws, rules and regulations as may be applicable from time to time. 
Each Party shall at its own expense comply with all laws and regulations relating to its activities under 
this agreement, as they may change from time to time, and with any conditions binding on it in any 
applicable licences, registrations, permits and approvals.</p>
<p>b) This document contains the entire agreement between the Parties and neither Party shall be bound by 
any undertaking, representation or warranty not recorded herein or added hereto as provided herein. </p>
<p>c) Any amendment, alteration or variation of this agreement, including this provision itself, is not effective 
unless it is in writing and signed by both Parties.</p>
<p>d) Waiver of any right, power, authority, discretion or remedy arising from a breach of this agreement must 
be in writing and signed by the Party granting the waiver. A failure or delay in exercise, or partial exercise, 
of a right, power, authority, discretion or remedy created or arising from a breach of this agreement 
does not result in a waiver of that right, power, authority, discretion or remedy.</p>
<p>e) If any clause or term of this agreement should be invalid, unenforceable or illegal, then the remaining 
terms and provisions of this agreement shall be deemed to be severable therefrom and shall continue 
in full force and effect unless such invalidity, unenforceability or illegality goes to the root of this 
agreement.</p>
<p>f) 
This agreement may be executed in counterparts. Each counterpart is an original but the counterparts 
together are one and the same agreement. </p>
<p>g) This agreement is governed by and shall be construed and enforced in accordance with the laws of 
Hong Kong. The Parties submit to the non-exclusive jurisdiction of the courts there.</p>
<p>EXECUTED on behalf of 
ATLANTIC PARTNERS SPC 
FUND by </p>








        <!-- Include all other HTML-converted agreement content here -->
        <p><strong>Signed by:</strong><br>${user.full_name}<br>${today}</p>
      `;

                        document.getElementById("agreement-content").innerHTML = agreementHTML;
                    });
            }

            function closeModal2() {
                document.getElementById("Modal2").style.display = "none";
            }

            function clearSignature() {
                const canvas = document.getElementById("signature-pad");
                const ctx = canvas.getContext("2d");
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }

            function submitAgreement() {
                const canvas = document.getElementById("signature-pad");
                const signature = canvas.toDataURL("image/png");
                const content = document.getElementById("agreement-content").innerHTML;

                fetch("save_agreement.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ content, signature })
                })
                    .then(res => res.text())
                    .then(response => {
                        alert(response);
                        document.getElementById("agreement-status").innerText = "Completed";
                        closeModal2();
                    });
            }
        </script>

        <script>
            const canvas = document.getElementById("signature-pad");
            const signatureData = document.getElementById("signature-data");
            const ctx = canvas.getContext("2d");

            let drawing = false;

            // Mouse Events
            canvas.addEventListener("mousedown", (e) => {
                drawing = true;
                ctx.beginPath();
                ctx.moveTo(e.offsetX, e.offsetY);
            });

            canvas.addEventListener("mousemove", (e) => {
                if (drawing) {
                    ctx.lineTo(e.offsetX, e.offsetY);
                    ctx.stroke();
                }
            });

            canvas.addEventListener("mouseup", () => {
                drawing = false;
                signatureData.value = canvas.toDataURL(); // Save signature
            });

            canvas.addEventListener("mouseout", () => {
                drawing = false;
            });

            // Touch Events (for mobile)
            canvas.addEventListener("touchstart", (e) => {
                e.preventDefault();
                const rect = canvas.getBoundingClientRect();
                const touch = e.touches[0];
                const x = touch.clientX - rect.left;
                const y = touch.clientY - rect.top;
                drawing = true;
                ctx.beginPath();
                ctx.moveTo(x, y);
            });

            canvas.addEventListener("touchmove", (e) => {
                e.preventDefault();
                if (drawing) {
                    const rect = canvas.getBoundingClientRect();
                    const touch = e.touches[0];
                    const x = touch.clientX - rect.left;
                    const y = touch.clientY - rect.top;
                    ctx.lineTo(x, y);
                    ctx.stroke();
                }
            });

            canvas.addEventListener("touchend", () => {
                drawing = false;
                signatureData.value = canvas.toDataURL(); // Save signature
            });

            function clearSignature() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                signatureData.value = '';
            }
        </script>





        <script>
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                event.preventDefault();

                let formData = new FormData(this);

                fetch("kyc_submit.php", {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);
                    })
                    .catch(error => console.error("Error:", error));
            });
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                event.preventDefault();

                // Prevent default submission (if using AJAX)

                // Simulating successful submission (replace with actual AJAX call if needed)
                setTimeout(() => {
                    //alert("Form submitted successfully!");
                    closeModal(); // Close modal after submission
                }, 500); // Simulating slight delay


            });
        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                function getStatusColor(status) {
                    switch (status) {
                        case 'completed': return 'green';
                        case 'failed': return 'red';
                        case 'Processing': return 'orange';
                        default: return 'orange'; // Pending
                    }
                }

                function updateKycStatus() {
                    fetch("auto_update.php", {
                        method: "GET"
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status !== "unauthorized") {
                                let statusElement = document.getElementById("kyc-status");
                                statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                statusElement.style.color = getStatusColor(data.status);
                            }
                        })
                        .catch(error => console.error("Error fetching KYC status:", error));
                }

                // Fetch status every 5 seconds
                setInterval(updateKycStatus, 5000);
                updateKycStatus(); // Fetch immediately on page load
            });
        </script>
        <script>

            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                event.preventDefault();

                setTimeout(() => {
                    //alert("Form submitted successfully!");
                    closeModal2(); // Close modal after submission
                }, 500); // Simulating slight delay


            });
            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                event.preventDefault(); // Prevent default form submission

                let formData = new FormData(this);

                fetch("upload_agreements.php", {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);
                        //closeModal2(); // Close modal after successful submission
                    })
                    .catch(error => console.error("Error:", error));



            });




        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                function getStatusColor(status) {
                    switch (status) {
                        case 'completed': return 'green';
                        case 'failed': return 'red';
                        case 'processing': return 'orange';
                        default: return 'orange'; // Pending
                    }
                }

                function updateAgreementStatus() {
                    fetch("check_status.php", {
                        method: "GET"
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status !== "unauthorized") {
                                let statusElement = document.getElementById("agreement-status");
                                statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                statusElement.style.color = getStatusColor(data.status);
                            }
                        })
                        .catch(error => console.error("Error fetching agreement status:", error));
                }

                // Fetch status every 5 seconds
                setInterval(updateAgreementStatus, 5000);
                updateAgreementStatus(); // Fetch immediately on page load
            });
        </script>



</body><!-- End of .page_wrapper -->

</html>