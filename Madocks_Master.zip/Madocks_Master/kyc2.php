<?php
session_start();
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <style>
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            z-index: 1000;
            /* Ensure it's above everything else */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            /* Dark overlay */
            overflow-y: auto;
            /* Allow scrolling within the modal */
        }

        /* Prevent background from scrolling when modal is open */
        body.modal-open {
            overflow: hidden;
        }


        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }

        .close-btn {
            cursor: pointer;
            font-size: 24px;
        }

        .modal-body {
            padding: 20px 0;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input,
        select textarea {

            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;

        }






        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .clicked {
            background-color: #28a745 !important;
            /* Green color to indicate success */
            transform: scale(0.95);
        }

        .reference-code {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .circle {
            width: 200px;
            height: 200px;
            background: white;
            border-radius: 50%;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            position: relative;
        }

        .circle span {
            color: #007bff;
        }

        .options {
            color: black;
            display: flex;
            flex-direction: column;
            gap: 30px;
            margin-left: 80px;
        }

        .option {
            color: black;
            display: flex;
            align-items: center;
            background: white;
            padding: 15px;
            border-radius: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            justify-content: space-between;
            position: relative;
        }

        .icon {
            width: 40px;
            height: 40px;
            background: #f0f8ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
        }

        .text {
            text-align: left;
            flex: 1;
        }

        .text h3 {
            margin: 0;
            font-size: 16px;
            color: #007bff;
        }

        .text p {
            margin: 5px 0 0;
            font-size: 14px;
            color: #555;
        }

        .btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .modaldeposit {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modaldeposit-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modaldeposit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        input[type="file"],
        input[type="text"] {
            display: block;
            margin: 10px 0;
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }


        .modal2 {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal2-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal2-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modal2-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .reference-code2 {
            font-weight: bold;
            color: black;
            font-size: 16px;
            margin-top: 10px;
            text-align: left;
        }

        .btn:disabled {
            background: gray;
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>

    <style>
        /* Base Styles */
        .reference-code strong {
            font-size: 16px;
            color: #2c3e50;
            display: block;
            margin-bottom: 20px;
        }

        /* Tooltip styling */
        .tooltip-icon {
            display: inline-block;
            margin-left: 8px;
            background-color: #4a90e2;
            color: white;
            font-size: 12px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            text-align: center;
            line-height: 20px;
            position: relative;
            cursor: pointer;
        }

        .tooltip-text {
            visibility: hidden;
            width: 250px;
            background-color: #333;
            color: #fff;
            text-align: left;
            padding: 10px;
            border-radius: 6px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            /* Position above icon */
            left: 50%;
            margin-left: -125px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 13px;
        }

        .tooltip-icon:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }

        h2 {
            color: #007aa3;
            font-size: 14px;
            text-transform: uppercase;
        }

        p,
        li {
            font-size: 12px;
            line-height: 1.6;
        }

        ul {
            padding-left: 20px;
        }

        .section {
            margin-bottom: 20px;
        }

        .form-group {
            margin: 10px 0;
        }

        label {
            margin-top: 10px;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 6px;
            font-size: 12px;
        }

        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            align-items: center;
        }

        .checkbox input {
            height: 1em;
            width: 1em;
            vertical-align: middle;
        } 

        button {
            padding: 8px 16px;
            background-color: #007aa3;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #005f7a;
        }

        #signature-pad {
            border: 1px solid #ccc;
            width: 100%;
            height: 150px;
            cursor: crosshair;
        }

        .clear-button {
            margin-top: 5px;
            background-color: #999;
        }

        .checkbox label {
            cursor: pointer;
        }
    </style>



</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!---<div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>--->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
    <div class="popup-inner">
        <div class="upper-box clearfix">
            <figure class="logo-box pull-left"><a href="new_index.php"><img src="assets/images/logonew.png"
                        alt=""></a></figure>
            <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <div class="overlay-layer"></div>
        <div class="auto-container">
            <div class="search-form">
                <form method="post" action="new_index.php">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value=""
                                placeholder="Type your keyword and hit" required>
                            <button type="submit"><i class="flaticon-loupe"></i></button>
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                    Us</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                                <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="new_index.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                            <a href="logout.php">Logout</a>
                        </li>
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                            <a href="register.php">Signup</a>
                        </li>
                    </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="new_index.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="current dropdown"><a href="new_index.php">Home</a>
                                            <!---<ul>
                                        <li><a href="new_index.php">Home One</a></li>
                                        <li><a href="new_index.php">Home Two</a></li>
                                        <li><a href="new_index.php">Home Three</a></li>
                                    </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                        <li><a href="marketsl.php">Markets</a></li>
                                        <li><a href="market-details.html">Details Page</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                        <li><a href="platform.php">Platform</a></li>
                                        <li><a href="account.html">Our Accounts</a></li>
                                        <li><a href="account-details.html">Standard Account</a></li>
                                        <li><a href="account-details-2.html">Commision Account</a></li>
                                        <li><a href="account-details-3.html">STP Pro Account</a></li>
                                    </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="new_index.php">Education</a>
                                    <ul>
                                        <li><a href="education.html">Education</a></li>
                                        <li><a href="education-details.html">Detail Page</a></li>
                                    </ul>
                                </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                        <li><a href="about.html">Company</a></li>
                                        <li><a href="history.html">History</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li class="dropdown"><a href="new_index.php">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">3 Columns</a></li>
                                                <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                <li><a href="blog-3.html">List View 01</a></li>
                                                <li><a href="blog-4.html">List View 02</a></li>
                                                <li><a href="blog-details.html">Single Post</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                        <li><a href="faq.html">Faq’s</a></li>
                                        <li><a href="error.html">404</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="dropdown"><a href="USDT_main_page_change.php">USDT</a>

                                        </li>
                                        <!--<li class="dropdown"><a href="sneat/html/index.html">Dashboard</a> </li>-->
                                    </ul>
                                </div>
                            </nav>
                            <!--<div class="menu-right-content">

                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="" class="theme-btn btn-one">
                                
                            </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                            <!--<div class="menu-right-content">
                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                                



                         </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="new_index.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="new_index.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                Here</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="new_index.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- banner-style-three -->
        <section class="banner-style-three centred">

            <div class="container">
                <!-- Circular Infographic -->
                <div class="circle">
                    KYC <br> <span></span>
                </div>

                <!-- Connecting Lines -->
                <div class="line-container">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>

                <!-- Option Boxes -->
                <div class="options">
                    <!-- Option A -->
                    <div class="option">
                        <div class="icon">👤</div>
                        <div class="text">
                            <h3>Step1: KYC submission</h3>
                            <p>Status: <span id="kyc-status" style="color: orange;">Pending</span></p>
                        </div>
                        <button class="btn" id="kyc-btn" onclick="openModal()">Select</button>
                    </div>

                    <!-- Option B -->
                    <div class="option">
                        <div class="icon">🎫</div>
                        <div class="text">
                            <h3>Step2: Liquidity agreement</h3>
                            <p>Status: <span id="agreement-status" style="color: orange;">Pending</span> </p>

                        </div>
                        <button class="btn" id="step2-btn" onclick="openModal2()" disabled>Select</button>
                    </div>



                </div>
            </div>

        </section>


        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode();
            });

            function generateReferenceCode() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });

        </script>

        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode2();
            });

            function generateReferenceCode2() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay2").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode2").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode2").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });
        </script>

        <div id="usdtModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>USDT Onboarding</h2>
                    <span class="close-btn" onclick="closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <h3>KYC APPLICATION</h3>
                    <h4>INDIVIDUAL DETAILS</h4>

                    <form id="usdtOnboardingForm">
                        <div class="reference-code">
                            <strong id="referenceCodeDisplay"></strong>
                        </div>
                        <input type="hidden" id="referenceCode" name="referenceCode">

                        <label for="apaEmployee">Name of the MADOCKS employee spoken to</label>
                        <input type="text" id="apaEmployee" name="apaEmployee">

                        <label for="fullName">Full Name as per Passport/ID *</label>
                        <input type="text" id="fullName" name="fullName" required>

                        <label for="dob">Date of Birth *</label>
                        <input type="text" id="dob" name="dob" placeholder="DDMMYYYY" required>

                        <label for="nationality">Nationality *</label>
                        <select id="nationality" name="nationality" required>
                            <option value="">Select Country</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                            <option value="UK">United Kingdom</option>
                        </select>

                        <label for="address1">Address Line 1 *</label>
                        <input type="text" id="address1" name="address1" required>

                        <label for="address2">Address Line 2</label>
                        <input type="text" id="address2" name="address2">

                        <label for="address3">Address Line 3</label>
                        <input type="text" id="address3" name="address3">

                        <label for="postcode">Postcode *</label>
                        <input type="text" id="postcode" name="postcode" required>

                        <label for="mobile">Mobile Number *</label>
                        <input type="text" id="mobile" name="mobile" required>

                        <label for="passportId">Passport/ID Number *</label>
                        <input type="text" id="passportId" name="passportId" required>

                        <label for="country">Country *</label>
                        <select id="country" name="country" required>
                            <option value="">Select Country</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                            <option value="UK">United Kingdom</option>
                        </select>

                        <label for="occupation">Occupation *</label>
                        <input type="text" id="occupation" name="occupation" required>

                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required>

                        <label for="currencies">Currencies Required *</label>
                        <input type="text" id="currencies" name="currencies" required>

                        <label for="sourceWealth">
                            Source of Wealth *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Proof of how client makes money:<br>
                                    • Employment Letter<br>
                                    • Pay slips<br>
                                    • Sale and Purchase agreement<br>
                                    • Investment portfolio<br>
                                    • Inheritance<br>
                                    • Gift letter
                                </span>
                            </span>
                        </label>
                        <input type="file" id="sourceWealth" name="sourceWealth" required>

                        <label for="proofIdentity">
                            Proof of Identity *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Government issued ID:<br>
                                    • Passport<br>
                                    • Valid driver's licence<br>
                                    • NRIC
                                </span>
                            </span>
                        </label>
                        <input type="file" id="proofIdentity" name="proofIdentity" required>

                        <label for="proofAddress">
                            Proof of Address (issued within 3 months) *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Dated within last 3 months:<br>
                                    • Bank statements<br>
                                    • Utility bills<br>
                                    • Driver's license / NRIC<br>
                                    • Signed tenancy agreement (within 1 year)<br>
                                    • Mortgage loan statement
                                </span>
                            </span>
                        </label>
                        <input type="file" id="proofAddress" name="proofAddress" required>

                        <label for="sourceFunds">
                            Source of Funds *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Proof to show client can afford trades:<br>
                                    • Bank statements showing sufficient balance
                                </span>
                            </span>
                        </label>
                        <input type="file" id="sourceFunds" name="sourceFunds" required>

                        <label for="annualVolume">Estimated Annual Transaction Volume (USD) *</label>
                        <input type="text" id="annualVolume" name="annualVolume" required>

                        <label for="accountReason">Reason for Account Opening *</label>
                        <textarea id="accountReason" name="accountReason" required></textarea>

                        <h2>Confirmation and Submission 确认和提交</h2>
                        <p>By submitting this form to the APA Group, you confirm and agree:</p>

                        <div class="section1">
                            <ol>
                                <li>This Individual Application form, together with the Terms and Conditions (the
                                    “Terms”) and the Supplemental Terms and Conditions (as applicable) (the
                                    “Supplemental Terms”), comprise the entire agreement between the Company and the APA
                                    Group related to the Services (the “Agreement”). This Agreement is entered into by
                                    and between the Individual and APA Canada Tech Limited, a company incorporated under
                                    the laws of the Province of Alberta, Canada (Individual Access Number 2025006178)
                                    with its registered address of 428-1001 1st Street SE, Calgary, Alberta, T2G 5G3,
                                    Canada, which is registered as an MSB in Canada with the Financial Transactions and
                                    Reports Analysis Centre of Canada (Canadian MSB Registration Number M23328908)
                                    (“APA”). You acknowledge that APA may engage other companies within the APA Group to
                                    perform services under this agreement. For the purposes of this Agreement, the “APA
                                    Group” shall refer to APA and its’ affiliates, including: (i) Atlantic Partners Asia
                                    (SG) Pte Limited, a company incorporated in Singapore (Company Number 201841045G)
                                    with its registered office at 7A Stanley Street, Singapore 068726 (Major Payment
                                    Institute License No. 20200516), (ii) Atlantic Partners Asia PS Limited, a company
                                    incorporated in Hong Kong SAR (Company Number 2816539) with its registered office at
                                    Flat/RM 2005 20/F Kinwick Centre 31 Hollywood Road Mid-Levels Central, Hong Kong,
                                    which holds an MSO License in Hong Kong (License No. 20-12-02993), (iii) Atlantic
                                    Partners Asia (MY) SDN BHD, a company incorporated in Malaysia (Company Number
                                    202201040529 (1486226X) with its registered address at Unit 25-13, Q Sentral, Jalan
                                    Stesen Sentral 2, KL Sentral, 50470 W.P. Kuala Lumpur, Malaysia, (iv) Atlantic
                                    Partners Asia Management (Cayman) Limited, a company incorporated in the Cayman
                                    Islands (Company Number 270943) with its registered address at Floor 4, Willow
                                    House, Cricket Square, Grand Cayman KYl-9010, Cayman Islands, (v) Atlantic Partners
                                    Asia Canada Limited, a company incorporated under the laws of the Province of
                                    Ontario, Canada (Ontario Corporation Number 1000612208), with a registered address
                                    of 120 Adelaide Street West, Suite 2500, Toronto, Ontario, M5H 1T1, Canada (Canadian
                                    MSB Registration Number M23484752), (vi) Redbanx Limited, a company incorporated in
                                    England and Wales (Company Number 10452111) with its registered address at 11
                                    Woodford Avenue, Ilford, England, IG2 6UF, which holds a UK EMI License (License No.
                                    900897), (vii) Atlantic Partners Africa (Pty) Ltd, a company incorporated in South
                                    Africa (Company Number K2019340083) with its registered address at Office 09, 1st
                                    Floor, 35 Ferguson, 35 Ferguson Road, Illovo, Johannesburg, 2196, Gauteng, South
                                    Africa, which holds an FSP (Financial Services Provider) Category II (Discretionary)
                                    License (License No: 36823), and (viii) Atlantic Partners Asia PS Pty Ltd, a company
                                    incorporated in New South Wales (Company Number 633 838 481) with its registered
                                    address at 10.02, Level 10, 109 Pitt Street, Sydney, NSW, 2000, Australia.

                                    本個人申請表格連同條款和條件（以下稱為「條款」）及補充條款和條件（如適用，以下稱為「補充條款」）構成公司與APA集團之間關於服務的完整協議（以下稱為「協議」）。本協議由您與APA
                                    Canada Tech Limited簽訂，該公司依據加拿大阿爾伯塔省法律成立（公司註冊號碼2025006178），其註冊地址為428-1001 1st Street
                                    SE, Calgary, Alberta, T2G 5G3,
                                    Canada，並且在加拿大於金融交易和報告分析中心登記為MSB（加拿大MSB註冊號碼M23328908）（以下稱為「APA」）。您承認APA可以聘用APA集團內的其他公司來執行本協議下的服務。根據本協議，「APA集團」指APA及其附屬公司，包括：（i）Atlantic
                                    Partners Asia (SG) Pte Limited，該公司在新加坡成立（公司編號201841045G），註冊辦公地址為7A Stanley Street,
                                    Singapore 068726（主要支付機構許可證號碼20200516），（ii）Atlantic Partners Asia PS
                                    Limited，該公司在香港特別行政區成立（公司編號2816539），註冊辦公地址為Flat/RM 2005 20/F Kinwick Centre 31
                                    Hollywood Road Mid-Levels Central, Hong
                                    Kong，持有香港MSO許可證（許可證號碼20-12-02993），（iii）Atlantic Partners Asia (MY) SDN
                                    BHD，該公司在馬來西亞成立（公司編號202201040529 (1486226X)），註冊地址為Unit 25-13, Q Sentral, Jalan Stesen
                                    Sentral 2, KL Sentral, 50470 W.P. Kuala Lumpur, Malaysia，（iv）Atlantic Partners Asia
                                    Management (Cayman) Limited，該公司在開曼群島成立（公司編號270943），註冊地址為Floor 4, Willow House,
                                    Cricket Square, Grand Cayman KY1-9010, Cayman Islands，（v）Atlantic Partners Asia
                                    Canada Limited，該公司依據加拿大安大略省法律成立（安大略省公司編號1000612208），註冊地址為120 Adelaide Street West,
                                    Suite 2500, Toronto, Ontario, M5H 1T1, Canada（加拿大MSB註冊號碼M23484752），（vi）Redbanx
                                    Limited，該公司在英格蘭和威爾士成立（公司編號10452111），註冊地址為11 Woodford Avenue, Ilford, England, IG2
                                    6UF，持有英國EMI許可證（許可證號碼900897），（vii）Atlantic Partners Africa (Pty)
                                    Ltd，該公司在南非成立（公司編號K2019340083），註冊地址為Office 09, 1st Floor, 35 Ferguson, 35 Ferguson
                                    Road, Illovo, Johannesburg, 2196, Gauteng, South
                                    Africa，持有FSP（金融服務提供者）第二類（自主）許可證（許可證號碼36823），以及（viii）Atlantic Partners Asia PS Pty
                                    Ltd，該公司在新南威爾士州成立（公司編號633 838 481），註冊地址為10.02, Level 10, 109 Pitt Street, Sydney,
                                    NSW, 2000, Australia。</li>
                                <li>References in this Agreement to “you”, “your”, “yours” and “Client” are to you, the
                                    customer of APA.

                                    本協議中提及的「您」、「您的」、「屬於您的」及「客戶」均指您，即APA的客戶。</li>
                                <li>In this Agreement, you and the APA Group are referred to jointly as the Parties and
                                    each a Party in the singular.

                                    在本協議中，您和APA集團共同被稱為「各方」，單數形式則稱為「一方」。</li>
                                <li>Notwithstanding any other authorization or instruction provided by you to the APA
                                    Group, the APA Group is authorized to act on the authorizations or instructions
                                    provided in this form without further checks, even if the authorizations or
                                    instructions may contradict any other instructions provided by you to the APA Group.

                                    儘管您向APA集團提供了其他授權或指示，APA集團獲授權根據本表格中提供的授權或指示行事，而無需進一步檢查，即使該授權或指示可能與您向APA集團提供的其他指示相抵觸。
                                </li>
                                <li>You have read and understood the APA Group’s prevailing Terms and Supplemental Terms
                                    (as applicable), a copy of which has been provided to you, and you agree to be bound
                                    by all the terms therein and any amendments or variation thereof. You further agree
                                    and acknowledge that there are other terms and conditions and agreement(s) intended
                                    or expressed to govern the use of other relevant products and services offered by
                                    APA and you confirm your agreement and acceptance of the same, including but not
                                    necessarily limited to the Supplemental Terms (as applicable). We reserve the right
                                    to amend, remove, or add to this Agreement, the Terms and Supplemental Terms (as
                                    applicable) at any time, and from time to time, in our sole discretion. Your use of
                                    any product or service after the posting of modifications to this Agreement, the
                                    Terms and Supplemental Terms (as applicable) constitutes your acceptance of this
                                    Agreement, as modified. A copy of APA’s prevailing Terms and Supplemental Terms (as
                                    applicable) and can be obtained upon request.

                                    您已閱讀並理解APA集團的現行條款及補充條款（如適用），並已提供給您副本，您同意遵守其中的所有條款及其任何修訂或變更。您進一步同意並承認，還有其他條款及條件和協議旨在或明示用以管理APA提供的其他相關產品及服務的使用，您確認對此的協議和接受，包括但不限於補充條款（如適用）。我們保留隨時自行決定修訂、刪除或新增本協議、條款及補充條款（如適用）的權利。您在本協議、條款及補充條款（如適用）修訂後使用任何產品或服務，即表示您接受本協議的修改版本。APA的現行條款及補充條款（如適用）的副本可應要求獲得。
                                </li>

                                <li>You may provide personal information to APA in connection with your establishing and
                                    maintaining your relationship with the APA Group. You confirm that all information
                                    provided, and documents submitted by you are true, complete and accurate and that
                                    you have consent and authority to share such information with us. When providing any
                                    personal information to the APA Group, you confirm that you are lawfully providing
                                    the data for the APA Group to use and disclose for the purposes of:

                                    您可能會向APA提供個人信息，以建立和維持與APA集團的關係。您確認所有提供的信息和提交的文件均為真實、完整和準確的，並且您擁有分享該信息的同意和授權。當您向APA集團提供任何個人信息時，您確認您合法地提供該數據，以便APA集團使用和披露，目的包括：
                                    <ul>
                                        <li>providing products or services to you;

                                            向您提供產品或服務；</li>
                                        <li>managing the operational, administrative and risk management requirements
                                        </li>
                                        <li>meeting the operational, administrative and risk management requirements of
                                            the APA Group; and

                                            滿足APA集團的運營、行政和風險管理要求；以及</li>
                                        <li>complying with any requirement, as APA Group reasonably deems necessary,
                                            under any law or of any court, government authority or regulator

                                            遵守APA集團合理認為根據任何法律或任何法院、政府機構或監管機構的要求所需的任何要求。</li>
                                    </ul>
                                </li>
                                <li>All of your personal information will be collected by us in accordance [with the
                                    above and not for any other purpose without your express consent /OR/ the Privacy
                                    Policy at [link]. The Privacy Policy is incorporated in its entirety into and should
                                    be read in conjunction with this Agreement. We reserve the right to update the
                                    Privacy Policy at any time, and from time to time, in our sole discretion.

                                    我們將根據上述內容收集您的所有個人信息，並不會在未經您明示同意的情況下出於其他目的使用該信息 /
                                    或根據[鏈接]的隱私政策。隱私政策已全部納入本協議中，並應與本協議共同閱讀。我們保留隨時自行決定更新隱私政策的權利。</li>
                                <li>This Agreement represents an agreement made by and between you and the APA Group and
                                    has the binding effect of a legal contract and should be read carefully and in its
                                    entirety, prior to using any product or service. Your access to, and use of, any
                                    product or service is conditional upon your acceptance of, and compliance with, this
                                    Agreement.

                                    本協議代表您與APA集團之間的協議，具備法律合同的約束力，應在使用任何產品或服務之前仔細且完整地閱讀。您訪問及使用任何產品或服務的前提是您接受並遵守本協議。</li>
                            </ol>
                        </div>

                        <!-- Checkbox Section -->
                        <div class="checkbox">
                            <input type="checkbox" id="confirm-info" name="confirm-info" required>
                            <label for="confirm-info"><p> I/we have read and understood APA’s prevailing Terms and
                                Condition and agree to be bound by all the terms therein and any amendments or variation
                                thereof. I/we further agree and acknowledge that there are other terms and conditions
                                and agreement(s) intended or expressed to govern the use of other relevant products and
                                services offered by APA and I/we confirm my/our agreement and acceptance of the same.
                                Copies of APA’s prevailing terms and conditions can be obtained upon request.
                                我／我們已閱讀並理解 APA 目前的條款和條件，同意受其所有條款及任何修訂或變更之約束。我／我們進一步同意並承認，還有其他條款和條件及協議旨在或表達用於管理 APA
                                提供的其他相關產品和服務的使用，我／我們確認我／我們同意並接受同等。APA 目前的條款和條件的副本可應要求獲得。</p>
                            </label>
                        </div>

                        <div class="checkbox">
                            <input type="checkbox" id="confirm-info" name="confirm-info" required>
                            <label for="confirm-info"><p> I/we may provide personal data to APA in connection with me/us
                                establishing and maintaining my/our relationship with the APA. I/We confirm that all
                                information provided, and documents submitted by me/us are true, complete and accurate.
                                When providing any personal data to APA, I/we confirm that I am/we are lawfully
                                providing the data for APA to use and disclose for the purposes of:
                                我／我們可能會與 APA 提供與我／我們與 APA 之間建立和維持關係有關的個人資料。我／我們確認我／我們提供的所有信息和提交的文件均為真實、完整和準確。在向 APA
                                提供任何個人資料時，我／我們確認我／我們是合法提供該資料給 APA 用於目的的：
                                <ul style="margin: 0; padding-left: 18px; list-style-type: disc;">
                                    <li>providing products or services to me/us;
                                        向我／我們提供產品或服務；
                                    </li>
                                    <li> meeting the operational, administrative and risk management requirements of APA
                                        Group ; and
                                        符合 APA 集團的運營、行政和風險管理要求；以及
                                    </li>
                                    <li> complying with any requirement, as APA Group reasonably deems necessary, under
                                        any law or of any court, government authority or regulator. “APA Group” means
                                        Atlantic Partners Asia Holdings (SG) Pte. Ltd. and its affiliates.
                                        遵守 APA 集團合理認為在任何法律或任何法院、政府機構或監管機構下的任何要求。 “APA 集團” 指Atlantic Partners Asia
                                        Holdings (SG) Pte. Ltd. 及其聯營公司。
                                    </li>
                                </ul></p>
                            </label>
                        </div>


                        <div class="checkbox">
                            <input type="checkbox" id="terms" name="terms" required>
                            <label for="terms"><p>By submitting, you agree to our Terms and Conditions.</p></label>
                        </div>

                        <div class="form-group">
                            <label for="full-name">Full name as per Passport / 护照上的英文姓名：</label>
                            <input type="text" id="full-name" name="full-name" required>
                        </div>

                        <div class="form-group">
                            <label>Signature 签名：</label>
                            <canvas id="signature-pad"></canvas>
                            <button type="button" class="clear-button" onclick="clearSignature()">Clear</button>
                            <input type="hidden" name="signature-data" id="signature-data" required>
                        </div>

                        <div class="form-group">
                            <label for="date">Date 日期：</label>
                            <input type="date" id="date" name="date" required>
                        </div>

                        <button type="submit">Submit</button>




                    </form>

                </div>
            </div>

            <script>
                const canvas = document.getElementById("signature-pad");
                const signatureData = document.getElementById("signature-data");
                const ctx = canvas.getContext("2d");

                let drawing = false;

                canvas.addEventListener("mousedown", (e) => {
                    drawing = true;
                    ctx.beginPath();
                    ctx.moveTo(e.offsetX, e.offsetY);
                });

                canvas.addEventListener("mousemove", (e) => {
                    if (drawing) {
                        ctx.lineTo(e.offsetX, e.offsetY);
                        ctx.stroke();
                    }
                });

                canvas.addEventListener("mouseup", () => {
                    drawing = false;
                    signatureData.value = canvas.toDataURL(); // Save signature as base64
                });

                canvas.addEventListener("mouseout", () => {
                    drawing = false;
                });

                function clearSignature() {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    signatureData.value = '';
                }
            </script>





            <div id="Modal2" class="modal2">
                <div class="modal2-content">
                    <div class="modal2-header">
                        <h2>Liquidity Agreement</h2>
                        <span class="close-btn" onclick="closeModal2()">×</span>

                    </div>

                    <h2> Please download the agreement and signed it and upload </h2>


                    <form id="modal2Form" enctype="multipart/form-data" method="post">
                        <div class="reference-code2"><strong id="referenceCodeDisplay2"></strong></div>
                        <input type="hidden" id="referenceCode2" name="referenceCode2">
                        <label>Download Agreement:</label>
                        <a href="/path/to/agreement.pdf" download>Click here to download</a>

                        <label>Upload Signed Agreement:</label>
                        <input type="file" name="agreement" required>

                        <button type="submit">Submit</button>
                    </form>
                </div>
            </div>

            <script>
                function completeKYC() {
                    let kycStatus = document.getElementById("kyc-status");

                    // Simulate KYC completion
                    kycStatus.innerText = "Completed";
                    kycStatus.style.color = "green";

                    // Save KYC status in localStorage
                    localStorage.setItem("kycStatus", "Completed");
                }

                let step2Button = document.getElementById("step2-btn");
                let step1Button = document.getElementById("kyc-btn");
                let kycStatusElement = document.getElementById("kyc-status");
                let agreementStatusElement = document.getElementById("agreement-status");

                // Function to update button states dynamically
                function updateButtonStates() {
                    let kycStatus = kycStatusElement.innerText.trim();
                    let agreementStatus = agreementStatusElement.innerText.trim();

                    if (kycStatus === "Pending" && agreementStatus === "Pending") {
                        step2Button.disabled = true;
                        step1Button.disabled = false;
                    }
                    else if (kycStatus === "Completed" && agreementStatus === "Pending" || agreementStatus === "Processing") {
                        step1Button.disabled = true;
                        step2Button.disabled = false;
                    }
                    else if (kycStatus === "Completed" && agreementStatus === "Completed") {
                        step1Button.disabled = true;
                        step2Button.disabled = true;
                    }
                    else {
                        step1Button.disabled = false;
                        step2Button.disabled = true;
                    }
                }

                // Observe changes in the KYC and Agreement status elements
                let observer = new MutationObserver(updateButtonStates);
                observer.observe(kycStatusElement, { childList: true, subtree: true });
                observer.observe(agreementStatusElement, { childList: true, subtree: true });

                // Run the function initially to set the correct state
                updateButtonStates();


                function checkKYCStatusOnLoad() {
                    let savedKYCStatus = localStorage.getItem("kycStatus");
                    let kycStatusSpan = document.getElementById("kyc-status");

                    if (savedKYCStatus === "Completed") {
                        kycStatusSpan.innerText = "Completed";
                        kycStatusSpan.style.color = "green";
                    }

                    enableStep2Button();
                }

                window.onload = function () {
                    checkKYCStatusOnLoad();

                    // Start observing the KYC status text for changes
                    observer.observe(document.getElementById("kyc-status"), { childList: true, subtree: true });

                    // Attach event listener to the KYC button
                    document.getElementById("kyc-btn").addEventListener("click", function () {
                        completeKYC();
                    });
                };





                function openModal() {
                    document.getElementById("usdtModal").style.display = "block";


                }








                function closeModal() {
                    document.getElementById("usdtModal").style.display = "none";
                }

                function openModal2() {
                    document.getElementById("Modal2").style.display = "block";


                }

                function closeModal2() {
                    document.getElementById("Modal2").style.display = "none";
                }

            </script>

            <script>
                document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                    event.preventDefault();

                    let formData = new FormData(this);

                    fetch("kyc_submit.php", {
                        method: "POST",
                        body: formData
                    })
                        .then(response => response.json())
                        .then(data => {
                            alert(data.message);
                        })
                        .catch(error => console.error("Error:", error));
                });
                document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                    event.preventDefault();

                    // Prevent default submission (if using AJAX)

                    // Simulating successful submission (replace with actual AJAX call if needed)
                    setTimeout(() => {
                        //alert("Form submitted successfully!");
                        closeModal(); // Close modal after submission
                    }, 500); // Simulating slight delay


                });
            </script>
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    function getStatusColor(status) {
                        switch (status) {
                            case 'completed': return 'green';
                            case 'failed': return 'red';
                            case 'Processing': return 'orange';
                            default: return 'orange'; // Pending
                        }
                    }

                    function updateKycStatus() {
                        fetch("auto_update.php", {
                            method: "GET"
                        })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status !== "unauthorized") {
                                    let statusElement = document.getElementById("kyc-status");
                                    statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                    statusElement.style.color = getStatusColor(data.status);
                                }
                            })
                            .catch(error => console.error("Error fetching KYC status:", error));
                    }

                    // Fetch status every 5 seconds
                    setInterval(updateKycStatus, 5000);
                    updateKycStatus(); // Fetch immediately on page load
                });
            </script>
            <script>

                document.getElementById("modal2Form").addEventListener("submit", function (event) {
                    event.preventDefault();

                    setTimeout(() => {
                        //alert("Form submitted successfully!");
                        closeModal2(); // Close modal after submission
                    }, 500); // Simulating slight delay


                });
                document.getElementById("modal2Form").addEventListener("submit", function (event) {
                    event.preventDefault(); // Prevent default form submission

                    let formData = new FormData(this);

                    fetch("upload_agreements.php", {
                        method: "POST",
                        body: formData
                    })
                        .then(response => response.json())
                        .then(data => {
                            alert(data.message);
                            //closeModal2(); // Close modal after successful submission
                        })
                        .catch(error => console.error("Error:", error));



                });




            </script>
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    function getStatusColor(status) {
                        switch (status) {
                            case 'completed': return 'green';
                            case 'failed': return 'red';
                            case 'processing': return 'orange';
                            default: return 'orange'; // Pending
                        }
                    }

                    function updateAgreementStatus() {
                        fetch("check_status.php", {
                            method: "GET"
                        })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status !== "unauthorized") {
                                    let statusElement = document.getElementById("agreement-status");
                                    statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                    statusElement.style.color = getStatusColor(data.status);
                                }
                            })
                            .catch(error => console.error("Error fetching agreement status:", error));
                    }

                    // Fetch status every 5 seconds
                    setInterval(updateAgreementStatus, 5000);
                    updateAgreementStatus(); // Fetch immediately on page load
                });
            </script>





</body><!-- End of .page_wrapper -->

</html>