<?php
session_start();
require 'vendor/autoload.php';
include 'dbConnect.php'; // Include the database connection file

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Twilio\Rest\Client;

if (!isset($_SESSION['user'])) {
    echo json_encode(["message" => "User not authenticated."]);
    exit;
}

function sendEmailWithAttachment($filePath, $fileName, $reference_code, $user_name)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';  // Your email
        $mail->Password = 'uexurwwgwuotfcge';  // Your App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com'); // Recipient email
        $mail->addAttachment($filePath, $fileName); // Attach the uploaded file

        $mail->isHTML(true);
        $mail->Subject = 'New Liquidity Agreement Submitted';
        $mail->Body = "
            <h3>A new liquidity agreement has been submitted.</h3>
            <p><strong>Reference Code:</strong> $reference_code</p>
            <p><strong>Name:</strong> $user_name</p>
            <p>The user has submitted the liquidity agreement. Please find the attachment.</p>
        ";

        return $mail->send();
    } catch (Exception $e) {
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES["agreement"]) && isset($_POST["referenceCode2"])) {
        $user_id = $_SESSION['user']['id']; // Get user ID from session
        $user_name = $_SESSION['user']['name']; // Get user name from session
        $reference_code = $_POST["referenceCode2"];
        $status = "processing";
        $upload_dir = "uploads/";

        // Ensure upload directory exists
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $file_name = basename($_FILES["agreement"]["name"]);
        $file_path = $upload_dir . time() . "_" . $file_name;

        if (move_uploaded_file($_FILES["agreement"]["tmp_name"], $file_path)) {
            try {
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $pdo->prepare("INSERT INTO liquidity_agreements (user_id, agreement_file, status, reference_code) VALUES (?, ?, ?, ?)");
                $stmt->execute([$user_id, $file_path, $status, $reference_code]);

                // Send email with the attachment
                if (sendEmailWithAttachment($file_path, $file_name, $reference_code, $user_name)) {
                    echo json_encode(["message" => "Agreement uploaded and email sent successfully."]);
                } else {
                    echo json_encode(["message" => "Agreement uploaded, but email sending failed."]);
                }
            } catch (PDOException $e) {
                echo json_encode(["message" => "Database error: " . $e->getMessage()]);
            }
        } else {
            echo json_encode(["message" => "File upload failed."]);
        }
        sendWhatsAppMessagetoapa_kyc($reference_code, $user_name);
    } else {
        echo json_encode(["message" => "Invalid request."]);
    }
} else {
    echo json_encode(["message" => "Invalid method."]);
}

function sendWhatsAppMessagetoapa_kyc($reference_code, $user_name)
{
    $sid = "AC123ed9e921a2f70fa480229231503368";
    $token = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $body = "Reference Code: $reference_code , Name - $user_name The user has submitted the liquidity agreement. Please check email.
";

    $message = $twilio->messages->create("whatsapp:+917588345894", [
        "from" => "whatsapp:+14155238886",
        "body" => $body
    ]);
}



