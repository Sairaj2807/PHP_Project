<?php
require 'dbConnect.php';
require_once('vendor/autoload.php'); // Composer autoload
require_once('tcpdf/tcpdf.php');

$data = json_decode(file_get_contents("php://input"), true);
$html = $data['html'];
$signature = $data['signature'];
$user_id = $data['user_id'];

// Save signature image
$imgPath = 'signatures/' . uniqid() . '.png';
file_put_contents($imgPath, base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $signature)));

// Append signature to HTML
$html .= "<p><strong>Signature:</strong><br><img src='$imgPath' width='200'></p>";

// Generate PDF using TCPDF
$pdf = new TCPDF();
$pdf->AddPage();
$pdf->writeHTML($html, true, false, true, false, '');
$pdfPath = 'pdfs/' . uniqid() . '_agreement.pdf';
$pdf->Output($pdfPath, 'F');

// Save PDF path to DB
$stmt = $pdo->prepare("INSERT INTO liquidity_agreements (user_id, pdf) VALUES (?, ?)");
$stmt->execute([$user_id, $pdfPath]);

echo "Agreement submitted and saved successfully.";
?>
