<?php
require 'dbConnect.php';

if (!isset($_GET['user_id'])) {
    echo "<p style='color:red;'>User ID not provided.</p>";
    exit;
}

$user_id = $_GET['user_id'];

$stmt = $pdo->prepare("SELECT full_name, passport_id, address1, address2, address3 FROM kyc WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "<p style='color:red;'>No KYC data found for user ID $user_id.</p>";
    exit;
}

$date = date("d F Y");
$address = "{$user['address1']}, {$user['address2']}, {$user['address3']}";

echo "
<div style='max-height: 400px; overflow-y: auto; padding-right: 10px;'>
  <p>This Liquidity Agreement is made on <strong>$date</strong> between</p>
  <p><strong>{$user['full_name']}</strong>, holder of Passport ID <strong>{$user['passport_id']}</strong>, residing at <strong>$address</strong>.</p>

  <p>And ATLANTIC PARTNERS SPC FUND on behalf of the Atlantic Partners Asia Fund Segregated Portfolio, a 
  company incorporated under the laws of Cayman Island...</p>
 
</div>
";
?>
