<?php
require 'dbConnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["new_password"])) {
  $email = $_POST["email"] ?? null;
  $new_password = $_POST["password"];

  if (empty($new_password)) {
    echo "<script>alert('Password cannot be empty.'); window.location.href='change_password.html?email=$email';</script>";
    exit;
  }

  if (strlen($new_password) < 8) {
    echo "<script>alert('Password must be at least 8 characters long.'); window.location.href='change_password.html?email=$email';</script>";
    exit;
  }

  if (!$email) {
    echo "<script>alert('Invalid request.'); window.location.href='forgot.html';</script>";
    exit;
  }

  // Hash the new password
  $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

  // Update the password in the database
  $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE email = :email");
  $stmt->bindParam(":password", $hashed_password);
  $stmt->bindParam(":email", $email);

  if ($stmt->execute()) {
    echo "<script>alert('Password updated successfully.'); window.location.href='login.html';</script>";
  } else {
    echo "<script>alert('Error updating password.'); window.location.href='change_password.html';</script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Forgot Password</title>
  <link rel="stylesheet" href="style2.css" />
</head>

<body>
  <div class="container" id="signIn">
    <h1 class="form-title">Change Password</h1>
    <form method="POST">
      <!-- Hidden field to store email -->
      <input type="hidden" name="email"
        value="<?php echo isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>">

      <div class="input-group password">
        <i class="fas fa-lock"></i>
        <input type="password" name="password" id="password" placeholder="New Password" required />
      </div>

      <input type="submit" class="btn" value="Save" name="new_password" />
    </form>
  </div>
  <script src="script.js"></script>
</body>

</html>