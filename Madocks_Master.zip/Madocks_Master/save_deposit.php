<?php
include 'dbConnect.php';
session_start(); // Ensure session is started

// Include PHPMailer and Twilio
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Twilio\Rest\Client;

// Check if user is logged in
if (!isset($_SESSION['user']['id'])) {
    die("Error: User not logged in.");
}

$user_id = $_SESSION['user']['id'];





// Validate form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['receipt']) && isset($_POST['bank_address'])) {
    $bank_address = htmlspecialchars($_POST['bank_address']);

    // File upload handling
    $upload_dir = 'uploads/';
    $filename = basename($_FILES['receipt']['name']);
    $target_file = $upload_dir . $filename;

    if (move_uploaded_file($_FILES['receipt']['tmp_name'], $target_file)) {
        // Fetch latest record for the user
        $query = "SELECT id FROM records 
                  WHERE user_id = :user_id 
                  ORDER BY transaction_time DESC LIMIT 1";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $record = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($record) {
            $record_id = $record['id'];

            // Update the record
            $deposit_status = 'processing';

            $update_query = "UPDATE records 
                 SET receipt_file = :receipt_file, bank_address = :bank_address, deposit_status = :deposit_status 
                 WHERE id = :record_id";

            $update_stmt = $pdo->prepare($update_query);
            $update_stmt->bindParam(':receipt_file', $target_file, PDO::PARAM_STR);
            $update_stmt->bindParam(':bank_address', $bank_address, PDO::PARAM_STR);
            $update_stmt->bindParam(':deposit_status', $deposit_status, PDO::PARAM_STR);
            $update_stmt->bindParam(':record_id', $record_id, PDO::PARAM_INT);



            if ($update_stmt->execute()) {
                // Send email with receipt
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'madocks.ai@gmail.com';
                    $mail->Password = 'uexurwwgwuotfcge';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
                    $mail->addAddress('sdbangar2807@gmail.com');
                    $mail->addAttachment($target_file);

                    $mail->isHTML(true);
                    $mail->Subject = 'New Bank Record Receipt';
                    $mail->Body = "<h3>New bank record receipt uploaded.</h3>
                                   <p><strong>User ID:</strong> $user_id</p>
                                   <p><strong>User's Bank Address:</strong> $bank_address</p>
                                   <p>
                                   <p>The receipt file is attached.</p>";

                    if ($mail->send()) {
                        echo "success";
                    } else {
                        echo "Error: Failed to send email.";
                    }
                } catch (Exception $e) {
                    echo "Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                echo "Error: Failed to update the record.";
            }
        } else {
            echo "Error: No records found.";
        }
    } else {
        echo "Error: Failed to upload the receipt file.";
    }

    sendWhatsAppMessagetoapa_Deposit($user_id, $bank_address);

} else {
    echo "Error: Invalid form submission.";
}

function sendWhatsAppMessagetoapa_Deposit($user_id, $bank_address)
{
    $sid = "AC123ed9e921a2f70fa480229231503368";
    $token = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $body = "User - $user_id has Deposited money. Bank Address - $bank_address, please check mail.";

    $twilio->messages->create("whatsapp:+917588345894", [
        "from" => "whatsapp:+14155238886",
        "body" => $body
    ]);
}
?>