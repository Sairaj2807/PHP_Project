<?php
header('Content-Type: application/json');

$translations = [
  "zh" => [
    "welcome" => "欢迎来到 MADOCKS",
    "intro" => "在 Madocks，我们通过三大核心服务为交易者提供智能解决方案。"
  ],
  "hi" => [
    "welcome" => "MADOCKS में आपका स्वागत है",
    "intro" => "Madocks में, हम अपने तीन प्रमुख प्रस्तावों के माध्यम से ट्रेडर्स को स्मार्ट समाधान प्रदान करते हैं।"
  ],
  "en" => [
    "welcome" => "Welcome to MADOCKS",
    "intro" => "At madocks, we empower traders with smart solutions through our three core offerings:"
  ]
];

$lang = $_POST['lang'] ?? 'en';
echo json_encode($translations[$lang] ?? $translations['en']);
?>
