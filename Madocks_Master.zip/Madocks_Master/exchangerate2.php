<?php 
header("Content-Type: application/json");

// Load fixed exchange rates from JSON file
$fixedRatesJson = file_get_contents('exchangeRates.json');
$fixedRates = json_decode($fixedRatesJson, true);

// Fetch live exchange rates
$url = "https://www.xe.com/api/protected/midmarket-converter/";
$auth = "Basic bG9kZXN0YXI6cHVnc25heA=="; // Replace with your actual API key

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Accept: application/json",
    "Authorization: $auth"
]);

$response = curl_exec($ch);
curl_close($ch);

$liveRates = json_decode($response, true);

// List of currencies to track
$currencies = ["USD", "SGD", "THB", "MYR", "INR", "JPY", "EUR", "HKD", "CNY", "RMB", "AUD", "GBP", "PHP", "USDT"];

$combinedRates = [];

foreach ($currencies as $code) {
    $fixedKey = "exchangeRate_$code";
    $fixed = isset($fixedRates[$fixedKey]) ? (float)$fixedRates[$fixedKey] : 0;
    $live = isset($liveRates['rates'][$code]) ? (float)$liveRates['rates'][$code] : 0;

    // Use the lower of the two
    $combinedRates[$fixedKey] = min($fixed, $live);
}

echo json_encode($combinedRates);
