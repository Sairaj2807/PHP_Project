<?php
session_start();
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <style>
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            z-index: 1000;
            /* Ensure it's above everything else */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            /* Dark overlay */
            overflow-y: auto;
            /* Allow scrolling within the modal */
        }

        /* Prevent background from scrolling when modal is open */
        body.modal-open {
            overflow: hidden;
        }


        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }

        .close-btn {
            cursor: pointer;
            font-size: 24px;
        }

        .modal-body {
            padding: 20px 0;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input,
        select textarea {

            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;

        }






        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .clicked {
            background-color: #28a745 !important;
            /* Green color to indicate success */
            transform: scale(0.95);
        }

        .reference-code {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .circle {
            width: 200px;
            height: 200px;
            background: white;
            border-radius: 50%;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            position: relative;
        }

        .circle span {
            color: #007bff;
        }

        .options {
            color: black;
            display: flex;
            flex-direction: column;
            gap: 30px;
            margin-left: 80px;
        }

        .option {
            color: black;
            display: flex;
            align-items: center;
            background: white;
            padding: 15px;
            border-radius: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            justify-content: space-between;
            position: relative;
        }

        .icon {
            width: 40px;
            height: 40px;
            background: #f0f8ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
        }

        .text {
            text-align: left;
            flex: 1;
        }

        .text h3 {
            margin: 0;
            font-size: 16px;
            color: #007bff;
        }

        .text p {
            margin: 5px 0 0;
            font-size: 14px;
            color: #555;
        }

        .btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .modaldeposit {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modaldeposit-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modaldeposit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        input[type="file"],
        input[type="text"] {
            display: block;
            margin: 10px 0;
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }


        .modal2 {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal2-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal2-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modal2-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .reference-code2 {
            font-weight: bold;
            color: black;
            font-size: 16px;
            margin-top: 10px;
            text-align: left;
        }

        .btn:disabled {
            background: gray;
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!---<div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>--->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
    <div class="popup-inner">
        <div class="upper-box clearfix">
            <figure class="logo-box pull-left"><a href="new_index.php"><img src="assets/images/logonew.png"
                        alt=""></a></figure>
            <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <div class="overlay-layer"></div>
        <div class="auto-container">
            <div class="search-form">
                <form method="post" action="new_index.php">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value=""
                                placeholder="Type your keyword and hit" required>
                            <button type="submit"><i class="flaticon-loupe"></i></button>
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                    Us</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                                <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="new_index.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                            <a href="logout.php">Logout</a>
                        </li>
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                            <a href="register.php">Signup</a>
                        </li>
                    </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="new_index.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="current dropdown"><a href="new_index.php">Home</a>
                                            <!---<ul>
                                        <li><a href="new_index.php">Home One</a></li>
                                        <li><a href="new_index.php">Home Two</a></li>
                                        <li><a href="new_index.php">Home Three</a></li>
                                    </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                        <li><a href="marketsl.php">Markets</a></li>
                                        <li><a href="market-details.html">Details Page</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                        <li><a href="platform.php">Platform</a></li>
                                        <li><a href="account.html">Our Accounts</a></li>
                                        <li><a href="account-details.html">Standard Account</a></li>
                                        <li><a href="account-details-2.html">Commision Account</a></li>
                                        <li><a href="account-details-3.html">STP Pro Account</a></li>
                                    </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="new_index.php">Education</a>
                                    <ul>
                                        <li><a href="education.html">Education</a></li>
                                        <li><a href="education-details.html">Detail Page</a></li>
                                    </ul>
                                </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                        <li><a href="about.html">Company</a></li>
                                        <li><a href="history.html">History</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li class="dropdown"><a href="new_index.php">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">3 Columns</a></li>
                                                <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                <li><a href="blog-3.html">List View 01</a></li>
                                                <li><a href="blog-4.html">List View 02</a></li>
                                                <li><a href="blog-details.html">Single Post</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                        <li><a href="faq.html">Faq’s</a></li>
                                        <li><a href="error.html">404</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="dropdown"><a href="usdt_main.php">USDT</a>

                                        </li>
                                        <!--<li class="dropdown"><a href="sneat/html/index.html">Dashboard</a> </li>-->
                                    </ul>
                                </div>
                            </nav>
                            <!--<div class="menu-right-content">

                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="" class="theme-btn btn-one">
                                
                            </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                            <!--<div class="menu-right-content">
                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                                



                         </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="new_index.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="new_index.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                Here</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="new_index.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- banner-style-three -->
        <section class="banner-style-three centred">

            <div class="container">
                <!-- Circular Infographic -->
                <div class="circle">
                    KYC <br> <span></span>
                </div>

                <!-- Connecting Lines -->
                <div class="line-container">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>

                <!-- Option Boxes -->
                <div class="options">
                    <!-- Option A -->
                    <div class="option">
                        <div class="icon">👤</div>
                        <div class="text">
                            <h3>Step1: KYC submission</h3>
                            <p>Status: <span id="kyc-status" style="color: orange;">Pending</span></p>
                        </div>
                        <button class="btn" id="kyc-btn" onclick="openModal()">Select</button>
                    </div>

                    <!-- Option B -->
                    <div class="option">
                        <div class="icon">🎫</div>
                        <div class="text">
                            <h3>Step2: Liquidity agreement</h3>
                            <p>Status: <span id="agreement-status" style="color: orange;">Pending</span> </p>

                        </div>
                        <button class="btn" id="step2-btn" onclick="openModal2()" disabled>Select</button>
                    </div>



                </div>
            </div>

        </section>


        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode();
            });

            function generateReferenceCode() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });

        </script>

        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode2();
            });

            function generateReferenceCode2() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay2").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode2").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode2").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });
        </script>

        <div id="usdtModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>USDT Onboarding</h2>
                    <span class="close-btn" onclick="closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <h3>KYC APPLICATION</h3>
                    <h4>INDIVIDUAL DETAILS</h4>

                    <form id="usdtOnboardingForm">
                        <div class="reference-code"><strong id="referenceCodeDisplay"></strong></div>
                        <input type="hidden" id="referenceCode" name="referenceCode">

                        <label for="apaEmployee">Name of the MADOCKS employee spoken to </label>
                        <input type="text" id="apaEmployee" name="apaEmployee">

                        <label for="fullName">Full Name as per Passport/ID *</label>
                        <input type="text" id="fullName" name="fullName" required>

                        <label for="dob">Date of Birth *</label>
                        <input type="text" id="dob" name="dob" placeholder="DDMMYYYY" required>

                        <label for="nationality">Nationality *</label>
                        <select id="nationality" name="nationality" required>
                            <option value="">Select Country</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                            <option value="UK">United Kingdom</option>
                        </select>

                        <label for="address1">Address Line 1 *</label>
                        <input type="text" id="address1" name="address1" required>

                        <label for="address2">Address Line 2</label>
                        <input type="text" id="address2" name="address2">

                        <label for="address3">Address Line 3</label>
                        <input type="text" id="address3" name="address3">

                        <label for="postcode">Postcode *</label>
                        <input type="text" id="postcode" name="postcode" required>

                        <label for="mobile">Mobile Number *</label>
                        <input type="text" id="mobile" name="mobile" required>

                        <label for="passportId">Passport/ID Number *</label>
                        <input type="text" id="passportId" name="passportId" required>

                        <label for="country">Country *</label>
                        <select id="country" name="country" required>
                            <option value="">Select Country</option>
                            <option value="US">United States</option>
                            <option value="IN">India</option>
                            <option value="UK">United Kingdom</option>
                        </select>

                        <label for="occupation">Occupation *</label>
                        <input type="text" id="occupation" name="occupation" required>

                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required>

                        <label for="currencies">Currencies Required *</label>
                        <input type="text" id="currencies" name="currencies" required>

                        <label for="sourceWealth">Source of Wealth *</label>
                        <input type="file" id="sourceWealth" name="sourceWealth" required>

                        <label for="proofIdentity">Proof of Identity *</label>
                        <input type="file" id="proofIdentity" name="proofIdentity" required>

                        <label for="proofAddress">Proof of Address (issued within 3 months) *</label>
                        <input type="file" id="proofAddress" name="proofAddress" required>

                        <label for="sourceFunds">Source of Funds *</label>
                        <input type="file" id="sourceFunds" name="sourceFunds" required>

                        <label for="annualVolume">Estimated Annual Transaction Volume (USD) *</label>
                        <input type="text" id="annualVolume" name="annualVolume" required>

                        <label for="accountReason">Reason for Account Opening *</label>
                        <textarea id="accountReason" name="accountReason" required></textarea>

                        <button type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>




        <div id="Modal2" class="modal2">
            <div class="modal2-content">
                <div class="modal2-header">
                    <h2>Liquidity Agreement</h2>
                    <span class="close-btn" onclick="closeModal2()">×</span>

                </div>

                <h2> Please download the agreement and signed it and upload </h2>


                <form id="modal2Form" enctype="multipart/form-data" method="post">
                    <div class="reference-code2"><strong id="referenceCodeDisplay2"></strong></div>
                    <input type="hidden" id="referenceCode2" name="referenceCode2">
                    <label>Download Agreement:</label>
                    <a href="/path/to/agreement.pdf" download>Click here to download</a>

                    <label>Upload Signed Agreement:</label>
                    <input type="file" name="agreement" required>

                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>

        <script>
            function completeKYC() {
                let kycStatus = document.getElementById("kyc-status");

                // Simulate KYC completion
                kycStatus.innerText = "Completed";
                kycStatus.style.color = "green";

                // Save KYC status in localStorage
                localStorage.setItem("kycStatus", "Completed");
            }

            let step2Button = document.getElementById("step2-btn");
            let step1Button = document.getElementById("kyc-btn");
            let kycStatusElement = document.getElementById("kyc-status");
            let agreementStatusElement = document.getElementById("agreement-status");

            // Function to update button states dynamically
            function updateButtonStates() {
                let kycStatus = kycStatusElement.innerText.trim();
                let agreementStatus = agreementStatusElement.innerText.trim();

                if (kycStatus === "Pending" && agreementStatus === "Pending") {
                    step2Button.disabled = true;
                    step1Button.disabled = false;
                }
                else if (kycStatus === "Completed" && agreementStatus === "Pending" || agreementStatus ==="Processing" ) {
                    step1Button.disabled = true;
                    step2Button.disabled = false;
                }
                else if (kycStatus === "Completed" && agreementStatus === "Completed") {
                    step1Button.disabled = true;
                    step2Button.disabled = true;
                }
                else {
                    step1Button.disabled = false;
                    step2Button.disabled = true;
                }
            }

            // Observe changes in the KYC and Agreement status elements
            let observer = new MutationObserver(updateButtonStates);
            observer.observe(kycStatusElement, { childList: true, subtree: true });
            observer.observe(agreementStatusElement, { childList: true, subtree: true });

            // Run the function initially to set the correct state
            updateButtonStates();


            function checkKYCStatusOnLoad() {
                let savedKYCStatus = localStorage.getItem("kycStatus");
                let kycStatusSpan = document.getElementById("kyc-status");

                if (savedKYCStatus === "Completed") {
                    kycStatusSpan.innerText = "Completed";
                    kycStatusSpan.style.color = "green";
                }

                enableStep2Button();
            }

            window.onload = function () {
                checkKYCStatusOnLoad();

                // Start observing the KYC status text for changes
                observer.observe(document.getElementById("kyc-status"), { childList: true, subtree: true });

                // Attach event listener to the KYC button
                document.getElementById("kyc-btn").addEventListener("click", function () {
                    completeKYC();
                });
            };





            function openModal() {
                document.getElementById("usdtModal").style.display = "block";


            }








            function closeModal() {
                document.getElementById("usdtModal").style.display = "none";
            }

            function openModal2() {
                document.getElementById("Modal2").style.display = "block";


            }

            function closeModal2() {
                document.getElementById("Modal2").style.display = "none";
            }

        </script>

        <script>
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                event.preventDefault();

                let formData = new FormData(this);

                fetch("kyc_submit.php", {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);
                    })
                    .catch(error => console.error("Error:", error));
            });
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                event.preventDefault();

                // Prevent default submission (if using AJAX)

                // Simulating successful submission (replace with actual AJAX call if needed)
                setTimeout(() => {
                    //alert("Form submitted successfully!");
                    closeModal(); // Close modal after submission
                }, 500); // Simulating slight delay


            });
        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                function getStatusColor(status) {
                    switch (status) {
                        case 'completed': return 'green';
                        case 'failed': return 'red';
                        case 'Processing': return 'orange';
                        default: return 'orange'; // Pending
                    }
                }

                function updateKycStatus() {
                    fetch("auto_update.php", {
                        method: "GET"
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status !== "unauthorized") {
                                let statusElement = document.getElementById("kyc-status");
                                statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                statusElement.style.color = getStatusColor(data.status);
                            }
                        })
                        .catch(error => console.error("Error fetching KYC status:", error));
                }

                // Fetch status every 5 seconds
                setInterval(updateKycStatus, 5000);
                updateKycStatus(); // Fetch immediately on page load
            });
        </script>
        <script>

            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                event.preventDefault();

                setTimeout(() => {
                    //alert("Form submitted successfully!");
                    closeModal2(); // Close modal after submission
                }, 500); // Simulating slight delay


            });
            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                event.preventDefault(); // Prevent default form submission

                let formData = new FormData(this);

                fetch("upload_agreements.php", {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);
                        //closeModal2(); // Close modal after successful submission
                    })
                    .catch(error => console.error("Error:", error));



            });




        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                function getStatusColor(status) {
                    switch (status) {
                        case 'completed': return 'green';
                        case 'failed': return 'red';
                        case 'processing': return 'orange';
                        default: return 'orange'; // Pending
                    }
                }

                function updateAgreementStatus() {
                    fetch("check_status.php", {
                        method: "GET"
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status !== "unauthorized") {
                                let statusElement = document.getElementById("agreement-status");
                                statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                statusElement.style.color = getStatusColor(data.status);
                            }
                        })
                        .catch(error => console.error("Error fetching agreement status:", error));
                }

                // Fetch status every 5 seconds
                setInterval(updateAgreementStatus, 5000);
                updateAgreementStatus(); // Fetch immediately on page load
            });
        </script>



</body><!-- End of .page_wrapper -->

</html>