<?php
require_once 'dbConnect.php';
require 'vendor/autoload.php'; // Ensure you have Endroid/qr-code installed via Composer

use Endroid\QrCode\Builder\Builder; // Import Endroid QR Code Builder
use Endroid\QrCode\Writer\PngWriter;

session_start();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $name = $_POST['name'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $created_at = date('Y-m-d H:i:s');
    $referredBy = null; // default

    // Check if referral code was submitted via hidden input
    if (isset($_POST['referral_code']) && !empty($_POST['referral_code'])) {
        $referralCodeUsed = $_POST['referral_code'];

        // Find the user who owns this referral code
        $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = :code");
        $stmt->execute(['code' => $referralCodeUsed]);
        $referrer = $stmt->fetch();

        if ($referrer) {
            $referredBy = $referrer['id']; // Save referrer ID
        }
    }

    // Validate input fields
    $errors = [];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    if (empty($name)) {
        $errors['name'] = 'Name is required';
    }
    if (strlen($password) < 8) {
        $errors['password'] = 'Password must be at least 8 characters long.';
    }
    if ($password !== $confirmPassword) {
        $errors['confirm_password'] = 'Passwords do not match';
    }

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    if ($stmt->fetch()) {
        $errors['user_exist'] = 'Email is already registered';
    }

    // Redirect back with errors if validation fails
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: register.php');
        exit();
    }

    // Generate unique referral code
    $referralCode = substr(str_pad(mt_rand(0, 99999999), 8, '0', STR_PAD_LEFT), 0, 8);
    $referralLink = "www.madocks.ai/register.php?code=" . $referralCode;

    // Generate QR Code
    $qrImagePath = 'qr_codes/' . $referralCode . '.png';
    $qrCode = Builder::create()
        ->writer(new PngWriter())
        ->data($referralLink)
        ->size(300)
        ->margin(10)
        ->build();
    $qrCode->saveToFile($qrImagePath);

    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert user with referred_by
    $stmt = $pdo->prepare("INSERT INTO users (email, password, name, created_at, referral_code, referral_link, referred_by) 
                           VALUES (:email, :password, :name, :created_at, :referral_code, :referral_link, :referred_by)");
    $stmt->execute([
        'email' => $email,
        'password' => $hashedPassword,
        'name' => $name,
        'created_at' => $created_at,
        'referral_code' => $referralCode,
        'referral_link' => $referralLink,
        'referred_by' => $referredBy
    ]);

    header('Location: index.html');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signin'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // Validate login fields
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    if (empty($password)) {
        $errors['password'] = 'Password cannot be empty';
    }

    // Redirect back with errors if validation fails
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: login.php');
        exit();
    }

    // Check for user in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    



    // Verify password and set session
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'created_at' => $user['created_at'],
            'referral_code' => $user['referral_code'],
            'referral_link' => $user['referral_link'] // Store referral link in session
        ];

        header('Location: new_index.php');
        exit();
    } else {
        $errors['login'] = 'Invalid email or password';
        $_SESSION['errors'] = $errors;
        header('Location: login.php');
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['usdt_login'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // Validate login fields
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    if (empty($password)) {
        $errors['password'] = 'Password cannot be empty';
    }

    // Redirect back with errors if validation fails
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: login_usdt.php');
        exit();
    }

    // Check for user in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    // Verify password and set session
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'created_at' => $user['created_at'],
            'referral_code' => $user['referral_code'],
            'referral_link' => $user['referral_link'] // Store referral link in session
        ];

        header('Location: usdt_main_page_change2.php');
        exit();
    } else {
        $errors['login'] = 'Invalid email or password';
        $_SESSION['errors'] = $errors;
        header('Location: login_usdt.php');
        exit();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['Login_admin'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // Validate login fields
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    if (empty($password)) {
        $errors['password'] = 'Password cannot be empty';
    }

    // Redirect back with errors if validation fails
    if (!empty($errors)) {
        $_SESSION['errors'] = $errors;
        header('Location: login_admin.php');
        exit();
    }

    // Check for user in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();

    // Verify password and set session
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'created_at' => $user['created_at'],
            'referral_code' => $user['referral_code'],
            'referral_link' => $user['referral_link'] // Store referral link in session
        ];

        header('Location: admin.php');
        exit();
    } else {
        $errors['login'] = 'Invalid email or password';
        $_SESSION['errors'] = $errors;
        header('Location: login_usdt.php');
        exit();
    }
}


?>
