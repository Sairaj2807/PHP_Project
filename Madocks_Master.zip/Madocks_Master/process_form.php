<?php
require 'dbConnect.php';
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Function to safely retrieve form values
    function getPostValue($key) {
        return isset($_POST[$key]) ? trim($_POST[$key]) : null;
    }

    // Retrieve form data safely
    $referenceCode = getPostValue('referenceCode') ?? uniqid("REF_");
    $apaEmployee = getPostValue('apaEmployee');
    $fullName = getPostValue('fullName');
    $dob = getPostValue('dob');
    $nationality = getPostValue('nationality');
    $address1 = getPostValue('address1');
    $address2 = getPostValue('address2');
    $address3 = getPostValue('address3');
    $postcode = getPostValue('postcode');
    $mobile = getPostValue('mobile');
    $passportId = getPostValue('passportId');
    $country = getPostValue('country');
    $occupation = getPostValue('occupation');
    $email = getPostValue('email');
    $currencies = getPostValue('currencies');
    $annualVolume = getPostValue('annualVolume');
    $accountReason = getPostValue('accountReason');

    // Handle File Uploads
    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    function uploadFile($fileKey, $uploadDir) {
        if (isset($_FILES[$fileKey]) && $_FILES[$fileKey]['error'] == UPLOAD_ERR_OK) {
            $filename = time() . "_" . basename($_FILES[$fileKey]['name']);
            $filePath = $uploadDir . $filename;
            move_uploaded_file($_FILES[$fileKey]['tmp_name'], $filePath);
            return $filePath;
        }
        return null;
    }

    $sourceWealth = uploadFile('sourceWealth', $uploadDir);
    $proofIdentity = uploadFile('proofIdentity', $uploadDir);
    $proofAddress = uploadFile('proofAddress', $uploadDir);
    $sourceFunds = uploadFile('sourceFunds', $uploadDir);

    // Ensure the user ID exists
    $defaultUserId = 12; // Change this to a valid existing user ID
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->execute([$defaultUserId]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(["success" => false, "message" => "Error: Invalid user ID."]);
        exit;
    }

    $userId = $user['id'];

    // Insert into Database
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount_send, currency_send, amount_receive, currency_receive, usdt_address, bank_address, receipt_file, kyc_status, deposit_status, receive_status)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending', 'pending')");
    $stmt->execute([$userId, 'buy', 0, $currencies, 0, 'USDT', NULL, NULL, NULL]);

    // Send Email
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com');

        $mail->isHTML(true);
        $mail->Subject = "New USDT Onboarding Submission - $referenceCode";
        $mail->Body = "
            <h3>New USDT Onboarding Request</h3>
            <p><strong>Reference Code:</strong> $referenceCode</p>
            <p><strong>Name of APA Employee:</strong> $apaEmployee</p>
            <p><strong>Full Name:</strong> $fullName</p>
            <p><strong>Date of Birth:</strong> $dob</p>
            <p><strong>Nationality:</strong> $nationality</p>
            <p><strong>Address:</strong> $address1, $address2, $address3, $postcode</p>
            <p><strong>Mobile:</strong> $mobile</p>
            <p><strong>Passport/ID:</strong> $passportId</p>
            <p><strong>Country:</strong> $country</p>
            <p><strong>Occupation:</strong> $occupation</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Currencies Required:</strong> $currencies</p>
            <p><strong>Annual Volume:</strong> $annualVolume</p>
            <p><strong>Reason for Account Opening:</strong> $accountReason</p>
            <p><strong>Uploaded Files:</strong></p>
            <ul>
                " . ($sourceWealth ? "<li><a href='$sourceWealth'>Source of Wealth</a></li>" : "") . "
                " . ($proofIdentity ? "<li><a href='$proofIdentity'>Proof of Identity</a></li>" : "") . "
                " . ($proofAddress ? "<li><a href='$proofAddress'>Proof of Address</a></li>" : "") . "
                " . ($sourceFunds ? "<li><a href='$sourceFunds'>Source of Funds</a></li>" : "") . "
            </ul>
        ";

        if ($mail->send()) {
            echo json_encode(["success" => true, "message" => "Form submitted and email sent."]);
        } else {
            echo json_encode(["success" => false, "message" => "Failed to send email."]);
        }
    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Mailer Error: {$mail->ErrorInfo}"]);
    }
}
?>
