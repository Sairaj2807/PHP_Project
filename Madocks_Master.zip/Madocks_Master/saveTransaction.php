<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in."]);
    exit();
}

$user_id = $_SESSION['user']['id'];

$data = json_decode(file_get_contents("php://input"), true);

$amountSend = $data['amountSend'];
$currencySend = $data['currencySend'];
$amountReceive = $data['amountReceive'];
$currencyReceive = $data['currencyReceive'];



try {
    $stmt = $pdo->prepare("INSERT INTO records (user_id, amount_send, currency_send, amount_receive, currency_receive) 
                           VALUES (:user_id, :amount_send, :currency_send, :amount_receive, :currency_receive)");
    $stmt->execute([
        ':user_id' => $user_id,
        ':amount_send' => $amountSend,
        ':currency_send' => $currencySend,
        ':amount_receive' => $amountReceive,
        ':currency_receive' => $currencyReceive,
    ]);

    echo json_encode(["status" => "success", "message" => "Transaction saved."]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
