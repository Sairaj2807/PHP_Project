<?php
require 'dbConnect.php';
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit-form'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Lookup user in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $userDetails = "";
    if ($user) {
        $userDetails = "
            <p><strong>User ID:</strong> {$user['id']}</p>
            <p><strong>Name:</strong> {$user['name']}</p>
            <p><strong>Email:</strong> {$user['email']}</p>
        ";
    } else {
        $userDetails = "<p>User not found in the database.</p>";
    }

    // Compose email body
    $emailBody = "
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> $username</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Phone:</strong> $phone</p>
        <p><strong>Subject:</strong> $subject</p>
        <p><strong>Message:</strong></p>
        <p>$message</p>
        <hr>
        <h4>User Info from Database:</h4>
        $userDetails
    ";

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress('sdbangar2807@gmail.com');
        //$mail->addAddress('harveyong.wv@gmail.com'); // Optional second recipient

        // Content
        $mail->isHTML(true);
        $mail->Subject = "New Message from Contact Form: $subject";
        $mail->Body = $emailBody;

        if ($mail->send()) {
            echo "<script>alert('Message sent successfully!'); window.location.href='new_index.php';</script>";
        } else {
            echo "Failed to send email.";
        }
    } catch (Exception $e) {
        echo "Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo "Invalid request.";
}
?>
