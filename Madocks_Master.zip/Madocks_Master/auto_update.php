<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(["status" => "unauthorized"]);
    exit;
}

$user_id = $_SESSION['user']['id'];

$query = "SELECT status FROM kyc WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 1";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$kyc = $stmt->fetch(PDO::FETCH_ASSOC);

$kyc_status = $kyc['status'] ?? 'pending';

echo json_encode(["status" => $kyc_status]);
