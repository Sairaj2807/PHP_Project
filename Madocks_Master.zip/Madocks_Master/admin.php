<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login_admin.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Actions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }

        .container {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .kyc-button {
            background-color: #007bff;
            color: white;
        }

        .liquidity-button {
            background-color: #28a745;
            color: white;
        }

        .deposit-button {
            background-color: grey;
            color: white;
        }

        .receive-money-button {
            background-color: orange;
            color: white;
        }

        .sell-deposit-button {
            background-color: gold;
            color: white;
        }

        .sell-receive-money-button {
            background-color: skyblue;
            color: white;
        }

        /*===============================*/
    </style>

    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f9f9f9;
            color: #333;
        }

        #formContainer {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .pair {
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        .pair h4 {
            margin-top: 0;
        }

        label {
            display: block;
            margin: 8px 0 4px;
        }

        input {
            width: 100%;
            padding: 6px 8px;
            margin-bottom: 8px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            background-color: #007BFF;
            /* Bootstrap Blue */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }





        .output {
            margin-top: 10px;
            font-size: 1rem;
            font-weight: 500;
        }
    </style>
    <style>
        .header {
            background-color: #333;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h2 {
            margin: 0;
            font-size: 20px;
        }

        .logout-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .logout-btn:hover {
            background-color: #c0392b;
        }

        .content {
            padding: 40px;
            text-align: center;
        }

        .content p {
            font-size: 18px;
            color: #333;
        }
    </style>
    </style>
    <style>
        form#rateForm {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            font-family: Arial, sans-serif;
        }

        form#rateForm h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form#rateForm div {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            align-items: center;
        }

        form#rateForm label {
            font-weight: bold;
            width: 100px;
        }

        form#rateForm input {
            width: 100%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            transition: border-color 0.3s ease;
        }

        form#rateForm input:focus {
            border-color: #007bff;
            outline: none;
        }

        form#rateForm button {
            width: 100%;
            padding: 10px 0;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        form#rateForm button:hover {
            background: #0056b3;
        }

        #response {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
    </style>
    <style>
        .table-responsive {
            overflow-x: auto;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead {
            background-color: #007bff;
            color: #ffffff;
        }

        .table thead th {
            font-weight: 600;
            text-transform: uppercase;
        }

        .table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .table td,
        .table th {
            padding: 12px;
            vertical-align: middle;
        }

        .text-success {
            color: #28a745;
        }

        .text-danger {
            color: #dc3545;
        }
    </style>
</head>

<body>
    <div class="header">
        <h2>Welcome Admin!</h2>
        <a href="logout_admin.php" class="logout-btn">Logout</a>
    </div>

    <!--<div class="content">
        <p>You are logged in.</p>
    </div>-->
    <div class="container">
        <h2>Send Email</h2>
        <input type="text" id="userId" placeholder="Enter User ID">
        <button class="kyc-button" onclick="sendEmail('kyc')">Send KYC Mail</button>
        <button class="liquidity-button" onclick="sendEmail('liquidity')">Send Liquidity Agreement Mail</button>
        <button class="deposit-button" onclick="sendEmail('deposit')">Send Buy Deposit Mail</button>
        <button class="receive-money-button" onclick="sendEmail('receiveMoney')">Send Buy Receive Money Mail</button>
        <button class="sell-deposit-button" onclick="sendEmail('deposit')">Send sell Deposit Mail</button>
        <button class="sell-receive-money-button" onclick="sendEmail('receiveMoney')">Send sell Receive Money
            Mail</button>

    </div>


    <script>


        document.addEventListener("DOMContentLoaded", function () {
            function sendEmail(mailType) {
                const userId = document.getElementById("userId").value;
                if (!userId) {
                    alert("Please enter a User ID");
                    return;
                }

                fetch("send_mail.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: `user_id=${encodeURIComponent(userId)}&mail_type=${encodeURIComponent(mailType)}`,
                })
                    .then((response) => response.json())
                    .then((data) => {
                        alert(data.message);
                    })
                    .catch((error) => {
                        console.error("Error:", error);
                        alert("An error occurred while sending the email.");
                    });
            }

            document.querySelector(".kyc-button").addEventListener("click", function () {
                sendEmail("kyc");
            });

            document.querySelector(".liquidity-button").addEventListener("click", function () {
                sendEmail("liquidity");
            });

            document.querySelector(".deposit-button").addEventListener("click", function () {
                sendEmail("deposit");
            });

            document.querySelector(".receive-money-button").addEventListener("click", function () {
                sendEmail("receiveMoney");
            });
        });

    </script>

    <script>


        document.addEventListener("DOMContentLoaded", function () {
            function sendEmail(mailType) {
                const userId = document.getElementById("userId").value;
                if (!userId) {
                    alert("Please enter a User ID");
                    return;
                }

                fetch("send_sell_mail.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: `user_id=${encodeURIComponent(userId)}&mail_type=${encodeURIComponent(mailType)}`,
                })
                    .then((response) => response.json())
                    .then((data) => {
                        alert(data.message);
                    })
                    .catch((error) => {
                        console.error("Error:", error);
                        alert("An error occurred while sending the email.");
                    });
            }

            document.querySelector(".sell-deposit-button").addEventListener("click", function () {
                sendEmail("deposit");
            });

            document.querySelector(".sell-receive-money-button").addEventListener("click", function () {
                sendEmail("receiveMoney");
            });


        });

    </script>

    <h2>Update Transaction Charges</h2>
    <form id="chargesForm">
        <div id="formContainer"></div>
        <button type="submit">Save Changes</button>
    </form>

    <script>
        async function loadCharges() {
            const response = await fetch('get_charges.php');
            const data = await response.json();
            const container = document.getElementById("formContainer");

            Object.entries(data).forEach(([pair, info]) => {
                const div = document.createElement('div');
                div.className = 'pair';
                div.innerHTML = `<h4>${pair}</h4>
                    <label>Base: <input name="${pair}_base" value="${info.base}" /></label>`;

                info.tiers.forEach((tier, i) => {
                    div.innerHTML += `
                        <label>Tier ${i + 1} Limit: <input name="${pair}_limit_${i}" value="${tier.limit}" /></label>
                        <label>Tier ${i + 1} Charge: <input name="${pair}_charge_${i}" value="${tier.charge}" /></label>
                    `;
                });
                container.appendChild(div);
            });
        }

        document.getElementById("chargesForm").addEventListener("submit", async function (e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            const response = await fetch("save_charges.php", {
                method: "POST",
                body: formData
            });
            const result = await response.text();
            alert(result);
        });

        loadCharges();
    </script>

    <section>

        <h2>Update Fixed Exchange Rates</h2>
        <form id="rateForm">
            <div>
                <label>USD:</label>
                <input type="number" step="0.0001" name="rates[USD]" value="1.00">
            </div>
            <div>
                <label>SGD:</label>
                <input type="number" step="0.0001" name="rates[SGD]" value="1.31044">
            </div>

            <div>
                <label>THB:</label>
                <input type="number" step="0.0001" name="rates[THB]" value="32.66477">
            </div>

            <div>
                <label>MYR:</label>
                <input type="number" step="0.0001" name="rates[MYR]" value="4.23250">
            </div>

            <div>
                <label>JPY:</label>
                <input type="number" step="0.0001" name="rates[JPY]" value="142.72367">
            </div>

            <div>
                <label>HKD:</label>
                <input type="number" step="0.0001" name="rates[HKD]" value="7.75099">
            </div>

            <div>
                <label>CNY:</label>
                <input type="number" step="0.0001" name="rates[CNY]" value="4.23250">
            </div>

            <div>
                <label>AUD:</label>
                <input type="number" step="0.0001" name="rates[AUD]" value="4.23250">
            </div>

            <div>
                <label>PHP:</label>
                <input type="number" step="0.0001" name="rates[PHP]" value="55.42709">
            </div>



            <div>
                <label>EUR:</label>
                <input type="number" step="0.0001" name="rates[EUR]" value="0.88136">
            </div>
            <div>
                <label>INR:</label>
                <input type="number" step="0.0001" name="rates[INR]" value="84.31756">
            </div>

            <div>
                <label>GBP:</label>
                <input type="number" step="0.00000001" name="rates[GBP]" value="0.74810">
            </div>
            <button type="submit">Update Rates</button>
        </form>

        <div id="response"></div>

    </section>
    <script>
        document.getElementById('rateForm').addEventListener('submit', async function (e) {
            e.preventDefault();
            const formData = new FormData(this);

            const response = await fetch('updateRates.php', {
                method: 'POST',
                body: formData
            });

            document.getElementById('response').textContent = await response.text();
        });
    </script>
    <section>
        <div class="container mt-5">
            <h2 class="mb-4">Transaction Records</h2>

            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User ID</th>
                            <th>Referred by</th>
                            <th>Amount Sent</th>
                            <th>Currency Sent</th>
                            <th>Amount Received</th>
                            <th>Currency Received</th>
                            <th>Profit APA</th>
                            <th>Profit Madocks</th>
                        </tr>
                    </thead>
                    <tbody id="recordsTableBody">
                        <!-- Data will be populated here by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            fetch("fetchRecords.php")
                .then(response => response.json())
                .then(data => {
                    const tableBody = document.getElementById("recordsTableBody");
                    tableBody.innerHTML = "";

                    if (data.status === "success") {
                        data.records.forEach(record => {
                            const row = `
                            <tr>
                                <td>${record.id}</td>
                                <td>${record.user_id}</td>
                                <td>${record.referred_by}</td>
                                <td>${record.amount_send}</td>
                                <td>${record.currency_send}</td>
                                <td>${record.amount_receive}</td>
                                <td>${record.currency_receive}</td>
                                <td>${record.profit_apa}</td>
                                <td>${record.profit_madocks}</td>
                            </tr>
                        `;
                            tableBody.innerHTML += row;
                        });
                    } else {
                        tableBody.innerHTML = `<tr><td colspan="8" class="text-center text-danger">${data.message}</td></tr>`;
                    }
                })
                .catch(error => {
                    console.error("Error fetching records:", error);
                });
        });
    </script>

</body>

</html>