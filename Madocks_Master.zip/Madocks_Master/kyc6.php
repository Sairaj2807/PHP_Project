<?php
session_start();
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <style>
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            z-index: 1000;
            /* Ensure it's above everything else */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            /* Dark overlay */
            overflow-y: auto;
            /* Allow scrolling within the modal */
        }

        /* Prevent background from scrolling when modal is open */
        body.modal-open {
            overflow: hidden;
        }


        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }

        .close-btn {
            cursor: pointer;
            font-size: 24px;
        }

        .modal-body {
            padding: 20px 0;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input,
        select textarea {

            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;

        }






        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .clicked {
            background-color: #28a745 !important;
            /* Green color to indicate success */
            transform: scale(0.95);
        }

        .reference-code {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .circle {
            width: 200px;
            height: 200px;
            background: white;
            border-radius: 50%;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            position: relative;
        }

        .circle span {
            color: #007bff;
        }

        .options {
            color: black;
            display: flex;
            flex-direction: column;
            gap: 30px;
            margin-left: 80px;
        }

        .option {
            color: black;
            display: flex;
            align-items: center;
            background: white;
            padding: 15px;
            border-radius: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            justify-content: space-between;
            position: relative;
        }

        .icon {
            width: 40px;
            height: 40px;
            background: #f0f8ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
        }

        .text {
            text-align: left;
            flex: 1;
        }

        .text h3 {
            margin: 0;
            font-size: 16px;
            color: #007bff;
        }

        .text p {
            margin: 5px 0 0;
            font-size: 14px;
            color: #555;
        }

        .btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .modaldeposit {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modaldeposit-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modaldeposit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        input[type="file"],
        input[type="text"] {
            display: block;
            margin: 10px 0;
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }


        .modal2 {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        /*.modal2-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }*/

        .modal2-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;

            overflow-y: auto;
            /* Enable vertical scrolling */
            max-height: 80vh;
        }

        .modal2-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .reference-code2 {
            font-weight: bold;
            color: black;
            font-size: 16px;
            margin-top: 10px;
            text-align: left;
        }

        .btn:disabled {
            background: gray;
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>

    <style>
        /* Base Styles */
        .reference-code strong {
            font-size: 16px;
            color: #2c3e50;
            display: block;
            margin-bottom: 20px;
        }

        /* Tooltip styling */
        .tooltip-icon {
            display: inline-block;
            margin-left: 8px;
            background-color: #4a90e2;
            color: white;
            font-size: 12px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            text-align: center;
            line-height: 20px;
            position: relative;
            cursor: pointer;
        }

        .tooltip-text {
            visibility: hidden;
            width: 250px;
            background-color: #333;
            color: #fff;
            text-align: left;
            padding: 10px;
            border-radius: 6px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            /* Position above icon */
            left: 50%;
            margin-left: -125px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 13px;
        }

        .tooltip-icon:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }

        h2 {
            color: #007aa3;
            font-size: 14px;
            text-transform: uppercase;
        }

        p,
        li {
            font-size: 12px;
            line-height: 1.6;
        }

        ul {
            padding-left: 20px;
        }

        .section {
            margin-bottom: 20px;
        }

        .form-group {
            margin: 10px 0;
        }

        label {
            margin-top: 10px;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 6px;
            font-size: 12px;
        }

        .footer {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            align-items: center;
        }

        .checkbox input {
            height: 1em;
            width: 1em;
            vertical-align: middle;
        }

        button {
            padding: 8px 16px;
            background-color: #007aa3;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #005f7a;
        }



        .clear-button {
            margin-top: 5px;
            background-color: #999;
        }

        .checkbox label {
            cursor: pointer;
        }
    </style>
    <style>
        @media (max-width: 768px) {

            .modal-content,
            .modaldeposit-content,
            .modal2-content {
                width: 90% !important;
                margin: 20% auto !important;
                padding: 15px;
            }

            .options {
                margin-left: 0;
                gap: 20px;
                align-items: center;
            }

            .option {
                flex-direction: column;
                align-items: flex-start;
                width: 100%;
                padding: 10px;
            }

            .icon {
                margin-right: 0;
                margin-bottom: 10px;
            }

            .text {
                text-align: left;
                width: 100%;
            }

            .container {
                flex-direction: column;
            }

            .circle {
                width: 150px;
                height: 150px;
                font-size: 16px;
                margin-bottom: 20px;
            }

            .btn {
                width: 100%;
            }

            input[type="text"],
            input[type="date"],
            input[type="file"],
            select,
            textarea {
                font-size: 14px;
            }

            .tooltip-text {
                width: 200px;
                margin-left: -100px;
                font-size: 12px;
            }

            .footer {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
    <style>
        button:active::after {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 120%;
            height: 120%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%) scale(0);
            border-radius: 50%;
            animation: clickEffect 0.4s ease-out;
        }

        @keyframes clickEffect {
            to {
                transform: translate(-50%, -50%) scale(1);
                opacity: 0;
            }
        }
    </style>
    <style>
        #loadingOverlay {
            display: none;
            /* Hidden by default */
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            color: white;
            font-size: 1.5rem;
        }

        #loadingOverlay1 {
            display: none;
            /* Hidden by default */
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            color: white;
            font-size: 1.5rem;
        }
    </style>

</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!---<div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>--->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
    <div class="popup-inner">
        <div class="upper-box clearfix">
            <figure class="logo-box pull-left"><a href="new_index.php"><img src="assets/images/logonew.png"
                        alt=""></a></figure>
            <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <div class="overlay-layer"></div>
        <div class="auto-container">
            <div class="search-form">
                <form method="post" action="new_index.php">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value=""
                                placeholder="Type your keyword and hit" required>
                            <button type="submit"><i class="flaticon-loupe"></i></button>
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                    Us</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                                <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="new_index.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                            <a href="logout.php">Logout</a>
                        </li>
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                            <a href="register.php">Signup</a>
                        </li>
                    </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="new_index.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="current dropdown"><a href="new_index.php">Home</a>
                                            <!---<ul>
                                        <li><a href="new_index.php">Home One</a></li>
                                        <li><a href="new_index.php">Home Two</a></li>
                                        <li><a href="new_index.php">Home Three</a></li>
                                    </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                        <li><a href="marketsl.php">Markets</a></li>
                                        <li><a href="market-details.html">Details Page</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                        <li><a href="platform.php">Platform</a></li>
                                        <li><a href="account.html">Our Accounts</a></li>
                                        <li><a href="account-details.html">Standard Account</a></li>
                                        <li><a href="account-details-2.html">Commision Account</a></li>
                                        <li><a href="account-details-3.html">STP Pro Account</a></li>
                                    </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="new_index.php">Education</a>
                                    <ul>
                                        <li><a href="education.html">Education</a></li>
                                        <li><a href="education-details.html">Detail Page</a></li>
                                    </ul>
                                </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                        <li><a href="about.html">Company</a></li>
                                        <li><a href="history.html">History</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li class="dropdown"><a href="new_index.php">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">3 Columns</a></li>
                                                <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                <li><a href="blog-3.html">List View 01</a></li>
                                                <li><a href="blog-4.html">List View 02</a></li>
                                                <li><a href="blog-details.html">Single Post</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                        <li><a href="faq.html">Faq’s</a></li>
                                        <li><a href="error.html">404</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="dropdown"><a href="usdt_main_page_change8.php">USDT</a>

                                        </li>
                                        <!--<li class="dropdown"><a href="sneat/html/index.html">Dashboard</a> </li>-->
                                    </ul>
                                </div>
                            </nav>
                            <!--<div class="menu-right-content">

                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="" class="theme-btn btn-one">
                                
                            </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                            <!--<div class="menu-right-content">
                        <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                        <div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                                



                         </a></div>
                    </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="new_index.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="new_index.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                Here</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="new_index.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- banner-style-three -->
        <section class="banner-style-three centred">

            <div class="container">
                <!-- Circular Infographic -->
                <div class="circle">
                    KYC <br> <span></span>
                </div>

                <!-- Connecting Lines -->
                <div class="line-container">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </div>

                <!-- Option Boxes -->
                <div class="options">
                    <!-- Option A -->
                    <div class="option">
                        <div class="icon">👤</div>
                        <div class="text">
                            <h3>KYC submission</h3>
                            <p>Status: <span id="kyc-status" style="color: orange;">Pending</span></p>
                        </div>
                        <button class="btn" id="kyc-btn" onclick="openModal()">Select</button>
                    </div>

                    <!-- Option B -->
                    <div class="option">
                        <div class="icon">🎫</div>
                        <div class="text">
                            <h3>Liquidity agreement</h3>
                            <p>Status: <span id="agreement-status" style="color: orange;">Pending</span> </p>

                        </div>
                        <button class="btn" id="step2-btn" onclick="openModal2()">Select</button>
                    </div>



                </div>
            </div>

        </section>


        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode();
            });

            function generateReferenceCode() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });

        </script>

        <script>
            document.addEventListener("DOMContentLoaded", function () {
                generateReferenceCode2();
            });

            function generateReferenceCode2() {
                let refCode = "MADOCKS" + Math.floor(10000 + Math.random() * 90000);
                document.getElementById("referenceCodeDisplay2").innerText = "Reference Code: " + refCode;
                document.getElementById("referenceCode2").value = refCode; // Ensure value is set correctly
                console.log("Generated Reference Code:", refCode); // Debugging output
            }

            // Ensure reference code is included before form submission
            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                let refCodeInput = document.getElementById("referenceCode2").value;
                console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                if (!refCodeInput) {
                    alert("Reference Code is missing. Please reload the page.");
                    event.preventDefault();
                }
            });
        </script>

        <div id="usdtModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>USDT Onboarding</h2>
                    <span class="close-btn" onclick="closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <h3>KYC APPLICATION</h3>
                    <h4>INDIVIDUAL DETAILS</h4>

                    <form id="usdtOnboardingForm">
                        <div class="reference-code">
                            <strong id="referenceCodeDisplay"></strong>
                        </div>
                        <input type="hidden" id="referenceCode" name="referenceCode">

                        <!--<label for="apaEmployee">Name of the MADOCKS employee spoken to</label>--->
                        <input type="hidden" id="apaEmployee" name="apaEmployee">

                        <label for="fullName">Full Name as per Passport/ID *</label>
                        <input type="text" id="fullName" name="fullName" required>

                        <label for="dob">Date of Birth *</label>
                        <input type="date" id="dob" name="dob" placeholder="DDMMYYYY" required>

                        <label for="nationality">Nationality *</label>
                        <select id="nationality" name="nationality" required>
                            <option value="">Select Country</option>
                            <!-- Major Countries -->
                            <option value="US">United States</option>
                            <option value="SG">Singapore</option>
                            <option value="IN">India </option>
                            <option value="UK">United Kingdom</option>
                            <option value="CA">Canada </option>
                            <option value="AU">Australia </option>
                            <option value="DE">Germany </option>
                            <option value="FR">France </option>
                            <option value="IT">Italy </option>
                            <option value="ES">Spain </option>
                            <option value="CN">China</option>
                            <option value="JP">Japan</option>
                            <option value="KR">South Korea</option>
                            <option value="BR">Brazil</option>
                            <option value="ZA">South Africa</option>
                            <option value="MX">Mexico</option>
                            <option value="RU">Russia</option>
                            <option value="AE">United Arab Emirates</option>
                            <option value="SA">Saudi Arabia</option>

                            <option value="NZ">New Zealand</option>
                            <option value="NG">Nigeria</option>
                            <option value="EG">Egypt</option>
                            <option value="AR">Argentina</option>
                            <option value="TR">Turkey</option>
                            <option value="SE">Sweden</option>
                            <option value="CH">Switzerland</option>
                            <option value="NL">Netherlands</option>
                            <option value="BE">Belgium</option>
                            <option value="PL">Poland</option>

                            <!-- South East Asian Countries -->
                            <option value="ID">Indonesia</option>
                            <option value="MY">Malaysia</option>
                            <option value="TH">Thailand</option>
                            <option value="PH">Philippines</option>
                            <option value="VN">Vietnam</option>
                            <option value="MM">Myanmar</option>
                            <option value="KH">Cambodia</option>


                        </select>

                        <label for="address1">Address Line 1 *</label>
                        <input type="text" id="address1" name="address1" required>

                        <label for="address2">Address Line 2</label>
                        <input type="text" id="address2" name="address2">

                        <label for="address3">Address Line 3</label>
                        <input type="text" id="address3" name="address3">

                        <label for="postcode">Postcode *</label>
                        <input type="text" id="postcode" name="postcode" required>

                        <label for="mobile">Mobile Number *</label>
                        <div style="display: flex; align-items: center; gap: 5px;">
                            <select id="countryCode" name="countryCode" required style="padding: 4px;">
                                <option value="+65">🇸🇬 +65 (Singapore)</option>
                                <option value="+91">🇮🇳 +91 (India) </option>
                                <option value="+1">🇺🇸 +1 (USA)</option>
                                <option value="+44">🇬🇧 +44 (UK)</option>
                                <option value="+61">🇦🇺 +61 (Australia)</option>
                                <option value="+81">🇯🇵 +81 (Japan)</option>

                                <option value="+62">🇮🇩 +62 (Indonesia)</option>
                                <option value="+60">🇲🇾 +60 (Malaysia)</option>
                                <option value="+66">🇹🇭 +66 (Thailand)</option>
                                <option value="+84">🇻🇳 +84 (Vietnam)</option>
                                <option value="+63">🇵🇭 +63 (Philippines)</option>
                                <option value="+95">🇲🇲 +95 (Myanmar)</option>
                                <option value="+856">🇱🇦 +856 (Laos)</option>
                                <option value="+855">🇰🇭 +855 (Cambodia)</option>
                                <option value="+673">🇧🇳 +673 (Brunei)</option>
                                <option value="+670">🇹🇱 +670 (Timor-Leste)</option>

                                <!-- Add more countries as needed -->
                            </select>
                            <input type="text" id="mobile" name="mobile" placeholder="Enter mobile number" required
                                style="flex: 1; padding: 4px;">
                        </div>


                        <label for="passportId">Passport/ID Number *</label>
                        <input type="text" id="passportId" name="passportId" required>

                        <label for="country">Country *</label>
                        <select id="country" name="country" required>
                            <option value="">Select Country</option>
                            <!-- Major Countries -->
                            <option value="US">United States</option>
                            <option value="SG">Singapore</option>
                            <option value="IN">India</option>
                            <option value="UK">United Kingdom</option>
                            <option value="CA">Canada</option>
                            <option value="AU">Australia</option>
                            <option value="DE">Germany</option>
                            <option value="FR">France</option>
                            <option value="IT">Italy</option>
                            <option value="ES">Spain</option>
                            <option value="CN">China</option>
                            <option value="JP">Japan</option>
                            <option value="KR">South Korea</option>
                            <option value="BR">Brazil</option>
                            <option value="ZA">South Africa</option>
                            <option value="MX">Mexico</option>
                            <option value="RU">Russia</option>
                            <option value="AE">United Arab Emirates</option>
                            <option value="SA">Saudi Arabia</option>

                            <option value="NZ">New Zealand</option>
                            <option value="NG">Nigeria</option>
                            <option value="EG">Egypt</option>
                            <option value="AR">Argentina</option>
                            <option value="TR">Turkey</option>
                            <option value="SE">Sweden</option>
                            <option value="CH">Switzerland</option>
                            <option value="NL">Netherlands</option>
                            <option value="BE">Belgium</option>
                            <option value="PL">Poland</option>

                            <!-- South East Asian Countries -->
                            <option value="ID">Indonesia</option>
                            <option value="MY">Malaysia</option>
                            <option value="TH">Thailand</option>
                            <option value="PH">Philippines</option>
                            <option value="VN">Vietnam</option>
                            <option value="MM">Myanmar</option>
                            <option value="KH">Cambodia</option>


                        </select>

                        <label for="occupation">Occupation *</label>
                        <input type="text" id="occupation" name="occupation" required>

                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" required>

                        <label for="currencies">Currencies Required *</label>
                        <select id="currencies" name="currencies[]" multiple required>
                            <option value="SGD">SGD - Singapore Dollar</option>
                            <option value="USD">USD - US Dollar</option>
                            <option value="THB">THB - Thai Baht</option>
                            <option value="MYR">MYR - Malaysian Ringgit</option>
                            <option value="INR">INR - Indian Rupee</option>
                            <option value="JPY">JPY - Japanese Yen</option>
                            <option value="EUR">EUR - Euro</option>
                            <option value="HKD">HKD - Hong Kong Dollar</option>
                            <option value="CNY">CNY - Chinese Yuan</option>

                            <option value="AUD">AUD - Australian Dollar</option>
                            <option value="GBP">GBP - British Pound</option>
                            <option value="PHP">PHP - Philippine Peso</option>
                            <option value="USDT">USDT - Tether</option>
                        </select>
                        <!--<input type="hidden" id="currencies" name="currencies" required>--->
                        <!---<div id="selected-currencies" style="margin-top: 10px; font-weight: bold; "></div>--->




                        <label for="sourceWealth">
                            Source of Wealth *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Proof of how client makes money:<br>
                                    • Employment Letter<br>
                                    • Pay slips<br>
                                    • Sale and Purchase agreement<br>
                                    • Investment portfolio<br>
                                    • Inheritance<br>
                                    • Gift letter
                                </span>
                            </span>
                        </label>
                        <input type="file" id="sourceWealth" name="sourceWealth" required>

                        <label for="proofIdentity">
                            Proof of Identity *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Government issued ID:<br>
                                    • Passport<br>
                                    • Valid driver's licence<br>
                                    • NRIC
                                </span>
                            </span>
                        </label>
                        <input type="file" id="proofIdentity" name="proofIdentity" required>

                        <label for="proofAddress">
                            Proof of Address (issued within 3 months) *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Dated within last 3 months:<br>
                                    • Bank statements<br>
                                    • Utility bills<br>
                                    • Driver's license / NRIC<br>
                                    • Signed tenancy agreement (within 1 year)<br>
                                    • Mortgage loan statement
                                </span>
                            </span>
                        </label>
                        <input type="file" id="proofAddress" name="proofAddress" required>

                        <label for="sourceFunds">
                            Source of Funds *
                            <span class="tooltip-icon">?
                                <span class="tooltip-text">
                                    Proof to show client can afford trades:<br>
                                    • Bank statements showing sufficient balance
                                </span>
                            </span>
                        </label>
                        <input type="file" id="sourceFunds" name="sourceFunds" required>

                        <label for="annualVolume">Estimated Annual Transaction Volume (USD) *</label>
                        <input type="text" id="annualVolume" name="annualVolume" required>

                        <label for="accountReason">Reason for Account Opening *</label>
                        <textarea id="accountReason" name="accountReason" required></textarea>

                        <h2>Confirmation and Submission 确认和提交</h2>
                        <p>By submitting this form to the APA Group, you confirm and agree:</p>

                        <div class="section1">
                            <ol>
                                <li>This Individual Application form, together with the Terms and Conditions (the
                                    “Terms”) and the Supplemental Terms and Conditions (as applicable) (the
                                    “Supplemental Terms”), comprise the entire agreement between the Company and the APA
                                    Group related to the Services (the “Agreement”). This Agreement is entered into by
                                    and between the Individual and APA Canada Tech Limited, a company incorporated under
                                    the laws of the Province of Alberta, Canada (Individual Access Number 2025006178)
                                    with its registered address of 428-1001 1st Street SE, Calgary, Alberta, T2G 5G3,
                                    Canada, which is registered as an MSB in Canada with the Financial Transactions and
                                    Reports Analysis Centre of Canada (Canadian MSB Registration Number M23328908)
                                    (“APA”). You acknowledge that APA may engage other companies within the APA Group to
                                    perform services under this agreement. For the purposes of this Agreement, the “APA
                                    Group” shall refer to APA and its’ affiliates, including: (i) Atlantic Partners Asia
                                    (SG) Pte Limited, a company incorporated in Singapore (Company Number 201841045G)
                                    with its registered office at 7A Stanley Street, Singapore 068726 (Major Payment
                                    Institute License No. 20200516), (ii) Atlantic Partners Asia PS Limited, a company
                                    incorporated in Hong Kong SAR (Company Number 2816539) with its registered office at
                                    Flat/RM 2005 20/F Kinwick Centre 31 Hollywood Road Mid-Levels Central, Hong Kong,
                                    which holds an MSO License in Hong Kong (License No. 20-12-02993), (iii) Atlantic
                                    Partners Asia (MY) SDN BHD, a company incorporated in Malaysia (Company Number
                                    202201040529 (1486226X) with its registered address at Unit 25-13, Q Sentral, Jalan
                                    Stesen Sentral 2, KL Sentral, 50470 W.P. Kuala Lumpur, Malaysia, (iv) Atlantic
                                    Partners Asia Management (Cayman) Limited, a company incorporated in the Cayman
                                    Islands (Company Number 270943) with its registered address at Floor 4, Willow
                                    House, Cricket Square, Grand Cayman KYl-9010, Cayman Islands, (v) Atlantic Partners
                                    Asia Canada Limited, a company incorporated under the laws of the Province of
                                    Ontario, Canada (Ontario Corporation Number 1000612208), with a registered address
                                    of 120 Adelaide Street West, Suite 2500, Toronto, Ontario, M5H 1T1, Canada (Canadian
                                    MSB Registration Number M23484752), (vi) Redbanx Limited, a company incorporated in
                                    England and Wales (Company Number 10452111) with its registered address at 11
                                    Woodford Avenue, Ilford, England, IG2 6UF, which holds a UK EMI License (License No.
                                    900897), (vii) Atlantic Partners Africa (Pty) Ltd, a company incorporated in South
                                    Africa (Company Number K2019340083) with its registered address at Office 09, 1st
                                    Floor, 35 Ferguson, 35 Ferguson Road, Illovo, Johannesburg, 2196, Gauteng, South
                                    Africa, which holds an FSP (Financial Services Provider) Category II (Discretionary)
                                    License (License No: 36823), and (viii) Atlantic Partners Asia PS Pty Ltd, a company
                                    incorporated in New South Wales (Company Number 633 838 481) with its registered
                                    address at 10.02, Level 10, 109 Pitt Street, Sydney, NSW, 2000, Australia.

                                    本個人申請表格連同條款和條件（以下稱為「條款」）及補充條款和條件（如適用，以下稱為「補充條款」）構成公司與APA集團之間關於服務的完整協議（以下稱為「協議」）。本協議由您與APA
                                    Canada Tech Limited簽訂，該公司依據加拿大阿爾伯塔省法律成立（公司註冊號碼2025006178），其註冊地址為428-1001 1st Street
                                    SE, Calgary, Alberta, T2G 5G3,
                                    Canada，並且在加拿大於金融交易和報告分析中心登記為MSB（加拿大MSB註冊號碼M23328908）（以下稱為「APA」）。您承認APA可以聘用APA集團內的其他公司來執行本協議下的服務。根據本協議，「APA集團」指APA及其附屬公司，包括：（i）Atlantic
                                    Partners Asia (SG) Pte Limited，該公司在新加坡成立（公司編號201841045G），註冊辦公地址為7A Stanley Street,
                                    Singapore 068726（主要支付機構許可證號碼20200516），（ii）Atlantic Partners Asia PS
                                    Limited，該公司在香港特別行政區成立（公司編號2816539），註冊辦公地址為Flat/RM 2005 20/F Kinwick Centre 31
                                    Hollywood Road Mid-Levels Central, Hong
                                    Kong，持有香港MSO許可證（許可證號碼20-12-02993），（iii）Atlantic Partners Asia (MY) SDN
                                    BHD，該公司在馬來西亞成立（公司編號202201040529 (1486226X)），註冊地址為Unit 25-13, Q Sentral, Jalan Stesen
                                    Sentral 2, KL Sentral, 50470 W.P. Kuala Lumpur, Malaysia，（iv）Atlantic Partners Asia
                                    Management (Cayman) Limited，該公司在開曼群島成立（公司編號270943），註冊地址為Floor 4, Willow House,
                                    Cricket Square, Grand Cayman KY1-9010, Cayman Islands，（v）Atlantic Partners Asia
                                    Canada Limited，該公司依據加拿大安大略省法律成立（安大略省公司編號1000612208），註冊地址為120 Adelaide Street West,
                                    Suite 2500, Toronto, Ontario, M5H 1T1, Canada（加拿大MSB註冊號碼M23484752），（vi）Redbanx
                                    Limited，該公司在英格蘭和威爾士成立（公司編號10452111），註冊地址為11 Woodford Avenue, Ilford, England, IG2
                                    6UF，持有英國EMI許可證（許可證號碼900897），（vii）Atlantic Partners Africa (Pty)
                                    Ltd，該公司在南非成立（公司編號K2019340083），註冊地址為Office 09, 1st Floor, 35 Ferguson, 35 Ferguson
                                    Road, Illovo, Johannesburg, 2196, Gauteng, South
                                    Africa，持有FSP（金融服務提供者）第二類（自主）許可證（許可證號碼36823），以及（viii）Atlantic Partners Asia PS Pty
                                    Ltd，該公司在新南威爾士州成立（公司編號633 838 481），註冊地址為10.02, Level 10, 109 Pitt Street, Sydney,
                                    NSW, 2000, Australia。</li>
                                <li>References in this Agreement to “you”, “your”, “yours” and “Client” are to you, the
                                    customer of APA.

                                    本協議中提及的「您」、「您的」、「屬於您的」及「客戶」均指您，即APA的客戶。</li>
                                <li>In this Agreement, you and the APA Group are referred to jointly as the Parties and
                                    each a Party in the singular.

                                    在本協議中，您和APA集團共同被稱為「各方」，單數形式則稱為「一方」。</li>
                                <li>Notwithstanding any other authorization or instruction provided by you to the APA
                                    Group, the APA Group is authorized to act on the authorizations or instructions
                                    provided in this form without further checks, even if the authorizations or
                                    instructions may contradict any other instructions provided by you to the APA Group.

                                    儘管您向APA集團提供了其他授權或指示，APA集團獲授權根據本表格中提供的授權或指示行事，而無需進一步檢查，即使該授權或指示可能與您向APA集團提供的其他指示相抵觸。
                                </li>
                                <li>You have read and understood the APA Group’s prevailing Terms and Supplemental Terms
                                    (as applicable), a copy of which has been provided to you, and you agree to be bound
                                    by all the terms therein and any amendments or variation thereof. You further agree
                                    and acknowledge that there are other terms and conditions and agreement(s) intended
                                    or expressed to govern the use of other relevant products and services offered by
                                    APA and you confirm your agreement and acceptance of the same, including but not
                                    necessarily limited to the Supplemental Terms (as applicable). We reserve the right
                                    to amend, remove, or add to this Agreement, the Terms and Supplemental Terms (as
                                    applicable) at any time, and from time to time, in our sole discretion. Your use of
                                    any product or service after the posting of modifications to this Agreement, the
                                    Terms and Supplemental Terms (as applicable) constitutes your acceptance of this
                                    Agreement, as modified. A copy of APA’s prevailing Terms and Supplemental Terms (as
                                    applicable) and can be obtained upon request.

                                    您已閱讀並理解APA集團的現行條款及補充條款（如適用），並已提供給您副本，您同意遵守其中的所有條款及其任何修訂或變更。您進一步同意並承認，還有其他條款及條件和協議旨在或明示用以管理APA提供的其他相關產品及服務的使用，您確認對此的協議和接受，包括但不限於補充條款（如適用）。我們保留隨時自行決定修訂、刪除或新增本協議、條款及補充條款（如適用）的權利。您在本協議、條款及補充條款（如適用）修訂後使用任何產品或服務，即表示您接受本協議的修改版本。APA的現行條款及補充條款（如適用）的副本可應要求獲得。
                                </li>

                                <li>You may provide personal information to APA in connection with your establishing and
                                    maintaining your relationship with the APA Group. You confirm that all information
                                    provided, and documents submitted by you are true, complete and accurate and that
                                    you have consent and authority to share such information with us. When providing any
                                    personal information to the APA Group, you confirm that you are lawfully providing
                                    the data for the APA Group to use and disclose for the purposes of:

                                    您可能會向APA提供個人信息，以建立和維持與APA集團的關係。您確認所有提供的信息和提交的文件均為真實、完整和準確的，並且您擁有分享該信息的同意和授權。當您向APA集團提供任何個人信息時，您確認您合法地提供該數據，以便APA集團使用和披露，目的包括：
                                    <ul>
                                        <li>providing products or services to you;

                                            向您提供產品或服務；</li>
                                        <li>managing the operational, administrative and risk management requirements
                                        </li>
                                        <li>meeting the operational, administrative and risk management requirements of
                                            the APA Group; and

                                            滿足APA集團的運營、行政和風險管理要求；以及</li>
                                        <li>complying with any requirement, as APA Group reasonably deems necessary,
                                            under any law or of any court, government authority or regulator

                                            遵守APA集團合理認為根據任何法律或任何法院、政府機構或監管機構的要求所需的任何要求。</li>
                                    </ul>
                                </li>
                                <li>All of your personal information will be collected by us in accordance [with the
                                    above and not for any other purpose without your express consent /OR/ the Privacy
                                    Policy at [link]. The Privacy Policy is incorporated in its entirety into and should
                                    be read in conjunction with this Agreement. We reserve the right to update the
                                    Privacy Policy at any time, and from time to time, in our sole discretion.

                                    我們將根據上述內容收集您的所有個人信息，並不會在未經您明示同意的情況下出於其他目的使用該信息 /
                                    或根據[鏈接]的隱私政策。隱私政策已全部納入本協議中，並應與本協議共同閱讀。我們保留隨時自行決定更新隱私政策的權利。</li>
                                <li>This Agreement represents an agreement made by and between you and the APA Group and
                                    has the binding effect of a legal contract and should be read carefully and in its
                                    entirety, prior to using any product or service. Your access to, and use of, any
                                    product or service is conditional upon your acceptance of, and compliance with, this
                                    Agreement.

                                    本協議代表您與APA集團之間的協議，具備法律合同的約束力，應在使用任何產品或服務之前仔細且完整地閱讀。您訪問及使用任何產品或服務的前提是您接受並遵守本協議。</li>
                            </ol>
                        </div>

                        <!-- Checkbox Section -->
                        <div class="checkbox">
                            <input type="checkbox" id="confirm-info" name="confirm-info" required>
                            <label for="confirm-info">
                                <p> I/we have read and understood APA’s prevailing Terms and
                                    Condition and agree to be bound by all the terms therein and any amendments or
                                    variation
                                    thereof. I/we further agree and acknowledge that there are other terms and
                                    conditions
                                    and agreement(s) intended or expressed to govern the use of other relevant products
                                    and
                                    services offered by APA and I/we confirm my/our agreement and acceptance of the
                                    same.
                                    Copies of APA’s prevailing terms and conditions can be obtained upon request.
                                    我／我們已閱讀並理解 APA 目前的條款和條件，同意受其所有條款及任何修訂或變更之約束。我／我們進一步同意並承認，還有其他條款和條件及協議旨在或表達用於管理 APA
                                    提供的其他相關產品和服務的使用，我／我們確認我／我們同意並接受同等。APA 目前的條款和條件的副本可應要求獲得。</p>
                            </label>
                        </div>

                        <div class="checkbox">
                            <input type="checkbox" id="confirm-info" name="confirm-info" required>
                            <label for="confirm-info">
                                <p> I/we may provide personal data to APA in connection with me/us
                                    establishing and maintaining my/our relationship with the APA. I/We confirm that all
                                    information provided, and documents submitted by me/us are true, complete and
                                    accurate.
                                    When providing any personal data to APA, I/we confirm that I am/we are lawfully
                                    providing the data for APA to use and disclose for the purposes of:
                                    我／我們可能會與 APA 提供與我／我們與 APA 之間建立和維持關係有關的個人資料。我／我們確認我／我們提供的所有信息和提交的文件均為真實、完整和準確。在向 APA
                                    提供任何個人資料時，我／我們確認我／我們是合法提供該資料給 APA 用於目的的：
                                <ul style="margin: 0; padding-left: 18px; list-style-type: disc;">
                                    <li>providing products or services to me/us;
                                        向我／我們提供產品或服務；
                                    </li>
                                    <li> meeting the operational, administrative and risk management requirements of APA
                                        Group ; and
                                        符合 APA 集團的運營、行政和風險管理要求；以及
                                    </li>
                                    <li> complying with any requirement, as APA Group reasonably deems necessary, under
                                        any law or of any court, government authority or regulator. “APA Group” means
                                        Atlantic Partners Asia Holdings (SG) Pte. Ltd. and its affiliates.
                                        遵守 APA 集團合理認為在任何法律或任何法院、政府機構或監管機構下的任何要求。 “APA 集團” 指Atlantic Partners Asia
                                        Holdings (SG) Pte. Ltd. 及其聯營公司。
                                    </li>
                                </ul>
                                </p>
                            </label>
                        </div>


                        <div class="checkbox">
                            <input type="checkbox" id="terms" name="terms" required>
                            <label for="terms">
                                <p>By submitting, you agree to our Terms and Conditions.</p>
                            </label>
                        </div>

                        <!--<div class="form-group">
                            <label for="full-name">Full name as per Passport / 护照上的英文姓名：</label>
                            <input type="text" id="full-name" name="full-name" required>
                        </div>-->

                        <div class="form-group">

                            <h2>Signature:</h2>
                            <canvas id="signature-pad" width="300" height="100"
                                style="border: 1px solid #000;"></canvas>
                            <br>
                            <button class="btn" onclick="clearSignature()">Clear</button>
                        </div>


                        <div class="form-group">
                            <label for="date">Date 日期：</label>
                            <input type="date" id="date" name="date" required>
                        </div>

                        <script>
                            // Auto-fill today's date
                            window.addEventListener('DOMContentLoaded', () => {
                                const today = new Date().toISOString().split('T')[0];
                                document.getElementById('date').value = today;
                            });
                        </script>

                        <div id="loadingOverlay">
                            Loading... Please wait.
                        </div>

                        <button type="submit">Submit</button>




                    </form>

                </div>
            </div>
        </div>




        <div id="Modal2" class="modal2">
            <div class="modal2-content">
                <div class="modal2-header">
                    <h2>Liquidity Agreement</h2>
                    <span class="close-btn" onclick="closeModal2()">×</span>
                </div>
                <div class="modal2-body" id="agreement-content"
                    style="max-height: 500px; overflow-y: auto; padding: 10px;">
                    <!-- Agreement text will be inserted here -->
                </div>
                <h2>Signature:</h2>
                <canvas id="signature-pad-2" width="300" height="100" style="border: 1px solid #000;"></canvas>
                <br>
                <button class="btn" onclick="clearSignature2()">Clear</button>
                <br><br>
                <div id="loadingOverlay1">
                    Loading... Please wait.
                </div>
                <button class="btn" id="submitAgreementBtn">Submit</button>
            </div>
        </div>

        <!-- Select2 Styles & Script -->
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

        <script>
            $(document).ready(function () {
                $('#currencies').select2({
                    placeholder: ""
                });

                // Live update selected values below
                $('#currencies').on('change', function () {
                    let selected = $(this).val(); // get selected values
                    if (selected.length > 0) {
                        $('#selected-currencies').text("Selected: " + selected.join(", "));
                    } else {
                        $('#selected-currencies').text("");
                    }
                });
            });
        </script>



        <script>
            function completeKYC() {
                let kycStatus = document.getElementById("kyc-status");

                // Simulate KYC completion
                kycStatus.innerText = "Completed";
                kycStatus.style.color = "green";

                // Save KYC status in localStorage
                localStorage.setItem("kycStatus", "Completed");
            }

            let step2Button = document.getElementById("step2-btn");
            let step1Button = document.getElementById("kyc-btn");
            let kycStatusElement = document.getElementById("kyc-status");
            let agreementStatusElement = document.getElementById("agreement-status");

            // Function to update button states dynamically
            function updateButtonStates() {
                let kycStatus = kycStatusElement.innerText.trim();
                let agreementStatus = agreementStatusElement.innerText.trim();

                if (kycStatus === "Pending" && agreementStatus === "Pending") {
                    step2Button.disabled = true;
                    step1Button.disabled = false;
                }
                else if (kycStatus === "Completed" && agreementStatus === "Pending" || agreementStatus === "Processing") {
                    step1Button.disabled = true;
                    step2Button.disabled = false;
                }
                else if (kycStatus === "Completed" && agreementStatus === "Completed") {
                    step1Button.disabled = true;
                    step2Button.disabled = true;
                }
                else {
                    step1Button.disabled = false;
                    step2Button.disabled = true;
                }
            }

            // Observe changes in the KYC and Agreement status elements
            let observer = new MutationObserver(updateButtonStates);
            observer.observe(kycStatusElement, { childList: true, subtree: true });
            observer.observe(agreementStatusElement, { childList: true, subtree: true });

            // Run the function initially to set the correct state
            updateButtonStates();


            function checkKYCStatusOnLoad() {
                let savedKYCStatus = localStorage.getItem("kycStatus");
                let kycStatusSpan = document.getElementById("kyc-status");

                if (savedKYCStatus === "Completed") {
                    kycStatusSpan.innerText = "Completed";
                    kycStatusSpan.style.color = "green";
                }

                enableStep2Button();
            }

            window.onload = function () {
                checkKYCStatusOnLoad();

                // Start observing the KYC status text for changes
                observer.observe(document.getElementById("kyc-status"), { childList: true, subtree: true });

                // Attach event listener to the KYC button
                document.getElementById("kyc-btn").addEventListener("click", function () {
                    completeKYC();
                });




            };





            function openModal() {
                document.getElementById("usdtModal").style.display = "block";


            }








            function closeModal() {
                document.getElementById("usdtModal").style.display = "none";
            }

            /*function openModal2() {
                document.getElementById("Modal2").style.display = "block";
 
 
            }
 
            function closeModal2() {
                document.getElementById("Modal2").style.display = "none";
            }*/

        </script>

        <script>
            const canvas2 = document.getElementById("signature-pad-2");
            const ctx2 = canvas2.getContext("2d");
            let drawing2 = false;

            // Mouse Events
            canvas2.addEventListener("mousedown", (e) => {
                drawing2 = true;
                ctx2.beginPath();
                ctx2.moveTo(e.offsetX, e.offsetY);
            });

            canvas2.addEventListener("mousemove", (e) => {
                if (drawing2) {
                    ctx2.lineTo(e.offsetX, e.offsetY);
                    ctx2.stroke();
                }
            });

            canvas2.addEventListener("mouseup", () => {
                drawing2 = false;
            });

            canvas2.addEventListener("mouseout", () => {
                drawing2 = false;
            });

            // Touch Events (for mobile)
            canvas2.addEventListener("touchstart", (e) => {
                e.preventDefault();
                const rect = canvas2.getBoundingClientRect();
                const touch = e.touches[0];
                const x = touch.clientX - rect.left;
                const y = touch.clientY - rect.top;
                drawing2 = true;
                ctx2.beginPath();
                ctx2.moveTo(x, y);
            });

            canvas2.addEventListener("touchmove", (e) => {
                e.preventDefault();
                if (drawing2) {
                    const rect = canvas2.getBoundingClientRect();
                    const touch = e.touches[0];
                    const x = touch.clientX - rect.left;
                    const y = touch.clientY - rect.top;
                    ctx2.lineTo(x, y);
                    ctx2.stroke();
                }
            });

            canvas2.addEventListener("touchend", () => {
                drawing2 = false;
            });

            function clearSignature2() {
                ctx2.clearRect(0, 0, canvas2.width, canvas2.height);
            }
        </script>





        <script>
            let signaturePad2;

            window.onload = function () {
                const canvas = document.getElementById("signature-pad-2");
                signaturePad2 = new SignaturePad(canvas, {
                    backgroundColor: 'rgba(255, 255, 255, 0)',
                    penColor: 'black'
                });
            };

            function clearSignature2() {
                signaturePad2.clear();
            }

            /*function submitAgreement2() {

                const canvas = document.getElementById("signature-pad-2");
                const signature = canvas.toDataURL("image/png");
                const content = document.getElementById("agreement-content").innerHTML;

                fetch("save_agreement.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ content, signature })
                })
                    .then(res => res.text())
                    .then(response => {
                        alert(response);
                        document.getElementById("agreement-status").innerText = "Completed";
                        closeModal2();
                    });
            }*/

            function submitAgreement2() {
                const canvas = document.getElementById("signature-pad-2");
                const signature = canvas.toDataURL("image/png");
                const content = document.getElementById("agreement-content").innerHTML;

                return fetch("save_agreement.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ content, signature })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            document.getElementById("agreement-status").innerText = "Completed";
                            closeModal2();
                        } else {
                            throw new Error(data.message || "Submission failed.");
                        }
                    });
            }


            document.addEventListener("DOMContentLoaded", function () {
                const submitBtn = document.getElementById("submitAgreementBtn");
                const loadingOverlay1 = document.getElementById("loadingOverlay1");

                submitBtn.addEventListener("click", function () {
                    loadingOverlay1.style.display = "flex"; // Show loading

                    submitAgreement2()
                        .catch(error => {
                            console.error("Error:", error);
                            alert("Something went wrong: " + error.message);
                        })
                        .finally(() => {
                            loadingOverlay1.style.display = "none"; // Hide loading only after completion
                        });
                });
            });



            function openModal2() {
                document.getElementById("Modal2").style.display = "block";

                fetch("kyc_modal.php")
                    .then(res => res.json())
                    .then(user => {
                        const today = new Date().toLocaleDateString("en-GB");
                        const address = `${user.address1}, ${user.address2}, ${user.address3}`;

                        const agreementHTML = `
                        <!--<h1>Individual Liquidity Agreement</h1>-->                              
                        <p><strong>${today}</strong></p>
                        <p>Between</p> 
                        <p><strong>${user.full_name}</strong>, holder of Passport ID: <strong>${user.passport_id}</strong>, with the address of <strong>${address}</strong> ("Client")</p>
                        <p>ATLANTIC PARTNERS SPC FUND on behalf of the Atlantic Partners Asia Fund Segregated Portfolio, a company incorporated under the laws of Cayman Island (Company Number 270942), with its registered office at Willow House, Cricket Square, George Town, Grand Cayman KY1-1104, Cayman Islands (“APA”) </p>
                        <p> (together the Parties each a Party) </p>
                        <p>WHEREAS:</p>
                        <p>A. Client proposes to provide APA with short term liquidity in certain agreed jurisdictions and currencies, and APA shall repay these funds to Client on the terms and conditions contained in this Agreement.</p>
                        <p>B. The purpose of this Agreement is to establish parameters for the co-operation of the Parties on a best endeavours basis.</p>
                        <p>C. The Agreement does not modify or supersede any laws or regulatory requirements in force with regard to, or applying to, any of the Parties. </p>
                        <p>THEREFORE THE PARTIES AGREE AS FOLLOWS:  </p>
                        <p> 1. Definitions </p>
                        <p>In this agreement, unless the context requires otherwise: 
APA Nominated Account has the meaning given in the Liquidity Request.  
Available Local Funds has the meaning given in the Liquidity Request.  
Business Day means a day that banks are open for business in Hong Kong.  
Commencement Date means the date of this agreement.  
Fees has the meaning given in the Liquidity Request.  
KYC Pack means APA’s standard application form as provided to the Client.  
Liquidity Request means the form contained in Schedule 1. 
Loss(es) means all liabilities, losses (including consequential, special or indirect damages, economic 
loss, loss of profits or opportunities), costs (on a full indemnity basis), expenses (including any legal 
expenses on a full indemnity basis) and damages arising directly or indirectly from or in relation with 
this agreement, including any liability for taxes (including value-added taxes) in respect of any of the 
foregoing.</p>

<p>Settlement Amount has the meaning given in the Liquidity Request. </p>
<p>Settlement Details has the meaning given in the Liquidity Request. </p>
<p>Transaction means a liquidity transaction under this Agreement. </p>

<h3 style="page-break-before: always;"> Confidentiality </h3>
<p>a) Each Party may or will provide the other Party with information that is not publicly known and that is 
confidential or proprietary in nature and shall include technical and financial information. Such 
information and any other information concerning the disclosing Party’s business affairs, or any 
negotiations taking place concerning the Transaction and the status of those discussions and 
negotiations, furnished to the receiving Party by the disclosing Party, whether in writing, orally or by any 
other means, are herein collectively referred to as the Confidential Information.. </p>

<p>b) The Confidential Information shall be kept strictly confidential and shall not without the prior written 
consent of the disclosing Party be disclosed, revealed or permitted to be disclosed or revealed in whole 
or in part to any person other than the receiving Party and its directors, officers, employees, advisors 
and representatives to whom it is necessary to reveal the Confidential Information for the purpose of 
this agreement, provided such persons are bound by confidentiality obligations substantially similar to 
the ones contained in this agreement. The receiving Party shall use its best endeavours to prevent 
disclosure of the Confidential Information and the fact that it has been disclosed to the disclosing Party. </p>
<p> c) The Confidential Information shall not be used for any purpose other than to identify, evaluate, develop, 
commercialise and advise on matters contemplated by this agreement. </p>
<p> d) The foregoing undertakings shall be continuing obligations and shall continue in full force and effect, 
provided that such undertakings shall not apply to such of the Confidential Information as:
    i) was lawfully in possession of the receiving Party prior to the execution of this agreement; or 
   ii)was already publicly known at the time of disclosure; or 
   iii) becomes publicly known other than by reason of breach of the undertakings contained in this agreement; or 
   iv) is properly received by the receiving Party from a third party who is, insofar as is known to the receiving Party after reasonable inquiry, rightfully in possession of it and is not bound by any obligation of confidence or secrecy to the disclosing Party; or
   v) is required to be disclosed by any law, governmental authority or agency, by the regulations of,or at the request of, any regulatory or supervisory authority having jurisdiction over the receiving Party, or by an order of any court of competent jurisdiction, provided that the receiving Party will notify the disclosing Party of such a disclosure requirement to the extent this is permitted under applicable law; or 
   vi) is disclosed with the prior written consent of the providing Party.  </p>
   <p> e) Any intellectual property provided by either Party shall remain the property of the disclosing Party. </p>
   <p>f) 
Any intellectual property produced jointly as a result of this agreement shall remain the property of 
both Parties and cannot be disclosed or assigned without the express written consent of both Parties. </p>
<p>g) The obligations of confidentiality contained in this clause shall also apply and extend to any directors, 
officers, employees, agents, professional advisors, consultants and third party agents of each Party 
(together the Affiliates), and each Party shall be obliged to ensure their Affiliates’ compliance with this 
clause. Each Party shall have recourse directly to the other Party in respect of any breach of 
confidentiality or compliance with this agreement by the other Party’s Affiliates. </p>
</p>
<p>h) No Party shall make, or permit any person to make, any public announcement concerning this 
agreement without the prior written consent of the other Party, except as required by law. </p>
<p>i) 
For the avoidance of doubt, the provisions of this clause 1 shall survive any termination of this 
agreement. </p>


<h3 style="page-break-before: always;">Transaction process </h3>
<p>a) The Parties agree that each Transaction shall be completed as follows: 
i)Following discussions between APA and Client, and upon the KYC Pack being been verified by APA, 
APA and Client shall agree upon the Liquidity Request, or confirm a similar arrangement with all 
material terms agreed via other electronic means. 
ii)Following completion of clause 2(a)(i), Client shall remit the Available Local Funds to the APA 
Nominated Account via electronic funds transfer or as otherwise agreed. Client shall provide APA 
with a copy of the remittance or transfer receipt immediately thereafter. 
iii) Upon receipt by and availability of the Available Local Funds to APA, APA shall proceed to facilitate 
the settlement of the Settlement Amount in accordance with the Settlement Details. 
iv) The Settlement Amount will be remitted to the nominated account(s) of Client as specified in the 
Settlement Details, and APA shall provide Client with a copy of the remittance or transfer receipt 
immediately upon processing. APA may conduct such settlement in its own capacity, via 
regulated providers, or other partner entities, in its discretion. 
v) APA shall otherwise provide any and all necessary transactional support to facilitate the 
successful completion of the Transaction. 
vi) The Parties acknowledges that where any Transaction is concluded, the Fees shall be deducted 
by APA in accordance with the Transaction Terms. </p>
<p>b) Each Party shall be responsible for its own costs and expenses with relation to any Transaction and this 
agreement. </p>
<h3 style="page-break-before: always;">Communication and Dealings </h3>
<p>a) Each Party agrees that without the prior consent of the other Party, they shall not: 
i) 
ii) 
independently undertake any Transaction contemplated by this agreement (either directly or 
indirectly) other than with each other; 
negotiate or enter into an agreement with any person or company introduced by one Party in 
relation to all or part of any Transaction contemplated by this agreement (Introduced Person); 
or 
iii) accept any direct or indirect benefit from another person in respect of all or part of any 
Transaction contemplated by this agreement, or in return for another person entering into 
dealings with any Introduced Person.</p>
<p>b) Each Party shall exercise its powers and perform its duties, functions and obligations under this 
agreement or any future agreement with all reasonable professional care and diligence, in good faith, 
with fairness, honesty and efficiency and in accordance with all applicable laws.</p>
<h3 style="page-break-before: always;">Acknowledgements</h3>
<p>a) Each Party will be responsible for obtaining its own professional advice on legal, accounting, taxation 
and any other matters pertaining to this agreement or a Transaction. </p>
<p>b) Each Party accepts and acknowledges that it is aware of, fully understands and shall assume all risks 
involved in relation to a Transaction, including market risks, regulatory risks and the impact of prevailing 
market conditions. </p>
<p>c) No representation or warranty is or can be made as to the economic return that may accrue to a Party 
as a result of this agreement. Neither Party in any way warrants or represents that successful 
completion of the process contemplated by this agreement will be achieved. The Parties will, however, 
use their best endeavours to undertake the Transaction and obtain the best possible outcome for each 
other in accordance with this agreement.</p>
<p>d) Each Party represents and warrants to the other Party: 
i) that is validly existing and in good standing in the jurisdictions in which it is incorporated; 
ii) that it is in compliance with all relevant laws and regulations related to any Transaction 
contemplated herein, including but not necessarily limited to the laws of the governing 
jurisdiction; and 
iii) that the KYC Pack shall at all times be valid and up to date for the duration of the term of this 
agreement. 
iv) The Client acknowledges that any Transaction including the Funds subject of any Transaction 
may be restricted, suspended, confiscated or withheld permanently or indefinitely by law 
enforcement or other regulatory or government agency, and that APA has no liability for such 
action. </p>
<p>Commencement and Termination </p>
  <p>a) This agreement will take effect on the date it has been duly executed by both Parties and shall continue 
in full force and effect until the earlier of 2 years, or termination in accordance with this clause. </p>
<p> b) Without affecting any other right or remedy available to it, either Party may terminate this agreement 
with immediate effect by giving written notice to the other Party if the other Party: 
i)commits a material breach of any term of this agreement and such breach is irremediable or (if 
such breach is remediable) fails to remedy that breach within a period of 30 days after being 
notified in writing to do so; 
ii)repeatedly breaches any of the terms of this agreement in such a manner as to reasonably justify 
the opinion that its conduct is inconsistent with it having the intention or ability to give effect to 
the terms of this agreement; 
iii) goes into liquidation or insolvency (or any analogous procedure), whether compulsory or 
voluntary; 
iv) has an administrator or receiver and manager or judicial manager or similar officer appointed 
over any part of its assets; 
v) becomes insolvent or is unable to pay its debts or admits in writing its inability to pay its debts as 
they fall due or enters into any composition or arrangement with its creditors or makes a general 
assignment for the benefit of its creditors; 
vi) ceases or threatens to cease to carry on the whole or any substantial part of its business other 
than in the course of reconstruction or amalgamation; 
vii) sells, transfers, leases or otherwise disposes of the whole or substantially the whole of its assets, 
rights and undertaking either pursuant to a court order for compulsory acquisition or otherwise; 
or 
viii) suffers any distress, execution, sequestration or other process being levied or enforced upon its 
property, pursuant to a law suit or otherwise, which is not discharged within 5 days.</p>
<p> c) Either Party may terminate this agreement at any time upon 15 Business Days’ written notice to the 
other Party. </p>
<p> d) Termination of this agreement shall not affect any rights, remedies, obligations or liabilities of the 
Parties that have accrued up to the date of termination.</p>
<h3 style="page-break-before: always;"> Limitation of Liability and Indemnity </h3>
<p>a) This clause 6 applies to the maximum extent permitted by law and sets out, and the Parties accept, 
the limitations which apply to one Party’s liability to the other Party, should either a Party or any other 
person have reason to make a claim against a Party. The limitations and exclusions are accepted by 
the Parties to be fair and reasonable. </p>
<p>b) The Parties agree: 
i)to indemnify and hold harmless each other against; and 
ii)that a Party shall not have any liability to another Party in relation to,  
any Losses, however caused, arising directly or indirectly from or in connection with the activities 
contemplated in this agreement.</p>
<p>c) If any of the limitations of liability and indemnities set out in this agreement are not effective, do not 
apply or are not available to a Party (for any reason whatsoever), the Parties agree that the maximum 
liability of one Party to another Party for Losses will not exceed US$1,000, except that there should be no 
limit in the event of gross negligence, fraud or misconduct of the either Party.</p>
<p>d) Nothing in this agreement excludes, restricts or modifies the application of the provisions of any statute 
where to do so would contravene that statute or cause any part of the agreement to be void.</p>
<p>e) In the event that a Transaction or Funds are restricted, suspended, confiscated or withheld 
permanently or indefinitely or otherwise subject to any similar restrictive action by a financial 
institution, governmental authority, law enforcement agency, or any other entity possessing judicial or 
lawful authority over the funds or the Transaction, APA and any of its affiliates, subsidiaries, or related 
entities shall bear no liability or responsibility for the completion of the Transaction or Losses arising 
therefrom. </p>
<h3 style="page-break-before: always;">Notices</h3>
<p>a) All notices and communications to either Party under this agreement shall be made in writing and by 
means of registered mail (or courier) or email with acknowledgment of receipt and shall be deemed 
given on the date of the respective receipt, to the following addresses: 
APA: 
Atlantic Partners Asia 
Email: compliance@atlanticpartnersasia.com  </p>
<p>b) All notices should also be sent by email to the relevant email address as indicated above.</p>
<h3 style="page-break-before: always;"> Consultation and Disputes </h3>
<p>a) The Parties will keep the operation of this agreement under review and will consult when necessary: 
i)in the event of a dispute over the meaning of any term used in the agreement; 
ii)in the event of a substantial change in the laws, regulations or practices affecting the operation 
of the agreement; 
iii) in the event of any Party proposing to withdraw from the agreement; and 
iv) whenever necessary, with a view to improving its operation and resolving any matters.</p>
<p>b) Any dispute, controversy or claim arising out of, or relating to, this agreement including any dispute 
regarding its existence, its validity or termination (Dispute) shall in the first instance be submitted to 
one senior representative appointed by each Party, who will meet to discuss a resolution to the Dispute 
within 5 Business Days of a dispute notice being filed in writing.</p>
<p>c) If the appointed senior representatives are unable to resolve the Dispute within 10 Business Days of a 
dispute notice being filed, the Dispute shall be referred to and finally resolved by arbitration 
administered by the Singapore International Arbitration Centre (“SIAC”) in accordance with the 
Arbitration Rules of the Singapore International Arbitration Centre ("SIAC Rules") for the time being in 
force, which rules are deemed to be incorporated by reference in this clause.</p>
<p>d) The Parties acknowledge and agree that they:  
i) may be irreparably harmed by the breach of the terms of this agreement and damages may not 
be an adequate remedy; 
ii)may be granted an injunction or specific performance for any threatened or actual breach of the 
provisions of this agreement by a Party; and 
iii) may apply to the courts in any relevant jurisdiction in order to seek injunctive relief to enforce (or 
to prevent a breach of) any of their rights pursuant to this agreement.</p>
<h3 style="page-break-before: always;">General</h3>
<p>a) The Parties agree and understand that the basis of their respective understanding contained herein is 
and will be subject to all applicable laws, rules and regulations as may be applicable from time to time. 
Each Party shall at its own expense comply with all laws and regulations relating to its activities under 
this agreement, as they may change from time to time, and with any conditions binding on it in any 
applicable licences, registrations, permits and approvals.</p>
<p>b) This document contains the entire agreement between the Parties and neither Party shall be bound by 
any undertaking, representation or warranty not recorded herein or added hereto as provided herein. </p>
<p>c) Any amendment, alteration or variation of this agreement, including this provision itself, is not effective 
unless it is in writing and signed by both Parties.</p>
<p>d) Waiver of any right, power, authority, discretion or remedy arising from a breach of this agreement must 
be in writing and signed by the Party granting the waiver. A failure or delay in exercise, or partial exercise, 
of a right, power, authority, discretion or remedy created or arising from a breach of this agreement 
does not result in a waiver of that right, power, authority, discretion or remedy.</p>
<p>e) If any clause or term of this agreement should be invalid, unenforceable or illegal, then the remaining 
terms and provisions of this agreement shall be deemed to be severable therefrom and shall continue 
in full force and effect unless such invalidity, unenforceability or illegality goes to the root of this 
agreement.</p>
<p>f) 
This agreement may be executed in counterparts. Each counterpart is an original but the counterparts 
together are one and the same agreement. </p>
<p>g) This agreement is governed by and shall be construed and enforced in accordance with the laws of 
Hong Kong. The Parties submit to the non-exclusive jurisdiction of the courts there.</p>
<p>EXECUTED on behalf of 
ATLANTIC PARTNERS SPC 
FUND by </p>








        <!-- Include all other HTML-converted agreement content here -->
        <p><strong>Signed by:</strong><br>${user.full_name}<br>${today}</p>
      `;

                        document.getElementById("agreement-content").innerHTML = agreementHTML;
                    });
            }

            function closeModal2() {
                document.getElementById("Modal2").style.display = "none";
            }

            function clearSignature2() {
                const canvas = document.getElementById("signature-pad-2");
                const ctx = canvas.getContext("2d");
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }



            /*function submitAgreement2() {
                
                const canvas = document.getElementById("signature-pad-2");
                const signature = canvas.toDataURL("image/png");
                const content = document.getElementById("agreement-content").innerHTML;

                fetch("save_agreement.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ content, signature })
                })
                    .then(res => res.text())
                    .then(response => {
                        alert(response);
                        document.getElementById("agreement-status").innerText = "Completed";
                        closeModal2();
                    });
                    

            }*/

        </script>

        <script>
            const canvas = document.getElementById("signature-pad");
            const signatureData = document.getElementById("signature-data");
            const ctx = canvas.getContext("2d");

            let drawing = false;

            // Mouse Events
            canvas.addEventListener("mousedown", (e) => {
                drawing = true;
                ctx.beginPath();
                ctx.moveTo(e.offsetX, e.offsetY);
            });

            canvas.addEventListener("mousemove", (e) => {
                if (drawing) {
                    ctx.lineTo(e.offsetX, e.offsetY);
                    ctx.stroke();
                }
            });

            canvas.addEventListener("mouseup", () => {
                drawing = false;
                signatureData.value = canvas.toDataURL(); // Save signature
            });

            canvas.addEventListener("mouseout", () => {
                drawing = false;
            });

            // Touch Events (for mobile)
            canvas.addEventListener("touchstart", (e) => {
                e.preventDefault();
                const rect = canvas.getBoundingClientRect();
                const touch = e.touches[0];
                const x = touch.clientX - rect.left;
                const y = touch.clientY - rect.top;
                drawing = true;
                ctx.beginPath();
                ctx.moveTo(x, y);
            });

            canvas.addEventListener("touchmove", (e) => {
                e.preventDefault();
                if (drawing) {
                    const rect = canvas.getBoundingClientRect();
                    const touch = e.touches[0];
                    const x = touch.clientX - rect.left;
                    const y = touch.clientY - rect.top;
                    ctx.lineTo(x, y);
                    ctx.stroke();
                }
            });

            canvas.addEventListener("touchend", () => {
                drawing = false;
                signatureData.value = canvas.toDataURL(); // Save signature
            });

            function clearSignature() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                signatureData.value = '';
            }
        </script>





        <script>
            const form = document.getElementById("usdtOnboardingForm");
            const loadingOverlay = document.getElementById("loadingOverlay");

            form.addEventListener("submit", function (event) {
                event.preventDefault();

                loadingOverlay.style.display = "flex"; // Show loading

                const canvas = document.getElementById("signature-pad");
                const signatureData = canvas.toDataURL("image/png");

                let formData = new FormData(form);
                formData.append("signature", signatureData); // Append signature as base64

                fetch("kyc_submit2.php", {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);
                        if (data.status === "success") {
                            closeModal(); // Close modal only if successful
                        }
                    })
                    .catch(error => {
                        console.error("Error:", error);
                        alert("An error occurred. Please try again.");
                    })
                    .finally(() => {
                        loadingOverlay.style.display = "none"; // Hide loading
                    });
            });
        </script>


        <script>
            document.addEventListener("DOMContentLoaded", function () {
                function getStatusColor(status) {
                    switch (status) {
                        case 'completed': return 'green';
                        case 'failed': return 'red';
                        case 'Processing': return 'orange';
                        default: return 'orange'; // Pending
                    }
                }

                function updateKycStatus() {
                    fetch("auto_update.php", {
                        method: "GET"
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status !== "unauthorized") {
                                let statusElement = document.getElementById("kyc-status");
                                statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                statusElement.style.color = getStatusColor(data.status);
                            }
                        })
                        .catch(error => console.error("Error fetching KYC status:", error));
                }

                // Fetch status every 5 seconds
                setInterval(updateKycStatus, 5000);
                updateKycStatus(); // Fetch immediately on page load
            });
        </script>
        <script>

            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                event.preventDefault();

                setTimeout(() => {
                    //alert("Form submitted successfully!");
                    closeModal2(); // Close modal after submission
                }, 500); // Simulating slight delay


            });
            document.getElementById("modal2Form").addEventListener("submit", function (event) {
                event.preventDefault(); // Prevent default form submission

                let formData = new FormData(this);

                fetch("upload_agreements.php", {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);
                        //closeModal2(); // Close modal after successful submission
                    })
                    .catch(error => console.error("Error:", error));



            });




        </script>
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                function getStatusColor(status) {
                    switch (status) {
                        case 'completed': return 'green';
                        case 'failed': return 'red';
                        case 'processing': return 'orange';
                        default: return 'orange'; // Pending
                    }
                }

                function updateAgreementStatus() {
                    fetch("check_status.php", {
                        method: "GET"
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status !== "unauthorized") {
                                let statusElement = document.getElementById("agreement-status");
                                statusElement.textContent = data.status.charAt(0).toUpperCase() + data.status.slice(1);
                                statusElement.style.color = getStatusColor(data.status);
                            }
                        })
                        .catch(error => console.error("Error fetching agreement status:", error));
                }

                // Fetch status every 5 seconds
                setInterval(updateAgreementStatus, 5000);
                updateAgreementStatus(); // Fetch immediately on page load
            });
        </script>



        <!-- main-js -->
        <script src="assets/js/script.js"></script>






</body><!-- End of .page_wrapper -->

</html>