<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form = $_POST;
    $updated = [];

    foreach ($form as $key => $value) {
        if (preg_match('/^(.+?)_(base|limit_\d+|charge_\d+)$/', $key, $matches)) {
            $pair = $matches[1];
            $field = $matches[2];

            if (!isset($updated[$pair])) {
                $updated[$pair] = ['base' => 0, 'tiers' => []];
            }

            if ($field === "base") {
                $updated[$pair]['base'] = (float)$value;
            } elseif (preg_match('/limit_(\d+)/', $field, $m)) {
                $index = (int)$m[1];
                $updated[$pair]['tiers'][$index]['limit'] = $value === 'Infinity' ? 'Infinity' : (float)$value;
            } elseif (preg_match('/charge_(\d+)/', $field, $m)) {
                $index = (int)$m[1];
                $updated[$pair]['tiers'][$index]['charge'] = (float)$value;
            }
        }
    }

    // sort tiers by limit just in case
    foreach ($updated as &$pair) {
        usort($pair['tiers'], function ($a, $b) {
            return $a['limit'] === 'Infinity' ? 1 : ($b['limit'] === 'Infinity' ? -1 : $a['limit'] - $b['limit']);
        });
    }

    file_put_contents("charges.json", json_encode($updated, JSON_PRETTY_PRINT));
    echo "Charges updated successfully.";
}
