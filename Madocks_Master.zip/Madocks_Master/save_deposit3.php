<?php
include 'dbConnect.php';
session_start();

require 'vendor/autoload.php'; // PHPMailer & Twilio

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Twilio\Rest\Client;

// Check if user is logged in
if (!isset($_SESSION['user']['id'])) {
    die("Error: User not logged in.");
}

if (!isset($_SESSION['user'])) {
    echo json_encode(["message" => "User not authenticated."]);
    exit;
}
$user = $_SESSION['user'];

$user_id = $_SESSION['user']['id'];
$user_name = $user['name'] ?? 'Unknown User';

// Validate form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['receipt']) && isset($_POST['bank_address'])) {
    $bank_address = htmlspecialchars($_POST['bank_address']);

    // File upload handling
    $upload_dir = 'uploads/';
    $filename = basename($_FILES['receipt']['name']);
    $target_file = $upload_dir . $filename;

    if (move_uploaded_file($_FILES['receipt']['tmp_name'], $target_file)) {
        // Fetch latest record
        $query = "SELECT id, amount_send, currency_send, amount_receive, currency_receive, transaction_time 
                  FROM records WHERE user_id = :user_id ORDER BY transaction_time DESC LIMIT 1";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $record = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($record) {
            $record_id = $record['id'];
            $deposit_status = 'processing';

            // Update record
            $update_query = "UPDATE records 
                             SET receipt_file = :receipt_file, bank_address = :bank_address, deposit_status = :deposit_status 
                             WHERE id = :record_id";
            $update_stmt = $pdo->prepare($update_query);
            $update_stmt->bindParam(':receipt_file', $target_file, PDO::PARAM_STR);
            $update_stmt->bindParam(':bank_address', $bank_address, PDO::PARAM_STR);
            $update_stmt->bindParam(':deposit_status', $deposit_status, PDO::PARAM_STR);
            $update_stmt->bindParam(':record_id', $record_id, PDO::PARAM_INT);

            if ($update_stmt->execute()) {
                // Extract values for calculation
                $amount_send = (float) $record['amount_send'];
                $amount_receive = (float) $record['amount_receive'];
                $currency_send = $record['currency_send'];
                $currency_receive = $record['currency_receive'];
                $transaction_time = $record['transaction_time'];

                $xe_rates = json_decode(file_get_contents('xe_rates.json'), true);
                $xe_send_rate = $xe_rates['exchangeRate_' . strtoupper($currency_send)] ?? 1;
                $xe_receive_rate = $xe_rates['exchangeRate_' . strtoupper($currency_receive)] ?? 1;



                // Calculate fixed rate
                $rate1 = $xe_receive_rate / $xe_send_rate;

                $rates = json_decode(file_get_contents('exchangeRates.json'), true);
                $send_rate = $rates['exchangeRate_' . strtoupper($currency_send)] ?? 1;
                $receive_rate = $rates['exchangeRate_' . strtoupper($currency_receive)] ?? 1;



                // Calculate fixed rate
                $rate = $receive_rate / $send_rate;

                // Calculate financial values
                $new_apa = $rate1 * 0.004;
                $new_apa2 = $rate1 - $new_apa;

                $new_mad = $rate1 * 0.006;
                $new_madocks = $rate1 - $new_mad;

                $abc = $rate1 * $amount_send;
                $xyz = $new_apa2 * $amount_send;

                $profit_apa = $abc - $xyz;

                $pqr = $new_apa2 * $amount_send;
                $stu = $new_madocks * $amount_send;

                $profir_madocks = $pqr - $stu;

                if ($currency_send === 'USDT' && $rate1 != 0) {
                    $profit_apa = $profit_apa / $rate1;
                    $profir_madocks = $profir_madocks / $rate1;
                }


                $X = $rate * 0.0202;
                $y = $rate + $X;

                $aparate = $y * 0.01;
                $aparate2 = $y - $aparate;

                $madocksrate = $aparate2 * 0.01;
                $madocksrate2 = $aparate2 - $madocksrate;

                $a1 = $y * 0.01;
                $a2 = $y - $a1;

                $b = $a2 * $amount_send;
                $c = $y * $amount_send;
                $amountAPA = $c - $b;

                $p1 = $a2 * 0.01;
                $p = $a2 - $p1;
                $Q = $p * $amount_send;
                $amountmadocks = $b - $Q;
                $s = number_format($Q, 2, '.', '');


                // Send email
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'madocks.ai@gmail.com';
                    $mail->Password = 'uexurwwgwuotfcge';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
                    $mail->addAddress('sdbangar2807@gmail.com');
                    //$mail->addAddress('harveyong.wv@gmail.com');
                    $mail->addAddress('harvey@madocks.ai');
                    $mail->addAddress('rahul@madocks.ai');
                    

                    $mail->addAttachment($target_file);

                    $mail->isHTML(true);
                    $mail->Subject = 'New Bank Record Receipt';

                    $mail->Body = "
                        <h3>New bank record receipt uploaded.</h3>
                        <p><strong>User ID:</strong> $user_id </p>
                        <p><strong>User Name:</strong> {$user_name}</p>

                        <p><strong>Currency Selected:</strong>  $currency_send to $currency_receive </p>
                        <!--<p><strong>Transaction Time:</strong> $transaction_time IST</p>-->
                        <p><strong>XE Rate @ $transaction_time IST :</strong> $rate1 $currency_receive </p>
                        <!--<p><strong>Client Lock in Rate: </strong> 1 $currency_send = $y $currency_receive </p>--->
                        <!--<p><strong>Exchange Rate:</strong> 1 $currency_send = $y $currency_receive</p>-->
                        <p><strong>APA Fixed Rate :</strong> 1 $currency_send = $rate $currency_receive</p>
                        <p><strong>APA Rate :</strong> 1 $currency_send = $new_apa2 $currency_receive </p>
                        <p><strong>Madocks Rate :</strong> 1 $currency_send = $new_madocks $currency_receive </p> 

                        <p><strong>Amount Sent by Client :</strong> $amount_send $currency_send </p>
                        <!--<p><strong>Amount Received:</strong> $amount_receive $currency_receive</p>--->
                        
                        <p><strong>Amount to APA:</strong> $profit_apa</p>
                        <p><strong>Amount to Madocks:</strong> $profir_madocks</p>
                        <p><strong>amount to transfer to client :</strong> $amount_receive $currency_receive </p>
                        <p><strong>Bank Address:</strong> $bank_address </p>
                        <p>The receipt file is attached.</p>";

                    if ($mail->send()) {
                        echo "success";
                    } else {
                        echo "Error: Failed to send email.";
                    }
                } catch (Exception $e) {
                    echo "Mailer Error: {$mail->ErrorInfo}";
                }

                sendWhatsAppMessagetoapa_Deposit($user_id, $bank_address);
            } else {
                echo "Error: Failed to update the record.";
            }
        } else {
            echo "Error: No records found.";
        }
    } else {
        echo "Error: Failed to upload the receipt file.";
    }
} else {
    echo "Error: Invalid form submission.";
}

// WhatsApp notification
function sendWhatsAppMessagetoapa_Deposit($user_id, $bank_address)
{
    $sid = "AC123ed9e921a2f70fa480229231503368";
    $token = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $body = "User - $user_id has Deposited money. Bank Address - $bank_address, please check mail.";

    $twilio->messages->create("whatsapp:+917588345894", [
        "from" => "whatsapp:+14155238886",
        "body" => $body
    ]);
}
?>