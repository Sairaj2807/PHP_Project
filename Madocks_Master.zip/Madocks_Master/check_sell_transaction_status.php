<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(["status" => "unauthorized"]);
    exit;
}

$user_id = $_SESSION['user']['id'];

$query = "SELECT deposit_status, receive_status 
          FROM transactions 
          WHERE user_id = :user_id 
          AND transaction_type = 'sell'
          ORDER BY transaction_time DESC 
          LIMIT 1";

$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Return default values if no transactions found
echo json_encode([
    "deposit_status" => $result['deposit_status'] ?? 'pending',
    "receive_status" => $result['receive_status'] ?? 'pending'
]);
?>
