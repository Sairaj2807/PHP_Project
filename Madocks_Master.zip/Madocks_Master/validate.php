<?php
session_start();
require 'dbConnect.php';

// Check if user session is set
if (!isset($_SESSION['user'])) {
    echo json_encode(["status" => "unauthorized", "message" => "User session not found"]);
    exit;
}

$user_id = $_SESSION['user']['id'];

try {
    // Fetch KYC status
    $queryKyc = "SELECT status FROM kyc WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 1";
    $stmtKyc = $pdo->prepare($queryKyc);
    $stmtKyc->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmtKyc->execute();
    $kyc = $stmtKyc->fetch(PDO::FETCH_ASSOC);
    $kyc_status = $kyc['status'] ?? 'pending';

    // Fetch Liquidity Agreement status
    $queryAgreement = "SELECT status FROM liquidity_agreements WHERE user_id = :user_id ORDER BY uploaded_at DESC LIMIT 1";
    $stmtAgreement = $pdo->prepare($queryAgreement);
    $stmtAgreement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmtAgreement->execute();
    $agreement = $stmtAgreement->fetch(PDO::FETCH_ASSOC);
    $agreement_status = $agreement['status'] ?? 'pending';

    echo json_encode([
        "kyc_status" => $kyc_status,
        "agreement_status" => $agreement_status
    ]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
