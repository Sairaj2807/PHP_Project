const CACHE_NAME = "usdt-cache-v1";
const urlsToCache = [
  "/usdt_main_page_change3.php",
  "/mainfest.webmanifest",
  "/assets/images/icons/icon-1.png",
  "/assets/images/icons/icon-26.png",
  // Add more static assets here like CSS, JS, fonts, etc.
];

// Install event
self.addEventListener("install", (event) => {
    event.waitUntil(
      caches.open(CACHE_NAME).then(async (cache) => {
        try {
          await cache.addAll(urlsToCache);
        } catch (error) {
          console.error("Cache addAll failed:", error);
        }
      })
    );
  });
  

// Activate event
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) =>
      Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      )
    )
  );
  self.clients.claim();
});

// Fetch event
self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return (
        response ||
        fetch(event.request).catch(() => {
          // Optional fallback if offline
          return new Response("You're offline.");
        })
      );
    })
  );
});


