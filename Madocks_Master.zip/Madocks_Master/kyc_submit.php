<?php
session_start();
require 'dbConnect.php';
require 'vendor/autoload.php'; // Make sure PHPMailer is installed via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Twilio\Rest\Client;

if (!isset($_SESSION['user'])) {
    echo json_encode(["message" => "User not authenticated."]);
    exit;
}

$user = $_SESSION['user'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $uploadDir = "uploads/";
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Handle file uploads
        $source_wealth = $_FILES['sourceWealth']['name'] ? $uploadDir . basename($_FILES['sourceWealth']['name']) : null;
        $proof_identity = $_FILES['proofIdentity']['name'] ? $uploadDir . basename($_FILES['proofIdentity']['name']) : null;
        $proof_address = $_FILES['proofAddress']['name'] ? $uploadDir . basename($_FILES['proofAddress']['name']) : null;
        $source_funds = $_FILES['sourceFunds']['name'] ? $uploadDir . basename($_FILES['sourceFunds']['name']) : null;

        move_uploaded_file($_FILES['sourceWealth']['tmp_name'], $source_wealth);
        move_uploaded_file($_FILES['proofIdentity']['tmp_name'], $proof_identity);
        move_uploaded_file($_FILES['proofAddress']['tmp_name'], $proof_address);
        move_uploaded_file($_FILES['sourceFunds']['tmp_name'], $source_funds);

        // Insert the data into the database
        $stmt = $pdo->prepare("INSERT INTO kyc (user_id, apa_employee, full_name, dob, nationality, address1, address2, address3, postcode, mobile, passport_id, country, occupation, email, currencies, source_wealth, proof_identity, proof_address, source_funds, annual_volume, account_reason, reference_code, status) 
            VALUES (:user_id, :apa_employee, :full_name, :dob, :nationality, :address1, :address2, :address3, :postcode, :mobile, :passport_id, :country, :occupation, :email, :currencies, :source_wealth, :proof_identity, :proof_address, :source_funds, :annual_volume, :account_reason, :reference_code, 'pending')");

        $stmt->execute([
            ':user_id' => $user['id'],
            ':apa_employee' => $_POST['apaEmployee'],
            ':full_name' => $_POST['fullName'],
            ':dob' => $_POST['dob'],
            ':nationality' => $_POST['nationality'],
            ':address1' => $_POST['address1'],
            ':address2' => $_POST['address2'],
            ':address3' => $_POST['address3'],
            ':postcode' => $_POST['postcode'],
            ':mobile' => $_POST['mobile'],
            ':passport_id' => $_POST['passportId'],
            ':country' => $_POST['country'],
            ':occupation' => $_POST['occupation'],
            ':email' => $_POST['email'],
            ':currencies' => $_POST['currencies'],
            ':source_wealth' => $source_wealth,
            ':proof_identity' => $proof_identity,
            ':proof_address' => $proof_address,
            ':source_funds' => $source_funds,
            ':annual_volume' => $_POST['annualVolume'],
            ':account_reason' => $_POST['accountReason'],
            ':reference_code' => $_POST['referenceCode']
        ]);

        // Update the status to "processing"
        $updateStmt = $pdo->prepare("UPDATE kyc SET status = 'processing' WHERE reference_code = :reference_code");
        $updateStmt->execute([':reference_code' => $_POST['referenceCode']]);

        if ($updateStmt->rowCount() > 0) {
            // Send email notification
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'madocks.ai@gmail.com';
                $mail->Password = 'uexurwwgwuotfcge'; // Use App Password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
                $mail->addAddress('sdbangar2807@gmail.com');

                // Email content
                $mail->isHTML(true);
                $mail->Subject = 'New USDT Onboarding Submission';
                $mail->Body = "
                    <h3>New USDT Onboarding Submission Details</h3>
                    <p><strong>Reference Code:</strong> {$_POST['referenceCode']}</p>
                    <p><strong>Madocks Employee:</strong> {$_POST['apaEmployee']}</p>
                    <p><strong>Name:</strong> {$_POST['fullName']}</p>
                    <p><strong>DOB:</strong> {$_POST['dob']}</p>
                    <p><strong>Nationality:</strong> {$_POST['nationality']}</p>
                    <p><strong>Address:</strong> {$_POST['address1']} {$_POST['address2']} {$_POST['address3']}</p>
                    <p><strong>Post Code:</strong> {$_POST['postcode']}</p>
                    <p><strong>Mobile:</strong> {$_POST['mobile']}</p>
                    <p><strong>Passport ID:</strong> {$_POST['passportId']}</p>
                    <p><strong>Country:</strong> {$_POST['country']}</p>
                    <p><strong>Occupation:</strong> {$_POST['occupation']}</p>
                    <p><strong>Email:</strong> {$_POST['email']}</p>
                    <p><strong>Currencies:</strong> {$_POST['currencies']}</p>
                    <p><strong>Annual Volume:</strong> {$_POST['annualVolume']}</p>
                    <p><strong>Account Reason:</strong> {$_POST['accountReason']}</p>
                    <p>Below attached documents:</p>
                    <ol>
                        <li>Source of Wealth</li>
                        <li>Proof of Identity</li>
                        <li>Proof of Address</li>
                        <li>Source of Funds</li>
                    </ol>
                ";

                // Attach files if available
                if ($source_wealth) $mail->addAttachment($source_wealth);
                if ($proof_identity) $mail->addAttachment($proof_identity);
                if ($proof_address) $mail->addAttachment($proof_address);
                if ($source_funds) $mail->addAttachment($source_funds);

                // Send email
                if ($mail->send()) {
                    echo json_encode(["status" => "success", "message" => "Data stored, status updated, and email sent successfully"]);
                } else {
                    echo json_encode(["status" => "error", "message" => "Email sending failed"]);
                }
            } catch (Exception $e) {
                echo json_encode(["status" => "error", "message" => "Email could not be sent. Mailer Error: " . $mail->ErrorInfo]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "KYC submitted, but status update failed."]);
        }

        sendWhatsAppMessagetoapa_kyc($_POST['referenceCode']);


    } catch (Exception $e) {
        echo json_encode(["message" => "Error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["message" => "Invalid request method."]);
}

function sendWhatsAppMessagetoapa_kyc($referenceCode)

        {
            $sid = "AC123ed9e921a2f70fa480229231503368";
            $token = "5e8163958ae2e29d3757b261f62b072b";
            $twilio = new Client($sid, $token);

            $body = "User with Reference Code: $referenceCode has submitted KYC. Please check mail.";

            $message = $twilio->messages->create("whatsapp:+917588345894", [
                "from" => "whatsapp:+14155238886",
                "body" => $body
            ]);
        }

