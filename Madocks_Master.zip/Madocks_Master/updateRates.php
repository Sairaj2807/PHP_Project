<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jsonPath = 'exchangeRates.json';
    $data = $_POST['rates'];

    if (is_array($data)) {
        $formatted = [];
        foreach ($data as $currency => $rate) {
            $formatted["exchangeRate_$currency"] = floatval($rate);
        }

        file_put_contents($jsonPath, json_encode($formatted, JSON_PRETTY_PRINT));
        echo "Exchange rates updated successfully.";
    } else {
        echo "Invalid data format.";
    }
}
?>
