<?php
session_start();
include 'dbConnect.php'; // Ensure this file correctly initializes $pdo

$response = array('status' => 'incomplete', 'redirect' => 'kyc6.php');

if (isset($_SESSION['user']['id'])) {
    $user_id = $_SESSION['user']['id'];

    try {
        // Fetch KYC and Liquidity Agreement status
        $query = "SELECT 
                    (SELECT status FROM kyc WHERE user_id = :user_id) AS kyc_status,
                    (SELECT status FROM liquidity_agreements WHERE user_id = :user_id) AS liquidity_status";
        
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if both KYC and Liquidity Agreement are completed
        if ($result && $result['kyc_status'] === 'completed' && $result['liquidity_status'] === 'completed') {
            $response['status'] = 'completed';
            $response['redirect'] = 'deposit.php';
        }
    } catch (PDOException $e) {
        $response['error'] = 'Database error: ' . $e->getMessage();
    }
} else {
    $response['error'] = 'User not logged in';
}

echo json_encode($response);
?>
