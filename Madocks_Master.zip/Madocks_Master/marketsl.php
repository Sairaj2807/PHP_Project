<?php
session_start();
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">

</head>


<!-- page wrapper -->

<body>

    <div class="boxed_wrapper">


        <!-- preloader -->
        <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
            <div class="popup-inner">
                <div class="upper-box clearfix">
                    <figure class="logo-box pull-left"><a href="new_index.php"><img src="assets/images/logo1.png"
                                alt=""></a></figure>
                    <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
                </div>
                <div class="overlay-layer"></div>
                <div class="auto-container">
                    <div class="search-form">
                        <form method="post" action="new_index.php">
                            <div class="form-group">
                                <fieldset>
                                    <input type="search" class="form-control" name="search-input" value=""
                                        placeholder="Type your keyword and hit" required>
                                    <button type="submit"><i class="flaticon-loupe"></i></button>
                                </fieldset>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>-->


        <!-- main header -->
        <header class="main-header">
            <!-- header-top -->
            <div class="header-top">
                <div class="outer-container">
                    <div class="support-box">
                        <div class="icon-box"><img src="assets/images/icons/icon-1.png" alt=""></div>
                        <p><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact Us</a>
                            <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>---></p>
                    </div>
                    <!---<div class="text">
                        <div class="icon-box"><img src="assets/images/icons/icon-2.png" alt=""></div>
                        <p>£20 Discount & Get 24/7 Free Assistance</p>
                    </div>--->
                    <div class="right-column">
                        <!---<div class="guide-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-3.png" alt=""></div>
                            <p><a href="new_index.php">Free Trading Guides</a></p>
                        </div>--->
                        <!---<div class="help-center">
                            <div class="icon-box"><img src="assets/images/icons/icon-4.png" alt=""></div>
                            <p><a href="new_index.php">Help Center</a></p>
                        </div>--->
                        <!---<div class="language-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-5.png" alt=""></div>
                            <div class="select-box">
                                <select class="wide">
                                   <option data-display="English">English</option>
                                   <option value="1">Chinese</option>
                                   <option value="2">Hindi</option>
                                   <option value="3">Spanish</option>
                                   <option value="4">Turky</option>
                                </select>
                            </div>
                        </div>-->
                        <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="new_index.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="new_index.php"><img src="assets/images/logo1.png" alt=""></a>
                                </figure>
                            </div>
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="dropdown"><a href="new_index.php">Home</a>
                                            <!----<ul>
                                                <li><a href="new_index.php">Home One</a></li>
                                                <li><a href="index-2.html">Home Two</a></li>
                                                <li><a href="index-3.html">Home Three</a></li>
                                            </ul>----->
                                        </li>
                                        <li class="current dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                                <li><a href="markets.html">Markets</a></li>
                                                <li><a href="market-details.html">Details Page</a></li>
                                            </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!--<ul>
                                                <li><a href="platform.php">Platform</a></li>
                                                <li><a href="account.html">Our Accounts</a></li>
                                                <li><a href="account-details.html">Standard Account</a></li>
                                                <li><a href="account-details-2.html">Commision Account</a></li>
                                                <li><a href="account-details-3.html">STP Pro Account</a></li>
                                            </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="new_index.php">Education</a>
                                            <ul>
                                                <li><a href="education.html">Education</a></li>
                                                <li><a href="education-details.html">Detail Page</a></li>
                                            </ul>
                                        </li>-->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!---<ul>
                                                <li><a href="about.html">Company</a></li>
                                                <li><a href="history.html">History</a></li>
                                                <li><a href="team.html">Team</a></li>
                                                <li class="dropdown"><a href="new_index.php">Blog</a>
                                                    <ul>
                                                        <li><a href="blog.html">3 Columns</a></li>
                                                        <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                        <li><a href="blog-3.html">List View 01</a></li>
                                                        <li><a href="blog-4.html">List View 02</a></li>
                                                        <li><a href="blog-details.html">Single Post</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="contactl.php">Contact</a></li>
                                                <li><a href="faq.html">Faq’s</a></li>
                                                <li><a href="error.html">404</a></li>
                                            </ul>--->
                                        </li>
                                        
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!--<div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>-->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a href="new_index.php">Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            <!--<div class="btn-box"><a href="new_index.php" class="theme-btn btn-one"> <?php #echo '<span>Hi ' . $user['name'] . '</span>'; ?></a></div>-->
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="menu-area">
                            <div class="logo-box">
                                <figure class="logo"><a href="new_index.php"><img src="assets/images/logo1.png" alt=""></a>
                                </figure>
                            </div>
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                        <div class="menu-right-content">
                            <!--<div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>-->
                            <div class="clients-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-6.png" alt=""></div>
                                <a href="new_index.php">Client Portal<i class="flaticon-right-down"></i></a>
                            </div>
                            
                            <!--<div class="btn-box"><a href="register.php" class="theme-btn btn-one"> <?php #echo '<span>Hi ' . $user['name'] . '</span>'; ?></a></div>-->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>
                <div class="nav-logo"><a href="new_index.php"><img src="assets/images/logo2.png" alt="" title=""></a>
                </div>
                <div class="user-greeting">
                    <?php echo '<li><a href="new_index.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact Us</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="new_index.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank" rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank" rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- page-title -->
        <section class="page-title centred">
            <div class="bg-layer" style="background-image: url(assets/images/background/bg1_black_and_white.jpg);"></div>
            <div class="line-box">
                <div class="line-1"></div>
                <div class="line-2"></div>
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <h1>Markets</h1>
                    <p>Deaching of the great explorer of the truth the builder </p>
                    <ul class="bread-crumb clearfix">
                        <li><a href="new_index.php">Home</a></li>
                        <li>Markets</li>
                        
                    </ul>
                </div>
            </div>
        </section>
        <!-- page-title end -->


        <!-- markets-page-section -->
        <section class="markets-page-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 markets-block">
                        <div class="markets-block-one">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><img src="assets/images/resource/market1-1.jpg" alt="">
                                    </figure>
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-35.png);">
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="new_index.php">Trade Forex</a></h3>
                                    <p>Trade Forex with confidence using real-time analysis, advanced tools, risk management strategies. Access major currency pairs and execute trades with precision in a dynamic global market.</p>
                                    <div class="link-box">
                                        <!--<a href="new_index.php"><span>Read More</span></a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 markets-block">
                        <div class="markets-block-one">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><img src="assets/images/resource/market1-2.jpg" alt="">
                                    </figure>
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-35.png);">
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="new_index.php">Trade Gold & Silver</a></h3>
                                    <p>Trade Gold and Silver with precision using advanced market analysis and risk management tools. Benefit from the stability of precious metals and seize opportunities in the global market.</p>
                                    <div class="link-box">
                                        <!--<a href="new_index.php"><span>Read More</span></a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 markets-block">
                        <div class="markets-block-one">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><img src="assets/images/resource/market1-3.jpg" alt="">
                                    </figure>
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-35.png);">
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="new_index.php">Trade Oil & Gas</a></h3>
                                    <p>Trade Oil and Gas with real-time market insights and advanced trading tools. Capitalize on price movements in the energy sector with our secure and efficient trading platform.
                                    </p>
                                    <div class="link-box">
                                        <!--<a href="new_index.php"><span>Read More</span></a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 markets-block">
                        <div class="markets-block-one">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><img src="assets/images/resource/market1-4.jpg" alt="">
                                    </figure>
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-35.png);">
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="new_index.php">Trade Metals</a></h3>
                                    <p>Dignissimos ducimus qui blandiis praesentium voluptatum.</p>
                                    <div class="link-box">
                                        <!--<a href="new_index.php"><span>Read More</span></a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 markets-block">
                        <div class="markets-block-one">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><img src="assets/images/resource/market1-5.jpg" alt="">
                                    </figure>
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-35.png);">
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="new_index.php">Trade Shares</a></h3>
                                    <p>To take a trivial example which of to some advantage.</p>
                                    <div class="link-box">
                                        <!--<a href="new_index.php"><span>Read More</span></a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 markets-block">
                        <div class="markets-block-one">
                            <div class="inner-box">
                                <div class="image-box">
                                    <figure class="image"><img src="assets/images/resource/market1-6.jpg" alt="">
                                    </figure>
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-35.png);">
                                    </div>
                                </div>
                                <div class="lower-content">
                                    <h3><a href="new_index.php">Trade Crypto</a></h3>
                                    <p>Temporibus autem quibusdam et officiis debitis aut rerum.</p>
                                    <div class="link-box">
                                        <!--<a href="new_index.php"><span>Read More</span></a>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- markets-page-section end -->


        <!-- cta-section -->
        <section class="cta-section centred">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-22.png);"></div>
            <span class="big-text">bullion</span>
            <div class="auto-container">
                <div class="inner-box">
                    <h2>A 360 Trading Experience</h2>
                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate <br />velit esse quam nihil.</p>
                    <a href="new_index.php" class="theme-btn"><span>Read More</span></a>
                </div>
            </div>
        </section>
        <!-- cta-section end -->


        <!-- main-footer -->
        <footer class="main-footer">
            <div class="widget-section">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget contact-widget">
                                <div class="widget-title">
                                    <h3>Our Community</h3>
                                </div>
                                <div class="widget-content">
                                    <p>Here you'll find regular market updates, expert tips & stories.</p>
                                    <form action="contactl.php" method="post">
                                        <div class="form-group">
                                            <input type="email" name="email" placeholder="Email address..." required>
                                            <button type="submit"><img src="assets/images/icons/icon-27.png"
                                                    alt=""></button>
                                        </div>
                                    </form>
                                    <h3>Follow us</h3>
                                    <ul class="social-links clearfix">
                                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                                        <li><a href="new_index.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                        <li><a href="new_index.php"><i class="fa-brands fa-square-pinterest"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget">
                                <div class="widget-title">
                                    <h3>Useful Links</h3>
                                </div>
                                <div class="widget-content">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-6 col-sm-12 links-column">
                                            <ul class="links-list clearfix">
                                                <li><a href="new_index.php">About Us</a></li>
                                                <li><a href="new_index.php">Careers</a></li>
                                                <li><a href="new_index.php">Meet Our Team</a></li>
                                                <li><a href="new_index.php">Process</a></li>
                                                <li><a href="new_index.php">Mission & Vision</a></li>
                                                <li><a href="new_index.php">Faq’s</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 links-column">
                                            <ul class="links-list clearfix">
                                                <li><a href="new_index.php">Education</a></li>
                                                <li><a href="new_index.php">Trading Tools</a></li>
                                                <li><a href="new_index.php">Pricing List</a></li>
                                                <li><a href="new_index.php">Accout Types</a></li>
                                                <li><a href="new_index.php">Legal Notice</a></li>
                                                <li><a href="new_index.php">Privacy Policy</a></li>
                                                <li><a href="new_index.php">Conditions</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget assistance-widget">
                                <div class="widget-content">
                                    <h3>Need assistance?</h3>
                                    <p>Live chat with our service team for information & assistance.</p>
                                    <div class="assistance-box">
                                        <figure class="assistance-thumb"><img
                                                src="assets/images/resource/assistance1-1.jpg" alt=""></figure>
                                        <h5>Live Chat With</h5>
                                        <div class="link-box"><a href="new_index.php"><span>Expert</span></a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="bottom-inner">
                        <div class="copyright">
                            <p>&copy; <span>2025 <a href="new_index.php">Madocks</a>.</span> All Rights Reserved.</p>
                        </div>
                        <ul class="footer-card clearfix">
                            <li><a href="new_index.php"><i class="flaticon-symbols"></i></a></li>
                            <li><a href="new_index.php"><i class="flaticon-tool"></i></a></li>
                            <li><a href="new_index.php"><i class="flaticon-money"></i></a></li>
                            <li><a href="new_index.php"><i class="flaticon-symbol"></i></a></li>
                            <li><a href="new_index.php"><i class="flaticon-symbols-1"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <!-- main-footer end -->



        <!-- scroll to top -->
        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="flaticon-up-arrow"></i>
        </button>

    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

</html>