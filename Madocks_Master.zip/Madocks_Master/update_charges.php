<?php
$chargesFile = "charges.json";

// Get raw input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Validate
if (!$data || !isset($data["from"]) || !isset($data["to"])) {
    http_response_code(400);
    echo "Invalid data";
    exit;
}

$pairKey = $data["from"] . ">" . $data["to"];

// Load existing charges
$charges = [];
if (file_exists($chargesFile)) {
    $json = file_get_contents($chargesFile);
    $charges = json_decode($json, true);
}

// Update or add new entry
$charges[$pairKey] = [
    "base" => floatval($data["base"]),
    "tiers" => array_map(function ($tier) {
        return [
            "limit" => $tier["limit"] === "Infinity" ? "Infinity" : floatval($tier["limit"]),
            "charge" => floatval($tier["charge"])
        ];
    }, $data["tiers"])
];

// Save back to JSON file
file_put_contents($chargesFile, json_encode($charges, JSON_PRETTY_PRINT));
echo "Charge rates updated for $pairKey.";
?>
