<?php
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'madocks.ai@gmail.com';  // Your email
    $mail->Password = 'uexurwwgwuotfcge';  // Your App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
    $mail->addAddress('sdbangar2807@gmail.com');
    $mail->addAddress('harveyong.wv@gmail.com'); // Change to your email

    $mail->isHTML(true);
    $mail->Subject = 'Madocks Test Email';
    $mail->Body = '<h3>This is a test email from Madocks.</h3>';

    if ($mail->send()) {
        echo "Email sent successfully!";
    } else {
        echo "Failed to send email.";
    }
} catch (Exception $e) {
    echo "Mailer Error: {$mail->ErrorInfo}";
}
?>
