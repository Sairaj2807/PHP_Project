<?php
session_start();
require 'dbConnect.php';

if (!isset($_SESSION['user'])) {
    echo json_encode(["status" => "unauthorized"]);
    exit;
}

$user_id = $_SESSION['user']['id'];

$query = "SELECT status FROM liquidity_agreements WHERE user_id = :user_id ORDER BY uploaded_at DESC LIMIT 1";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$agreement = $stmt->fetch(PDO::FETCH_ASSOC);

$agreement_status = $agreement['status'] ?? 'pending';

echo json_encode(["status" => $agreement_status]);
?>