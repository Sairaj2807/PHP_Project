<?php
session_start();

if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

// Include database connection
require 'dbConnect.php';

// Handle profile photo upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_photo'])) {
    $userId = $_SESSION['user']['id']; // Assuming user ID is stored in session
    $uploadDir = "uploads/";
    $uploadFile = $uploadDir . basename($_FILES['profile_photo']['name']);

    // Ensure the uploads directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Move uploaded file to the uploads directory
    if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $uploadFile)) {
        // Update the user's profile photo path in the database
        $stmt = $pdo->prepare("UPDATE users SET profile_photo = :profile_photo WHERE id = :id");
        $stmt->execute([
            ':profile_photo' => $uploadFile,
            ':id' => $userId
        ]);
    }
}

// Retrieve all users from the database
$stmt = $pdo->query("SELECT name, phone, email, profile_photo FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle profile updates (Name, Phone, Email)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $userId = $_SESSION['user']['id']; // Ensure user ID is stored in the session
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);

    // Validate inputs
    if (!empty($name) && !empty($phone) && !empty($email)) {
        // Update the database
        $stmt = $pdo->prepare("UPDATE users SET name = :name, phone = :phone, email = :email WHERE id = :id");
        $stmt->execute([
            ':name' => $name,
            ':phone' => $phone,
            ':email' => $email,
            ':id' => $userId
        ]);

        // Update session with new details
        $_SESSION['user']['name'] = $name;
        $_SESSION['user']['phone'] = $phone;
        $_SESSION['user']['email'] = $email;

        // Redirect to prevent form resubmission
        header("Location: profile.php?update=success");
        exit();
    }
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">



    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!--<div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
    <div class="popup-inner">
        <div class="upper-box clearfix">
            <figure class="logo-box pull-left"><a href="indexl.php"><img src="assets/images/logonew.png"
                        alt=""></a></figure>
            <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <div class="overlay-layer"></div>
        <div class="auto-container">
            <div class="search-form">
                <form method="post" action="indexl.php">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value=""
                                placeholder="Type your keyword and hit" required>
                            <button type="submit"><i class="flaticon-loupe"></i></button>
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="tel:+6593628491">+6593628491</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                                <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="indexl.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                            <a href="logout.php">Logout</a>
                        </li>
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                            <a href="register.php">Signup</a>
                        </li>
                    </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="indexl.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png" alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="dropdown"><a href="indexl.php">Home</a>
                                            <!---<ul>
                                        <li><a href="indexl.php">Home One</a></li>
                                        <li><a href="indexl.php">Home Two</a></li>
                                        <li><a href="indexl.php">Home Three</a></li>
                                    </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                        <li><a href="marketsl.php">Markets</a></li>
                                        <li><a href="market-details.html">Details Page</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                        <li><a href="platform.php">Platform</a></li>
                                        <li><a href="account.html">Our Accounts</a></li>
                                        <li><a href="account-details.html">Standard Account</a></li>
                                        <li><a href="account-details-2.html">Commision Account</a></li>
                                        <li><a href="account-details-3.html">STP Pro Account</a></li>
                                    </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="indexl.php">Education</a>
                                    <ul>
                                        <li><a href="education.html">Education</a></li>
                                        <li><a href="education-details.html">Detail Page</a></li>
                                    </ul>
                                </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                        <li><a href="about.html">Company</a></li>
                                        <li><a href="history.html">History</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li class="dropdown"><a href="indexl.php">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">3 Columns</a></li>
                                                <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                <li><a href="blog-3.html">List View 01</a></li>
                                                <li><a href="blog-4.html">List View 02</a></li>
                                                <li><a href="blog-details.html">Single Post</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                        <li><a href="faq.html">Faq’s</a></li>
                                        <li><a href="error.html">404</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="dropdown"><a href="usdt.php">USDT</a>

                                        </li>
                                        <li class="dropdown"><a href="sneat/html/index.html">Dashboard</a> </li>
                                    </ul>
                                </div>
                            </nav>
                            <!--<div class="menu-right-content">

                                <div class="search-box-outer search-toggler">
                                    <i class="flaticon-search"></i></div>
                                    <div class="btn-box"><a href="" class="theme-btn btn-one">
                                
                                   </a></div>
                                </div>
                            </div>-->
                        </div>
                    </div>
                </div>

                <!--sticky Header-->
                <div class="sticky-header">
                    <div class="auto-container">
                        <div class="outer-box">
                            <div class="logo-box">
                                <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png"
                                            alt=""></a>
                                </figure>
                            </div>
                            <div class="menu-area">
                                <nav class="main-menu clearfix">
                                    <!--Keep This Empty / Menu will come through Javascript-->
                                </nav>
                                <div class="menu-right-content">
                                    <div class="search-box-outer search-toggler">
                                        <!--<i class="flaticon-search"></i></div>-->
                                        <!---<div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                                



                            </a></div>--->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="indexl.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="indexl.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="tel:+6593628491">+65 9362 8491</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="indexl.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->



        <!------ existing section --->
        <section class="cta-section  ">
            <div class="container bootstrap snippet">
                <hr>
                <?php if (!empty($users)): ?>
                <?php foreach ($users as $user): ?>

                <div class="row">
                    <div class="col-sm-3">

                        <div class="text-center">
                            <img src="<?php echo !empty($user['profile_photo']) ? htmlspecialchars($user['profile_photo']) : 'http://ssl.gstatic.com/accounts/ui/avatar_2x.png'; ?>"
                                class="avatar img-circle img-thumbnail" alt="Profile Photo">

                            <h6>Upload a profile photo...</h6>
                            <form action="profile.php" method="post" enctype="multipart/form-data">
                                <input type="file" name="profile_photo"
                                    class="text-center center-block file-upload form-control">
                                <button type="submit" class="btn btn-primary btn-block">Upload</button>
                            </form>
                        </div>
                        <br>
                        <div class="panel panel-default">
                            <div class="panel-heading">Website <i class="fa fa-link fa-1x"></i></div>
                            <div class="panel-body"><a href="http://madocks.ai">MADOCKS.AI</a></div>
                        </div>
                    </div>

                    <div class="col-sm-9">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
                        </ul>

                        <div class="tab-content">
                            <div class="tab-pane active" id="home">
                                <hr>


                                <form class="form" action="profile.php" method="post" id="updateForm">
                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="first_name">
                                                <h4><strong>NAME</strong></h4>
                                            </label>
                                            <input type="text" class="form-control" name="name"
                                                value="<?php echo htmlspecialchars($user['name']); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="phone">
                                                <h4><strong>Phone</strong></h4>
                                            </label>
                                            <input type="text" class="form-control" name="phone"
                                                value="<?php echo htmlspecialchars($user['phone']); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="email">
                                                <h4><strong>Email</strong></h4>
                                            </label>
                                            <input type="email" class="form-control" name="email"
                                                value="<?php echo htmlspecialchars($user['email']); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-xs-12">
                                            <br>
                                            <button class="btn btn-lg btn-success" name="update_profile"
                                                type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save
                                                Changes</button>

                                        </div>
                                    </div>
                                </form>







                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <p>No users found.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/language.js"></script>
    <script src="assets/js/jquery-ui.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>
</body>

</html>