<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'dbConnect.php';
require_once __DIR__ . '/vendor/autoload.php'; // TCPDF (installed via Composer)

// Validate inputs
$user_id     = $_POST['user_id']     ?? null;
$full_name   = $_POST['full_name']   ?? null;
$passport_id = $_POST['passport_id'] ?? null;
$address     = $_POST['address']     ?? null;
$date        = $_POST['date']        ?? null;
$signature   = $_POST['signature']   ?? null;

if (!$user_id || !$full_name || !$passport_id || !$address || !$date || !$signature) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields.']);
    exit;
}

// Ensure directories exist
if (!file_exists('pdfs')) mkdir('pdfs', 0777, true);
if (!file_exists('temp')) mkdir('temp', 0777, true);

// Decode and save signature image
$signature = str_replace('data:image/png;base64,', '', $signature);
$signature = str_replace(' ', '+', $signature);
$signatureData = base64_decode($signature);
$signaturePath = __DIR__ . "/temp/signature_$user_id.png";

if (!file_put_contents($signaturePath, $signatureData)) {
    echo json_encode(['status' => 'error', 'message' => 'Unable to save signature.']);
    exit;
}

// Create PDF file
require_once __DIR__ . '/vendor/tecnickcom/tcpdf/tcpdf.php';
$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 11);

// PDF content
$html = <<<EOD
<h2 style="text-align: center;">Individual Liquidity Agreement</h2>
<p><strong>Date:</strong> $date</p>
<p><strong>Client Name:</strong> $full_name</p>
<p><strong>Passport ID:</strong> $passport_id</p>
<p><strong>Address:</strong> $address</p>
<br>
<p>This agreement is made between <strong>$full_name</strong> (Client) and <strong>ATLANTIC PARTNERS SPC FUND</strong> (APA), on behalf of the Atlantic Partners Asia Fund Segregated Portfolio, a company incorporated under the laws of Cayman Island.</p>

<h3>WHEREAS:</h3>
<p>A. Client proposes to provide APA with short term liquidity in agreed jurisdictions...</p>
<p>B. The purpose of this Agreement is to establish cooperation on a best efforts basis.</p>
<p>C. The Agreement does not override any applicable laws...</p>

<h3>1. Definitions</h3>
<p>Includes APA Nominated Account, Available Local Funds, Business Day, KYC Pack, etc.</p>

<h3>2. Confidentiality</h3>
<p>Each Party shall maintain strict confidentiality of shared data and communications...</p>

<h3>3. Transaction Process</h3>
<p>Outlines how funds are agreed upon, sent, received and processed.</p>

<h3>4. Communication and Dealings</h3>
<p>Each party agrees to only engage in transactions with introduced parties via the other party.</p>

<h3>5. Acknowledgements</h3>
<p>Each Party is responsible for understanding all legal and financial implications...</p>

<h3>6. Commencement and Termination</h3>
<p>The agreement lasts 2 years unless earlier terminated under clause 6(b).</p>

<h3>7. Limitation of Liability</h3>
<p>Liability is limited to USD 1,000 except in cases of gross negligence or fraud.</p>

<h3>8. Notices</h3>
<p>All official communication must be in writing and acknowledged.</p>

<h3>9. Dispute Resolution</h3>
<p>Disputes will be resolved by arbitration at the Singapore International Arbitration Centre (SIAC).</p>

<h3>10. General</h3>
<p>This Agreement is governed by and shall be enforced in accordance with the laws of Hong Kong.</p>

<br><br>
<p><strong>Signed by:</strong> $full_name</p>
<p><strong>Date:</strong> $date</p>
<p><strong>Client Signature:</strong></p>
EOD;

$pdf->writeHTML($html, true, false, true, false, '');

// Add signature image
if (file_exists($signaturePath)) {
    $pdf->Image($signaturePath, 15, $pdf->GetY() + 5, 60, 0, 'PNG');
}

// Save the PDF file
$filename = "liquidity_agreement_user{$user_id}_" . time() . ".pdf";
$filepath = __DIR__ . "/pdfs/$filename";
$pdf->Output($filepath, 'F');

// Save filename in DB
$stmt = $pdo->prepare("INSERT INTO liquidity_agreements (user_id, pdf) VALUES (?, ?)");
$stmt->execute([$user_id, $filename]);

echo json_encode([
    'status' => 'success',
    'message' => 'Agreement PDF generated successfully.',
    'pdf' => "pdfs/$filename"
]);
?>
