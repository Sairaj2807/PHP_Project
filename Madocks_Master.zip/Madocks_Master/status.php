<?php
include 'dbConnect.php';
session_start(); // Ensure session is started
//name
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

// Check if the session user data exists
if (!isset($_SESSION['user']['id'])) {
    die("Error: User not logged in.");
}

// Retrieve user ID correctly
$user_id = $_SESSION['user']['id'];

$query = "SELECT kyc_status, deposit_status, receive_status 
          FROM transactions 
          WHERE user_id = :user_id AND transaction_type = 'buy' 
          ORDER BY transaction_time DESC LIMIT 1";

$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

// Default values if no transaction is found
$kyc_status = $transaction['kyc_status'] ?? 'pending';
$deposit_status = $transaction['deposit_status'] ?? 'pending';
$receive_status = $transaction['receive_status'] ?? 'pending';

function getStatusColor($status)
{
    return match ($status) {
        'completed' => 'green',
        'failed' => 'red',
        default => 'orange',
    };



}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php'; // Ensure PHPMailer is installed via Composer

function sendTransactionStatusEmail($email, $statusType, $status, $transaction)
{
    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // SMTP server (Gmail)
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com'; // Your SMTP email
        $mail->Password = 'uexurwwgwuotfcge'; // Your SMTP password or App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Sender & Recipient
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = "Transaction Update Order #{$transaction['id']} - $statusType Changed to $status";
        $mail->Body = "
            <p>Dear User,</p>
            <p>Your transaction status has been updated:</p>
            <ul>
                <li><strong>Update Type:</strong> $statusType</li>
                <li><strong>Status:</strong> <span style='color:" . ($status == 'completed' ? 'green' : 'red') . ";'>$status</span></li>
                <li><strong>Currency Sent:</strong> {$transaction['currency_send']}</li>
                <li><strong>Amount Sent:</strong> {$transaction['amount_send']}</li>
                <li><strong>Currency Received:</strong> {$transaction['currency_receive']}</li>
                <li><strong>Amount Received:</strong> {$transaction['amount_receive']}</li>
            </ul>
            <p>Please log in to your account for more details.</p>
            <p>Best Regards,<br>Madocks</p>
        ";

        // Send email
        $mail->send();
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
    }
}

// Fetch user email and latest transaction details
$query = "SELECT u.email, t.* 
          FROM users u 
          JOIN transactions t ON u.id = t.user_id 
          WHERE t.user_id = :user_id AND t.transaction_type = 'buy' 
          ORDER BY t.transaction_time DESC LIMIT 1";

$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

if ($transaction) {
    $user_email = $transaction['email'];

    // Array to track sent emails to prevent duplicates
    $sentEmails = [];

    // Check status changes and send email (if not sent before)
    if (($kyc_status == 'completed' || $kyc_status == 'failed') && !isset($sentEmails['KYC'])) {
        sendTransactionStatusEmail($user_email, 'KYC Status', ucfirst($kyc_status), $transaction);
        $sentEmails['KYC'] = true;
    }

    if (($deposit_status == 'completed' || $deposit_status == 'failed') && !isset($sentEmails['Deposit'])) {
        sendTransactionStatusEmail($user_email, 'Deposit Status', ucfirst($deposit_status), $transaction);
        $sentEmails['Deposit'] = true;
    }

    if (($receive_status == 'completed' || $receive_status == 'failed') && !isset($sentEmails['Receive'])) {
        sendTransactionStatusEmail($user_email, 'Receive Status', ucfirst($receive_status), $transaction);
        $sentEmails['Receive'] = true;
    }
}


//






?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">






    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 800px;
            height: 80vh;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .modal-header {
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h2 {
            margin: 0;
            font-size: 20px;
        }

        .close-btn {
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        iframe {
            width: 100%;
            height: 90%;
            border: none;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            text-align: center;
            padding: 40px;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .circle {
            width: 200px;
            height: 200px;
            background: white;
            border-radius: 50%;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            position: relative;
        }

        .circle span {
            color: #007bff;
        }

        .options {
            display: flex;
            flex-direction: column;
            gap: 30px;
            margin-left: 80px;
        }

        .option {
            display: flex;
            align-items: center;
            background: white;
            padding: 15px;
            border-radius: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            justify-content: space-between;
            position: relative;
        }

        .icon {
            width: 40px;
            height: 40px;
            background: #f0f8ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
        }

        .text {
            text-align: left;
            flex: 1;
        }

        .text h3 {
            margin: 0;
            font-size: 16px;
            color: #007bff;
        }

        .text p {
            margin: 5px 0 0;
            font-size: 14px;
            color: #555;
        }

        .btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .modaldeposit {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modaldeposit-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modaldeposit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        input[type="file"],
        input[type="text"] {
            display: block;
            margin: 10px 0;
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!--<div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
    <div class="popup-inner">
        <div class="upper-box clearfix">
            <figure class="logo-box pull-left"><a href="indexl.php"><img src="assets/images/logonew.png"
                        alt=""></a></figure>
            <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <div class="overlay-layer"></div>
        <div class="auto-container">
            <div class="search-form">
                <form method="post" action="indexl.php">
                    <div class="form-group">
                        <fieldset>
                            <input type="search" class="form-control" name="search-input" value=""
                                placeholder="Type your keyword and hit" required>
                            <button type="submit"><i class="flaticon-loupe"></i></button>
                        </fieldset>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="tel:+6593628491">+6593628491</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                                <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="indexl.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                            <a href="logout.php">Logout</a>
                        </li>
                        <li>
                            <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                            <a href="register.php">Signup</a>
                        </li>
                    </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="indexl.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png" alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="dropdown"><a href="indexl.php">Home</a>
                                            <!---<ul>
                                        <li><a href="indexl.php">Home One</a></li>
                                        <li><a href="indexl.php">Home Two</a></li>
                                        <li><a href="indexl.php">Home Three</a></li>
                                    </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                        <li><a href="marketsl.php">Markets</a></li>
                                        <li><a href="market-details.html">Details Page</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                        <li><a href="platform.php">Platform</a></li>
                                        <li><a href="account.html">Our Accounts</a></li>
                                        <li><a href="account-details.html">Standard Account</a></li>
                                        <li><a href="account-details-2.html">Commision Account</a></li>
                                        <li><a href="account-details-3.html">STP Pro Account</a></li>
                                    </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="indexl.php">Education</a>
                                    <ul>
                                        <li><a href="education.html">Education</a></li>
                                        <li><a href="education-details.html">Detail Page</a></li>
                                    </ul>
                                </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                        <li><a href="about.html">Company</a></li>
                                        <li><a href="history.html">History</a></li>
                                        <li><a href="team.html">Team</a></li>
                                        <li class="dropdown"><a href="indexl.php">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">3 Columns</a></li>
                                                <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                <li><a href="blog-3.html">List View 01</a></li>
                                                <li><a href="blog-4.html">List View 02</a></li>
                                                <li><a href="blog-details.html">Single Post</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">Contact</a></li>
                                        <li><a href="faq.html">Faq’s</a></li>
                                        <li><a href="error.html">404</a></li>
                                    </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="current dropdown"><a href="usdt.php">USDT</a>

                                        </li>
                                    </ul>
                                </div>
                            </nav>
                            <div class="menu-right-content">

                                <div class="search-box-outer search-toggler">
                                    <!--<i class="flaticon-search"></i></div>-->
                                    <!---<div class="btn-box"><a href="" class="theme-btn btn-one">
                                
                            </a></div>--->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--sticky Header-->
                <div class="sticky-header">
                    <div class="auto-container">
                        <div class="outer-box">
                            <div class="logo-box">
                                <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png"
                                            alt=""></a>
                                </figure>
                            </div>
                            <div class="menu-area">
                                <nav class="main-menu clearfix">
                                    <!--Keep This Empty / Menu will come through Javascript-->
                                </nav>
                                <div class="menu-right-content">
                                    <div class="search-box-outer search-toggler">
                                        <!--<i class="flaticon-search"></i></div>-->
                                        <!---<div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                                



                            </a></div>--->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="indexl.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="indexl.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="tel:+6593628491">+65 9362 8491</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="indexl.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->



        <!------ existing section --->
        <section class="banner-style-three centred">
            <div class="container">
                <div class="circle">
                    USDT/FIAT <br> <span>conversion steps</span>
                </div>

                <div class="options">
                    <div class="option">
                        <div class="icon">👤</div>
                        <div class="text">
                            <h3> Step1: KYC submission</h3>
                            <p>Status: <span style="color: <?php echo getStatusColor($kyc_status); ?>;">
                                    <?php echo ucfirst($kyc_status); ?>
                                </span></p>
                        </div>
                        <button class="btn" onclick="openModal()">Select</button>
                    </div>

                    <div class="option">
                        <div class="icon">⚖️</div>
                        <div class="text">
                            <h3>Step2: Deposit Fiat</h3>
                            <p>Status: <span style="color: <?php echo getStatusColor($deposit_status); ?>;">
                                    <?php echo ucfirst($deposit_status); ?>
                                </span></p>
                        </div>
                        <button class="btn" onclick="openDepositModal()">Select</button>
                    </div>

                    <div class="option">
                        <div class="icon">📊</div>
                        <div class="text">
                            <h3>Step3: Money received</h3>
                            <p>Status: <span style="color: <?php echo getStatusColor($receive_status); ?>;">
                                    <?php echo ucfirst($receive_status); ?>
                                </span></p>
                        </div>
                    </div>
                </div>
            </div>

            <div id="usdtModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>USDT Onboarding</h2>
                        <span class="close-btn" onclick="closeModal()">×</span>
                    </div>
                    <iframe id="embeddedFrame" src="https://www.atlanticpartnersasia.com/onboarding-forms-pvt"
                        onload="detectButtonClick()"></iframe>
                </div>
            </div>

            <div id="depositModal" class="modaldeposit">
                <div class="modaldeposit-content">
                    <div class="modaldeposit-header">
                        <h2>Deposit USDT</h2>
                        <span class="close-btn" onclick="closeDepositModal()">×</span>
                    </div>



                    <h2>Buy Transactions</h2>
                    <div id="transactionData">Loading transactions...</div>

                    <h3>Please deposit the money at the following bank address:</h3>
                    <p><strong>Bank Address:</strong> 1234 XYZ Bank, Account No: 987654321</p>

                    <form id="depositForm" enctype="multipart/form-data">
                        <label>Upload Receipt:</label>
                        <input type="file" name="receipt" required>

                        <label>Enter USDT Address:</label>
                        <input type="text" name="usdt_address" required>

                        <button type="submit" class="btn">Submit</button>
                    </form>



                </div>
            </div>
        </section>
    </div>

    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/language.js"></script>
    <script src="assets/js/jquery-ui.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

    <script>
        function openModal() {
            document.getElementById("usdtModal").style.display = "block";
        }

        function closeModal() {
            document.getElementById("usdtModal").style.display = "none";
        }

        function detectButtonClick() {
            let iframe = document.getElementById("embeddedFrame").contentWindow;

            setInterval(() => {
                try {
                    let buttons = iframe.document.getElementsByTagName("button");
                    if (buttons.length > 0) {
                        buttons[0].addEventListener("click", function () {
                            document.getElementById("embeddedFrame").src =
                                "https://www.atlanticpartnersasia.com/onboarding-forms-pvt";
                        });
                    }
                } catch (error) {
                    console.warn(
                        "Cross-origin access denied. Unable to detect button click."
                    );
                }
            }, 1000);
        }

        function openDepositModal() {
            document.getElementById("depositModal").style.display = "block";
            fetch('transaction.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('transactionData').innerHTML = data;
                });
        }

        function closeDepositModal() {
            document.getElementById("depositModal").style.display = "none";
        }
        // uploads 
        /*document.getElementById('depositForm').addEventListener('submit', function (e) {
            e.preventDefault(); // Prevent default form submission
 
            let formData = new FormData(this); // Collect form data
 
            fetch('processDeposit.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert('Deposit information submitted successfully.');
                        closeDepositModal(); // Close the deposit modal
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
        });*/



        document.getElementById("depositForm").addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent the form from submitting normally

            const formData = new FormData(this);

            fetch("processDeposit.php", {
                method: "POST",
                body: formData,
            })
                .then(response => response.text())
                .then(data => {
                    if (data.trim() === "success") {
                        alert("Transaction updated successfully!");
                        closeDepositModal(); // Close the modal on success
                    } else {
                        alert(data); // Show the error message
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred while submitting the form.");
                });
        });


    </script>

</body>

</html>