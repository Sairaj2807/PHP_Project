<?php
require 'dbConnect.php';
require 'vendor/autoload.php'; // Load PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["change_password"])) {
    $email = $_POST["email"];

    // Check if email exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(":email", $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo "<script>alert('Email is not registered.'); window.location.href='forgot_password.php';</script>";
        exit;
    }

    // Send password reset link
    $reset_link = "http://localhost/bullion/change_password.php?email=" . urlencode($email);

    $mail = new PHPMailer(true);
    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge'; // Use App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Sender & Recipient
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = 'Reset Your Password';
        $mail->Body    = "<p>Click the link below to reset your password:</p>
                          <p><a href='$reset_link'>$reset_link</a></p>";

        if ($mail->send()) {
            echo "<script>alert('Password reset link has been sent to your email.'); window.location.href='forgot_password.php';</script>";
        } else {
            echo "<script>alert('Failed to send email.'); window.location.href='forgot_password.php';</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Mail Error: {$mail->ErrorInfo}'); window.location.href='forgot_password.php';</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Forgot Password</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    />
    <link rel="stylesheet" href="style2.css" />
  </head>

  <body>
    <div class="container" id="signIn">
      <h1 class="form-title">Change Password</h1>
      <form method="POST" >
        <div class="input-group">
          <i class="fas fa-envelope"></i>
          <input 
            type="email"
            name="email"
            id="email"
            placeholder="Email"
            required
          />
        </div>
        
        <input type="submit" class="btn" value="Get Link " name="change_password" />
      </form>
    </div>
    <script src="script.js"></script>
  </body>
</html>