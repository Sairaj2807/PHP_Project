<?php
session_start();
require 'dbConnect.php'; // Ensure this file contains the correct PDO connection

require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to generate OTP
function generateOTP() {
    return rand(100000, 999999);
}

// Function to send OTP via email
function sendOTP($email, $otp) {
    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com'; // Your email
        $mail->Password = 'uexurwwgwuotfcge'; // Use App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Sender & Recipient
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP for Password Reset';
        $mail->Body    = "<p>Your OTP for password reset is: <strong>$otp</strong></p>";

        // Send email
        return $mail->send();
    } catch (Exception $e) {
        return false;
    }
}

// Handle OTP Request
if (isset($_POST['send_otp'])) {
    $email = trim($_POST['email']);

    if (!empty($email)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $otp = generateOTP();
            $_SESSION['otp'] = $otp;
            $_SESSION['email'] = $email;

            if (sendOTP($email, $otp)) {
                echo "<script>alert('OTP sent successfully! Check your email.');</script>";
            } else {
                echo "<script>alert('Failed to send OTP. Check SMTP settings.');</script>";
            }
        } else {
            echo "<script>alert('Email not registered!');</script>";
        }
    } else {
        echo "<script>alert('Please enter your email!');</script>";
    }
}

// Handle Password Change
if (isset($_POST['change_password'])) {
    $entered_otp = trim($_POST['otp']);
    $new_password = trim($_POST['password']);

    if (!empty($entered_otp) && !empty($new_password)) {
        if ($entered_otp == $_SESSION['otp']) {
            $email = $_SESSION['email'];
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

            $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE email = :email");
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':email', $email);

            if ($stmt->execute()) {
                echo "<script>alert('Password changed successfully!'); window.location='login.php';</script>";
                session_destroy();
            } else {
                echo "<script>alert('Failed to update password! Try again.');</script>";
            }
        } else {
            echo "<script>alert('Invalid OTP! Please enter the correct OTP.');</script>";
        }
    } else {
        echo "<script>alert('Please enter OTP and new password!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body>

    <div class="container">
        <h1 class="form-title">Change Password</h1>
        
        <form method="POST">
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Email" required>
            </div>

            <input type="submit" class="btn" value="Send OTP" name="send_otp">

            <div class="input-group">
                <i class="fas fa-key"></i>
                <input type="text" name="otp" placeholder="Enter OTP" required>
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="New Password" required>
            </div>

            <input type="submit" class="btn" value="Change Password" name="change_password">
        </form>

    </div>

</body>
</html>
