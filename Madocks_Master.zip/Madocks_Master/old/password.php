<?php
/*session_start();
require 'vendor/autoload.php';
require 'dbConnect.php'; // Ensure this file correctly connects to the database

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$pdo = new PDO("mysql:host=localhost;dbname=auth", "root", "");

if (isset($_POST['send_otp'])) {
    $email = $_POST['email'];

    // Check if email exists in the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        echo "<script>'Email not found!'</script>";
    } else {
        $otp = rand(100000, 999999); // Generate 6-digit OTP
        $_SESSION['otp'] = $otp;
        $_SESSION['email'] = $email;

        // Send OTP via Email
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'madocks.ai@gmail.com'; // Your email
            $mail->Password = 'uexurwwgwuotfcge'; // App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Your OTP Code';
            $mail->Body = "<h3>Your OTP is: <strong>$otp</strong></h3>";

            if ($mail->send()) {
                echo "<script>alert('OTP sent to your email!');</script>";
            } else {
                echo "<script>alert('Failed to send OTP!');</script>";
            }
        } catch (Exception $e) {
            echo "<script>alert('Mailer Error: {$mail->ErrorInfo}');</script>";
        }
    }
}

if (isset($_POST['change_password'])) {
    $entered_otp = $_POST['otp'];
    $new_password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    
    if (!isset($_SESSION['otp']) || $_SESSION['otp'] != $entered_otp) {
        echo "<script>alert('Invalid OTP!');</script>";
    } else {
        $email = $_SESSION['email'];
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->execute([$new_password, $email]);

        unset($_SESSION['otp']);
        unset($_SESSION['email']);
        
        echo "<script>alert('Password changed successfully!');</script>";
    }
}*/



session_start();
require 'vendor/autoload.php';
require 'dbConnect.php'; // Ensure this file correctly connects to the database

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//$pdo = new PDO("mysql:host=localhost;dbname=auth", "root", "");
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_otp'])) {
        $email = $_POST['email'];

        // Check if email exists in the database
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            $_SESSION['errors']['email'] = "Email not found!";
        } else {
            $otp = rand(100000, 999999); // Generate 6-digit OTP
            $_SESSION['otp'] = $otp;
            $_SESSION['email'] = $email;

            // Send OTP via Email
            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'madocks.ai@gmail.com'; // Your email
                $mail->Password = 'uexurwwgwuotfcge'; // App Password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
                $mail->addAddress($email);

                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Code';
                $mail->Body = "<h3>Your OTP is: <strong>$otp</strong></h3>";

                if ($mail->send()) {
                    $_SESSION['success'] = "OTP sent to your email!";
                } else {
                    $_SESSION['errors']['otp'] = "Failed to send OTP!";
                }
            } catch (Exception $e) {
                $_SESSION['errors']['otp'] = "Mailer Error: {$mail->ErrorInfo}";
            }
        }
    }

    if (isset($_POST['change_password'])) {
        $entered_otp = $_POST['otp'];
        $new_password = $_POST['password'];

        if (!isset($_SESSION['otp']) || $_SESSION['otp'] != $entered_otp) {
            $_SESSION['errors']['otp'] = "Invalid OTP!";
        } elseif (empty($new_password)) {
            $_SESSION['errors']['password'] = "Password cannot be empty!";
        } else {
            $email = $_SESSION['email'];
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
            $stmt->execute([$hashed_password, $email]);

            unset($_SESSION['otp']);
            unset($_SESSION['email']);
            
            $_SESSION['success'] = "Password changed successfully!";
        }
    }

    header("Location: recover.php");
    exit();
}
?>


