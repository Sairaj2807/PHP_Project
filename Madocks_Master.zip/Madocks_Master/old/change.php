<?php
/* require 'dbConnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["new_password"])) {
    $email = $_GET["email"] ?? null;
    $new_password = $_POST["password"];

    if (!$email) {
        echo "<script>alert('Invalid request.'); window.location.href='forgot.html';</script>";
        exit;
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

    // Update the password in the database
    $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE email = :email");
    $stmt->bindParam(":password", $hashed_password);
    $stmt->bindParam(":email", $email);
    
    if ($stmt->execute()) {
        echo "<script>alert('Password updated successfully.'); window.location.href='login.html';</script>";
    } else {
        echo "<script>alert('Error updating password.'); window.location.href='change_password.html';</script>";
    }
}*/
?>

<?php
require 'dbConnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["new_password"])) {
    $email = $_POST["email"] ?? null;
    $new_password = $_POST["password"];

    if (!$email) {
        echo "<script>alert('Invalid request.'); window.location.href='forgot.html';</script>";
        exit;
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

    // Update the password in the database
    $stmt = $pdo->prepare("UPDATE users SET password = :password WHERE email = :email");
    $stmt->bindParam(":password", $hashed_password);
    $stmt->bindParam(":email", $email);

    if ($stmt->execute()) {
        echo "<script>alert('Password updated successfully.'); window.location.href='login.html';</script>";
    } else {
        echo "<script>alert('Error updating password.'); window.location.href='change_password.html';</script>";
    }
}
?>


