<!--<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <div class="container">
        <h1 class="form-title">Change Password</h1>
        
        <form method="POST" action="password.php">
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Enter Email" required>
            </div>

            <input type="submit" class="btn" value="Send OTP" name="send_otp">
            
            <div class="input-group">
                <i class="fas fa-key"></i>
                <input type="text" name="otp" placeholder="Enter OTP">
            </div>

            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="New Password" >
            </div>

            <input type="submit" class="btn" value="Change Password" name="change_password">
        </form>
    </div>

    
</body>
</html>--->




<?php
session_start();

$errors = isset($_SESSION['errors']) ? $_SESSION['errors'] : [];
$success = isset($_SESSION['success']) ? $_SESSION['success'] : "";



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style2.css">
</head>

<body>
    <div class="container">
        <h1 class="form-title">Change Password</h1>

        <!-- Display Error Messages -->
        <?php if (!empty($errors)) : ?>
            <?php foreach ($errors as $error) : ?>
                <div class="error-main">
                    <p><?php echo $error; ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Display Success Message -->
        <?php if (!empty($success)) : ?>
            <div class="error-main">
                <p><?php echo $success; ?></p>
            </div>
            
        <?php endif; ?>

        <form method="POST" action="password.php">
            <!-- Email Input -->
            <div class="input-group">
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" placeholder="Enter Email" required >
            </div>

            <input type="submit" class="btn" value="Send OTP" name="send_otp">

            <!-- OTP Input -->
            <div class="input-group">
                <i class="fas fa-key"></i>
                <input type="text" name="otp" placeholder="Enter OTP">
            </div>

            <!-- New Password Input -->
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="New Password">
            </div>

            <input type="submit" class="btn" value="Change Password" name="change_password">
        </form>
    </div>

    <script src="script.js"></script>

</body>

</html>

<?php
// Clear errors and success message after displaying
unset($_SESSION['errors']);
unset($_SESSION['success']);
?>


