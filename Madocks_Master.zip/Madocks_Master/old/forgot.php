<?php
require 'dbConnect.php';
require 'vendor/autoload.php'; // Load PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["change_password"])) {
    $email = $_POST["email"];

    // Check if email exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->bindParam(":email", $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo "<script>alert('Email is not registered.'); window.location.href='forgot.html';</script>";
        exit;
    }

    // Send password reset link
    $reset_link = "http://localhost/bullion/change_password.html?email=" . urlencode($email);

    $mail = new PHPMailer(true);
    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge'; // Use App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Sender & Recipient
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email);

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = 'Reset Your Password';
        $mail->Body    = "<p>Click the link below to reset your password:</p>
                          <p><a href='$reset_link'>$reset_link</a></p>";

        if ($mail->send()) {
            echo "<script>alert('Password reset link has been sent to your email.'); window.location.href='forgot.html';</script>";
        } else {
            echo "<script>alert('Failed to send email.'); window.location.href='forgot.html';</script>";
        }
    } catch (Exception $e) {
        echo "<script>alert('Mail Error: {$mail->ErrorInfo}'); window.location.href='forgot.html';</script>";
    }
}
?>
