<?php
    // Update the path below to your autoload.php,
    // see https://getcomposer.org/doc/01-basic-usage.md


    require 'vendor/autoload.php';
    use Twilio\Rest\Client;

    $sid    = "AC123ed9e921a2f70fa480229231503368";
    $token  = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $message = $twilio->messages
      ->create("+917588345894", // to
        array(
          "from" => "+15393525772",
          "body" => "otp is 1234"
        )
      );

print($message->sid);