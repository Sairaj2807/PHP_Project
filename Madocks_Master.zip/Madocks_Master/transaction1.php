<?php
session_start();
include 'dbConnect.php'; // Ensure this file correctly initializes $pdo

if (!isset($_SESSION['user'])) {
    die("User not logged in.");
}

$user_id = $_SESSION['user']['id'];

if (!isset($pdo)) {
    die("Database connection error.");
}

try {
    // Fetch the latest record for the logged-in user
    $stmt = $pdo->prepare("SELECT currency_send, amount_send, currency_receive, amount_receive FROM records WHERE user_id = :user_id ORDER BY id DESC LIMIT 1");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($records)) {
        echo "<p>No records found.</p>";
    } else {
        echo "<table border='1' width='100%'>
                <tr>
                    <th>Currency Sent</th>
                    <th>Amount Sent</th>
                    <th>Currency Received</th>
                    <th>Amount Received</th>
                </tr>";
        foreach ($records as $record) {
            echo "<tr>
                    <td>{$record['currency_send']}</td>
                    <td>{$record['amount_send']}</td>
                    <td>{$record['currency_receive']}</td>
                    <td>{$record['amount_receive']}</td>
                  </tr>";
        }
        echo "</table>";
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
?>
