<?php
session_start();
include 'dbConnect.php'; // Ensure this file correctly initializes $pdo

if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

if (!isset($_SESSION['user'])) {
    die("User not logged in.");
}

$user_id = $_SESSION['user']['id'];

if (!isset($pdo)) {
    die("Database connection error.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['transaction_type'], $_POST['currency_send'], $_POST['amount_send'], $_POST['currency_receive'], $_POST['amount_receive'])) {
        exit("Missing required fields.");
    }

    $transaction_type = $_POST['transaction_type'];
    $currency_send = $_POST['currency_send'];
    $amount_send = $_POST['amount_send'];
    $currency_receive = $_POST['currency_receive'];
    $amount_receive = $_POST['amount_receive'];

    try {
        $sql = "INSERT INTO transactions (user_id, transaction_type, amount_send, currency_send, amount_receive, currency_receive, transaction_time) 
                VALUES (:user_id, :transaction_type, :amount_send, :currency_send, :amount_receive, :currency_receive, NOW())";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':transaction_type', $transaction_type, PDO::PARAM_STR);
        $stmt->bindParam(':amount_send', $amount_send, PDO::PARAM_STR);
        $stmt->bindParam(':currency_send', $currency_send, PDO::PARAM_STR);
        $stmt->bindParam(':amount_receive', $amount_receive, PDO::PARAM_STR);
        $stmt->bindParam(':currency_receive', $currency_receive, PDO::PARAM_STR);

        $stmt->execute();
    } catch (PDOException $e) {
        exit("Database error: " . $e->getMessage());
    }
}
?>









<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy & Sell USDT</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f2f2;
            text-align: center;
            margin: 0;
            padding: 40px;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        .text-section {
            flex: 1;
            max-width: 500px;
            text-align: left;
            padding: 20px;
        }

        .text-section h1 {
            font-size: 30px;
            font-weight: bold;
        }

        .text-section p {
            font-size: 16px;
            color: #444;
            line-height: 1.6;
        }

        .card {
            flex: 1;
            max-width: 400px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: left;
            position: relative;
        }

        .button-group {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .button-group button {
            background-color: #ccc;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 5px;
            border-radius: 5px;
        }

        .button-group button.active {
            background-color: #007bff;
            color: white;
        }

        .exchange-box {
            display: flex;
            flex-direction: column;
            margin-top: 40px;
        }

        .exchange-box label {
            font-weight: bold;
            margin-top: 10px;
        }

        .exchange-box select,
        .exchange-box input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            box-sizing: border-box;
        }

        .buy-button {
            width: 100%;
            background: #007bff;
            color: white;
            font-size: 18px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
        }

        .buy-button:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!--<div class="loader-wrap">
    <div class="preloader">
        <div class="preloader-close">x</div>
        <div id="handle-preloader" class="handle-preloader">
            <div class="animation-preloader">
                <div class="spinner"></div>
                <div class="txt-loading">
                    <span data-text-preloader="M" class="letters-loading">
                        M
                    </span>
                    <span data-text-preloader="A" class="letters-loading">
                        A
                    </span>
                    <span data-text-preloader="D" class="letters-loading">
                        D
                    </span>
                    <span data-text-preloader="O" class="letters-loading">
                        O
                    </span>
                    <span data-text-preloader="C" class="letters-loading">
                        C
                    </span>
                    <span data-text-preloader="K" class="letters-loading">
                        K
                    </span>
                    <span data-text-preloader="S" class="letters-loading">
                        S
                    </span>
                </div>
            </div>
        </div>
          </div>
     </div>-->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
<div class="popup-inner">
<div class="upper-box clearfix">
    <figure class="logo-box pull-left"><a href="indexl.php"><img src="assets/images/logonew.png"
                alt=""></a></figure>
    <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
</div>
<div class="overlay-layer"></div>
<div class="auto-container">
    <div class="search-form">
        <form method="post" action="indexl.php">
            <div class="form-group">
                <fieldset>
                    <input type="search" class="form-control" name="search-input" value=""
                        placeholder="Type your keyword and hit" required>
                    <button type="submit"><i class="flaticon-loupe"></i></button>
                </fieldset>
            </div>
        </form>
    </div>
</div>
</div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="tel:+6593628491">+6593628491</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                        <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="indexl.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                <li>
                    <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                    <a href="logout.php">Logout</a>
                </li>
                <li>
                    <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                    <a href="register.php">Signup</a>
                </li>
            </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="indexl.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png" alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="dropdown"><a href="indexl.php">Home</a>
                                            <!---<ul>
                                <li><a href="indexl.php">Home One</a></li>
                                <li><a href="indexl.php">Home Two</a></li>
                                <li><a href="indexl.php">Home Three</a></li>
                            </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                <li><a href="marketsl.php">Markets</a></li>
                                <li><a href="market-details.html">Details Page</a></li>
                            </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                <li><a href="platform.php">Platform</a></li>
                                <li><a href="account.html">Our Accounts</a></li>
                                <li><a href="account-details.html">Standard Account</a></li>
                                <li><a href="account-details-2.html">Commision Account</a></li>
                                <li><a href="account-details-3.html">STP Pro Account</a></li>
                            </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="indexl.php">Education</a>
                            <ul>
                                <li><a href="education.html">Education</a></li>
                                <li><a href="education-details.html">Detail Page</a></li>
                            </ul>
                        </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                <li><a href="about.html">Company</a></li>
                                <li><a href="history.html">History</a></li>
                                <li><a href="team.html">Team</a></li>
                                <li class="dropdown"><a href="indexl.php">Blog</a>
                                    <ul>
                                        <li><a href="blog.html">3 Columns</a></li>
                                        <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                        <li><a href="blog-3.html">List View 01</a></li>
                                        <li><a href="blog-4.html">List View 02</a></li>
                                        <li><a href="blog-details.html">Single Post</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact</a></li>
                                <li><a href="faq.html">Faq’s</a></li>
                                <li><a href="error.html">404</a></li>
                            </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="current dropdown"><a href="usdt.php">USDT</a>

                                        </li>
                                    </ul>
                                </div>
                            </nav>
                            <div class="menu-right-content">

                                <div class="search-box-outer search-toggler">
                                    <!--<i class="flaticon-search"></i></div>-->
                                    <!---<div class="btn-box"><a href="" class="theme-btn btn-one">
                        
                    </a></div>--->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--sticky Header-->
                <div class="sticky-header">
                    <div class="auto-container">
                        <div class="outer-box">
                            <div class="logo-box">
                                <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png"
                                            alt=""></a>
                                </figure>
                            </div>
                            <div class="menu-area">
                                <nav class="main-menu clearfix">
                                    <!--Keep This Empty / Menu will come through Javascript-->
                                </nav>
                                <div class="menu-right-content">
                                    <div class="search-box-outer search-toggler">
                                        <!--<i class="flaticon-search"></i></div>-->
                                        <!---<div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                        



                    </a></div>--->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="indexl.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="indexl.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="tel:+6593628491">+65 9362 8491</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="indexl.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->
        <!--- existing section -->
        <section class="banner-style-three centred">
            <div class="container">
                <div class="text-section">
                    <h1>Convert Fiat Into Crypto: Buy USDT with Various Currencies Online</h1>
                    <p>USDT is one of the most popular stablecoins, widely used for trading and investments.</p>
                </div>

                <div class="card">
                    <div class="button-group">
                        <button id="buyBtn" onclick="toggleMode('buy')">Buy</button>
                        <button id="sellBtn" onclick="toggleMode('sell')">Sell</button>
                    </div>

                    <form method="POST">
                        <input type="hidden" id="transaction_type" name="transaction_type" value="buy">

                        <div id="exchangeBox" class="exchange-box">
                            <!---<label>You send</label>
                    <select name="currency_send">
                        <option>EUR</option>
                        <option>AED</option>
                        <option>ARS</option>
                        <option>INR</option>
                        <option>EUR (Euro)</option>
                        <option>AED (United Arab Emirates Dirham)</option>
                        <option>ARS (Argentine Peso)</option>
                        <option>AUD (Australian Dollar)</option>
                        <option>INR (Indian Rupee)</option>
                        <option>JPY (Japanese Yen)</option>
                        <option>GBP (Pound Sterling)</option>
                        <option>SGD (Singapore Dollar)</option>
                        <option>VND (Vietnamese Dong)</option>
                        <option>ZAR (South African Rand)</option>
                    </select>
                    <input type="number" name="amount_send" id="amountSend" value="100">

                    <label>You get</label>
                    <select name="currency_receive">
                        <option>USDT</option>
                    </select>
                    <input type="number" name="amount_receive" id="amountReceive" value="0.00096624" readonly>-->
                        </div>

                        <button type="submit" class="buy-button" id="actionButton" onclick="redirectToPage()">Please
                            select
                            Buy or Sell</button>
                    </form>
                </div>
            </div>
        </section>
    </div>

     <!-- jequery plugins -->
     <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/language.js"></script>
    <script src="assets/js/jquery-ui.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>
    <script>
        function toggleMode(mode) {
            let buyBtn = document.getElementById('buyBtn');
            let sellBtn = document.getElementById('sellBtn');
            let actionButton = document.getElementById('actionButton');
            let transactionType = document.getElementById('transaction_type');

            if (mode === 'sell') {
                sellBtn.classList.add('active');
                buyBtn.classList.remove('active');
                actionButton.innerText = "Sell";
                transactionType.value = "sell";
                currentMode = "sell"
                exchangeBox.innerHTML = `
                       <label>You send</label>
                    <select name="currency_send">
                    <option>USDT</option>
                    </select>
                    <input type="number" name="amount_send" id="amountSend" value="100">
                    <label>You get</label>
                    <select name="currency_receive">

                    <option>AED</option>
                        <option>ARS</option>
                        <option>INR</option>  
                        <option>EUR (Euro)</option>
                        <option>AED (United Arab Emirates Dirham)</option>
                        <option>ARS (Argentine Peso)</option>
                        <option>AUD (Australian Dollar)</option>
                        <option>INR (Indian Rupee)</option>
                        <option>JPY (Japanese Yen)</option>
                        <option>GBP (Pound Sterling)</option>
                        <option>SGD (Singapore Dollar)</option>
                        <option>VND (Vietnamese Dong)</option>
                        <option>ZAR (South African Rand)</option>
                    </select>
                    <input type="number" name="amount_receive" id="amountReceive" value="0.00096624" readonly>
                    
                `;

            } else {
                buyBtn.classList.add('active');
                sellBtn.classList.remove('active');
                actionButton.innerText = "Buy";
                transactionType.value = "buy";
                currentMode = 'buy';
                exchangeBox.innerHTML = `
                            <label>You send</label>
                    <select name="currency_send">
                       <!-- <option>EUR</option>
                        <option>AED</option>
                        <option>ARS</option>
                        <option>INR</option>-->
                        <option>EUR (Euro)</option>
                        <option>AED (United Arab Emirates Dirham)</option>
                        <option>ARS (Argentine Peso)</option>
                        <option>AUD (Australian Dollar)</option>
                        <option>INR (Indian Rupee)</option>
                        <option>JPY (Japanese Yen)</option>
                        <option>GBP (Pound Sterling)</option>
                        <option>SGD (Singapore Dollar)</option>
                        <option>VND (Vietnamese Dong)</option>
                        <option>ZAR (South African Rand)</option>
                    </select>
                    <input type="number" name="amount_send" id="amountSend" value="100">

                    <label>You get</label>
                    <select name="currency_receive">
                        <option>USDT</option>
                    </select>
                    <input type="number" name="amount_receive" id="amountReceive" value="0.00096624" readonly>
                    
                `;
            }
        }




        document.getElementById('actionButton').addEventListener('click', function (event) {
            event.preventDefault();  // Prevent form submission

            let userId = <?php echo $_SESSION['user']['id'] ?? 'null'; ?>;
            if (userId === null) {
                alert("User not logged in!");
                return;
            }

            let transactionType = document.getElementById('transaction_type').value;
            let currencySend = document.querySelector('select[name="currency_send"]').value;
            let amountSend = document.getElementById('amountSend').value;
            let currencyReceive = document.querySelector('select[name="currency_receive"]').value;
            let amountReceive = document.getElementById('amountReceive').value;

            if (!transactionType || !currencySend || !amountSend || !currencyReceive || !amountReceive) {
                alert("Please fill in all fields.");
                return;
            }

            let data = new FormData();
            data.append("transaction_type", transactionType);
            data.append("currency_send", currencySend);
            data.append("amount_send", amountSend);
            data.append("currency_receive", currencyReceive);
            data.append("amount_receive", amountReceive);

            fetch('usdt.php', {
                method: 'POST',
                body: data
            })
                .then(response => response.text())
                .then(result => {
                    //console.log("Server Response:", result);
                    //alert(result);
                })
                .catch(error => console.error('Error:', error));
        });

        function redirectToPage() {
            if (currentMode === 'buy') {
                window.location.href = "status.php";
            }
            if (currentMode === 'sell') {
                window.location.href = "status_sell.php";
            }
        }
    </script>

</body>

</html>