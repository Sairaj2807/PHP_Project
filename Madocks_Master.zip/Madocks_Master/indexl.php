<?php
session_start();
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>MADOCKS.AI</title>

    <!-- Fav Icon -->
    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">

</head>


<!-- page wrapper -->

<body>

    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="M" class="letters-loading">
                                M
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="D" class="letters-loading">
                                D
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="C" class="letters-loading">
                                C
                            </span>
                            <span data-text-preloader="K" class="letters-loading">
                                K
                            </span>
                            <span data-text-preloader="S" class="letters-loading">
                                S
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
            <div class="popup-inner">
                <div class="upper-box clearfix">
                    <figure class="logo-box pull-left"><a href="indexl.php"><img src="assets/images/logonew.png"
                                alt=""></a></figure>
                    <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
                </div>
                <div class="overlay-layer"></div>
                <div class="auto-container">
                    <div class="search-form">
                        <form method="post" action="indexl.php">
                            <div class="form-group">
                                <fieldset>
                                    <input type="search" class="form-control" name="search-input" value=""
                                        placeholder="Type your keyword and hit" required>
                                    <button type="submit"><i class="flaticon-loupe"></i></button>
                                </fieldset>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                    Us</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="chinese.php">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                                        <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="indexl.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                                <li>
                                    <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                                    <a href="logout.php">Logout</a>
                                </li>
                                <li>
                                    <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                                    <a href="register.php">Signup</a>
                                </li>
                            </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="indexl.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png" alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="current dropdown"><a href="indexl.php">Home</a>
                                            <!---<ul>
                                                <li><a href="indexl.php">Home One</a></li>
                                                <li><a href="indexl.php">Home Two</a></li>
                                                <li><a href="indexl.php">Home Three</a></li>
                                            </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                                <li><a href="marketsl.php">Markets</a></li>
                                                <li><a href="market-details.html">Details Page</a></li>
                                            </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                                <li><a href="platform.php">Platform</a></li>
                                                <li><a href="account.html">Our Accounts</a></li>
                                                <li><a href="account-details.html">Standard Account</a></li>
                                                <li><a href="account-details-2.html">Commision Account</a></li>
                                                <li><a href="account-details-3.html">STP Pro Account</a></li>
                                            </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="indexl.php">Education</a>
                                            <ul>
                                                <li><a href="education.html">Education</a></li>
                                                <li><a href="education-details.html">Detail Page</a></li>
                                            </ul>
                                        </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                                <li><a href="about.html">Company</a></li>
                                                <li><a href="history.html">History</a></li>
                                                <li><a href="team.html">Team</a></li>
                                                <li class="dropdown"><a href="indexl.php">Blog</a>
                                                    <ul>
                                                        <li><a href="blog.html">3 Columns</a></li>
                                                        <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                                        <li><a href="blog-3.html">List View 01</a></li>
                                                        <li><a href="blog-4.html">List View 02</a></li>
                                                        <li><a href="blog-details.html">Single Post</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="contact.html">Contact</a></li>
                                                <li><a href="faq.html">Faq’s</a></li>
                                                <li><a href="error.html">404</a></li>
                                            </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator </a> </li>
                                        <li class="dropdown"><a href="usdt_main.php">USDT </a>

                                        </li>
                                        <li class="dropdown"><a href="sneat/html/index.html">Dashboard</a> </li>
                                    </ul>
                                </div>
                            </nav>
                            <!--<div class="menu-right-content">

                                <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                                <div class="btn-box"><a href="" class="theme-btn btn-one">
                                        
                                    </a></div>
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="indexl.php"><img src="assets/images/logonew.png" alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                            <!--<div class="menu-right-content">
                                <div class="search-box-outer search-toggler"><i class="flaticon-search"></i></div>
                                <div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                                        



                                 </a></div>
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="indexl.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="indexl.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="https://wa.me/+6593628491" target="_blank" rel="noopener noreferrer">Contact
                                Here</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="indexl.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="indexl.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- banner-style-three -->
        <section class="banner-style-three centred">
            <div class="pattern-layer">
                <div class="pattern-1" style="background-image: url(assets/images/shape/shape-23.png);"></div>
                <div class="pattern-2" style="background-image: url(assets/images/shape/shape-24.png);"></div>
            </div>
            <div class="image-layer">
                <figure class="image-1"><img src="assets/images/banner/banner1-img-1.png" alt=""></figure>
                <figure class="image-2 float-bob-y"><img src="assets/images/banner/banner1-img-2.png" alt=""></figure>
                <figure class="image-3 float-bob-y"><img src="assets/images/banner/banner1-img-3.png" alt=""></figure>
                <figure class="image-4 float-bob-x"><img src="assets/images/banner/banner1-img-4.png" alt=""></figure>
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <div class="inner-box">
                        <h5>Market Capitalisation</h5>
                        <h2>3.7 <span>B</span></h2>
                        <div class="graph-box"><img src="assets/images/icons/graph-5.png" alt=""></div>
                    </div>
                    <div class="upper-box">
                        <h2><span>Leading</span> the way <br />in Online Forex <span>Trading</span></h2>
                        <p>Deaching of the great explorer of the truth builder <br />of human happiness.</p>
                        <a href="#house-of-eas" class="theme-btn"><span>Try House of EAs</span></a>
                    </div>
                    <div class="lower-box">
                        <div class="icon-box"><img src="assets/images/icons/icon-44.png" alt=""></div>
                        <ul class="rating clearfix">
                            <li><i class="flaticon-star"></i></li>
                            <li><i class="flaticon-star"></i></li>
                            <li><i class="flaticon-star"></i></li>
                            <li><i class="flaticon-star"></i></li>
                            <li><i class="flaticon-star"></i></li>
                        </ul>
                        <p>4.8 Rating Based on 2.5k Reviews. <!---<a href="indexl.php"><span>Read Reviews</span>---></a>
                        </p>
                    </div>
                </div>
            </div>
        </section>
        <!-- banner-style-three end -->

        <!-- scrpt for smooth scrolling --->
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                document.querySelector('.theme-btn').addEventListener("click", function (event) {
                    event.preventDefault();
                    document.querySelector("#house-of-eas").scrollIntoView({
                        behavior: "smooth"
                    });
                });
            });
        </script>

        <section class="feature-section centred">
            <div class="sec-title centred">
                <h2>Welcome to <span>MADOCKS</span></h2>
                <p>At madocks, we empower traders with smart solutions through our three core offerings:</p>
            </div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">
                        <div class="feature-block-one wow fadeInUp animated" data-wow-delay="00ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-inner">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-25.png);">
                                    </div>
                                    <div class="icon-box"><img src="assets/images/icons/icon-51.png" alt=""></div>
                                </div>
                                <h6>We Offer</h6>
                                <h3><a href="index.html">Copy Trading</a></h3>
                                <p>Seamlessly replicate the trades of experienced market players to learn and
                                    potentially enhance your trading performance.
                                </p>
                                <!--<div class="link-box">
                            <a href="index.html"><span>Read More</span></a>
                        </div>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">
                        <div class="feature-block-one wow fadeInUp animated" data-wow-delay="300ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-inner">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-25.png);">
                                    </div>
                                    <div class="icon-box"><img src="assets/images/icons/icon-52.png" alt=""></div>
                                </div>
                                <h6>We Offer</h6>
                                <h3><a href="index.html">Trading Education</a></h3>
                                <p>Access a suite of resources, courses, and webinars designed to help you understand
                                    market dynamics and refine your strategies.</p>
                                <!--<div class="link-box">
                            <a href="index.html"><span>Read More</span></a>
                        </div>-->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">
                        <div class="feature-block-one wow fadeInUp animated" data-wow-delay="600ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-inner">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-25.png);">
                                    </div>
                                    <div class="icon-box"><img src="assets/images/icons/icon-53.png" alt=""></div>
                                </div>
                                <h6>We Offer</h6>
                                <h3><a href="index.html">Customised Indicators</a></h3>
                                <p>Benefit from our tailored technical indicators that support your unique trading style
                                    and objectives.</p>
                                <!--<div class="link-box">
                            <a href="index.html"><span>Read More</span></a>
                        </div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>










        <!-- feature-section -->
        <section id="house-of-eas" class="feature-section centred">
            <div class="sec-title centred">
                <h2>House of <span>EAs</span></h2>
            </div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">
                        <div class="feature-block-one wow fadeInUp animated" data-wow-delay="00ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-inner">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-25.png);">
                                    </div>
                                    <div class="icon-box"><img src="assets/images/icons/icon-51.png" alt=""></div>
                                </div>
                                <h6>We Offer</h6>
                                <h3><a href="plutus.php">EA1</a></h3>
                                <p>Find fault with a man who chooses to annoying consequences.</p>
                                <div class="link-box">
                                    <a href="plutus.php"><span>Read More</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">
                        <div class="feature-block-one wow fadeInUp animated" data-wow-delay="300ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-inner">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-25.png);">
                                    </div>
                                    <div class="icon-box"><img src="assets/images/icons/icon-52.png" alt=""></div>
                                </div>
                                <h6>We Offer</h6>
                                <h3><a href="plutus.php">EA2</a></h3>
                                <p>Great explorer of the truth the master builder human happiness.</p>
                                <div class="link-box">
                                    <a href="plutus.php"><span>Read More</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!---<div class="col-lg-4 col-md-6 col-sm-12 feature-block">
                        <div class="feature-block-one wow fadeInUp animated" data-wow-delay="600ms"
                            data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-inner">
                                    <div class="shape" style="background-image: url(assets/images/shape/shape-25.png);">
                                    </div>
                                    <div class="icon-box"><img src="assets/images/icons/icon-53.png" alt=""></div>
                                </div>
                                <h6>We Offer</h6>
                                <h3><a href="indexl.php">Sentiment Analysis</a></h3>
                                <p>Tationally encount consequences that again is there anyone.</p>
                                <div class="link-box">
                                    <a href="indexl.php"><span>Read More</span></a>
                                </div>
                            </div>
                        </div>
                    </div>--->
                </div>
            </div>
        </section>
        <!-- feature-section end -->

        <section class="apps-section bg-color-1">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-7.png);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image-box">
                            <figure class="image"><img src="assets/images/resource/colab.png" alt=""></figure>
                            <!--<div class="image-content">
                                <div class="text-box">
                                    <h2>4.7<span>Million +</span></h2>
                                    <p>Installation</p>
                                </div>
                                <ul class="rating clearfix">
                                    <li>4.96</li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                    <li><i class="flaticon-star"></i></li>
                                </ul>
                            </div>--->
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title">
                                <span class="sub-title">Business Collaboration</span>
                                <h2>Partner with<span>Madocks</span> </h2>
                            </div>
                            <div class="text-box">
                                <p>Do you have a proven trading strategy that you believe has the potential to shine as
                                    an Expert Advisor (EA)? Whether you need assistance with coding, optimization, or
                                    the marketing and sales of your EA, we are here to collaborate.</p>
                            </div>
                            <div class="inner-box">
                                <div class="single-item">
                                    <div class="icon-box"><img src="assets/images/icons/icon-26.png" alt=""></div>
                                    <h3>Get in Touch</h3>
                                    <p> harvey@madocks.ai</p>
                                </div>
                                <!--<div class="single-item">
                                    <div class="icon-box"><img src="assets/images/icons/icon-26.png" alt=""></div>
                                    <h3>Notification feature</h3>
                                    <p>Rem aperiam eaque ipsa quae ab illo inventore veritatis.</p>
                                </div>-->
                            </div>

                            <div class="text-box">
                                <p>
                                    Collaboration Note:All collaborations and projects are developed in adherence to the
                                    regulatory guidelines in Singapore. The tools and strategies we develop are provided
                                    for educational and research purposes only and do not constitute unlicensed
                                    financial advice.
                                </p>
                            </div>
                            <!--<div class="btn-box">
                                <a href="index.html" class="theme-btn btn-three"><span>Official App</span></a>
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- apps-section end -->







        <!-- pricing-style-three -->
        <section class="pricing-style-three">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-26.png);"></div>
            <div class="auto-container">
                <div class="sec-title centred">
                    <span class="sub-title">Popular Pairs</span>
                    <h2>Top <span>Pricing List</span> in Market</h2>
                </div>
                <div class="row clearfix">
                    <div class="col-xl-12 col-lg-12 col-md-12 big-column">
                        <div class="row clearfix">
                            <div class="col-lg-4 col-md-6 col-sm-12 pricing-block">
                                <div class="pricing-block-two">
                                    <div class="inner-box">
                                        <div class="link red"><a href="indexl.php"><i
                                                    class="flaticon-right-down"></i></a></div>
                                        <div class="currency-box">
                                            <ul class="list-item clearfix">
                                                <li>eur</li>
                                                <li><i class="flaticon-exchange"></i></li>
                                                <li>usd</li>
                                            </ul>
                                            <span class="currency-rate red">-0.14%</span>
                                        </div>
                                        <p><span>$1.06199 USD</span><span>Sell at 1.06185</span></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-12 pricing-block">
                                <div class="pricing-block-two">
                                    <div class="inner-box">
                                        <div class="link green"><a href="indexl.php"><i
                                                    class="flaticon-right-down"></i></a></div>
                                        <div class="currency-box">
                                            <ul class="list-item clearfix">
                                                <li>usd</li>
                                                <li><i class="flaticon-exchange"></i></li>
                                                <li>jpy</li>
                                            </ul>
                                            <span class="currency-rate green">+0.04%</span>
                                        </div>
                                        <p><span>$1.22195 USD</span><span>Sell at 1.06199</span></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12 col-sm-12 pricing-block">
                                <div class="pricing-block-two">
                                    <div class="inner-box">
                                        <div class="link green"><a href="indexl.php"><i
                                                    class="flaticon-right-down"></i></a></div>
                                        <div class="currency-box">
                                            <ul class="list-item clearfix">
                                                <li>usd</li>
                                                <li><i class="flaticon-exchange"></i></li>
                                                <li>jpy</li>
                                            </ul>
                                            <span class="currency-rate green">+0.04%</span>
                                        </div>
                                        <p><span>$1.22195 USD</span><span>Sell at 1.06199</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-12 col-md-12 big-column offset-xl-2">
                        <div class="row clearfix">
                            <div class="col-lg-6 col-md-6 col-sm-12 pricing-block">
                                <div class="pricing-block-two">
                                    <div class="inner-box">
                                        <div class="link green"><a href="indexl.php"><i
                                                    class="flaticon-right-down"></i></a></div>
                                        <div class="currency-box">
                                            <ul class="list-item clearfix">
                                                <li>usd</li>
                                                <li><i class="flaticon-exchange"></i></li>
                                                <li>jpy</li>
                                            </ul>
                                            <span class="currency-rate green">+0.04%</span>
                                        </div>
                                        <p><span>$1.22195 USD</span><span>Sell at 1.06199</span></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 pricing-block">
                                <div class="pricing-block-two">
                                    <div class="inner-box">
                                        <div class="link red"><a href="indexl.php"><i
                                                    class="flaticon-right-down"></i></a></div>
                                        <div class="currency-box">
                                            <ul class="list-item clearfix">
                                                <li>eur</li>
                                                <li><i class="flaticon-exchange"></i></li>
                                                <li>usd</li>
                                            </ul>
                                            <span class="currency-rate red">-0.14%</span>
                                        </div>
                                        <p><span>$1.06199 USD</span><span>Sell at 1.06185</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="link-box centred">
                    <a href="indexl.php"><span>See More Pairs</span></a>
                </div>--->
            </div>
        </section>
        <!-- pricing-style-three end -->


        <!-- markets-section -->
        <section class="markets-section sec-pad">
            <div class="auto-container">
                <div class="sec-title">
                    <span class="sub-title">Markets</span>
                    <h2>Wide Range of <span>Markets</span></h2>
                </div>
                <div class="three-item-carousel owl-carousel owl-theme owl-dots-none nav-style-one">
                    <div class="markets-block-one">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/resource/market1-1.jpg" alt=""></figure>
                                <div class="shape" style="background-image: url(assets/images/shape/shape-27.png);">
                                </div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="indexl.php">Trade Forex</a></h3>
                                <p>Trade Forex with confidence using real-time analysis, advanced tools, risk management
                                    strategies. Access major currency pairs and execute trades with precision in a
                                    dynamic global market.</p>
                                <div class="link-box">
                                    <!--<a href="indexl.php"><span>Read More</span></a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="markets-block-one">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/resource/market1-2.jpg" alt=""></figure>
                                <div class="shape" style="background-image: url(assets/images/shape/shape-27.png);">
                                </div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="indexl.php">Trade Gold & Silver</a></h3>
                                <p>Trade Gold and Silver with precision using advanced market analysis and risk
                                    management tools. Benefit from the stability of precious metals and seize
                                    opportunities in the global market.</p>
                                <div class="link-box">
                                    <!--<a href="indexl.php"><span>Read More</span></a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="markets-block-one">
                        <div class="inner-box">
                            <div class="image-box">
                                <figure class="image"><img src="assets/images/resource/market1-3.jpg" alt=""></figure>
                                <div class="shape" style="background-image: url(assets/images/shape/shape-27.png);">
                                </div>
                            </div>
                            <div class="lower-content">
                                <h3><a href="indexl.php">Trade Oil & Gas</a></h3>
                                <p>Trade Oil and Gas with real-time market insights and advanced trading tools.
                                    Capitalize on price movements in the energy sector with our secure and efficient
                                    trading platform.
                                </p>
                                <div class="link-box">
                                    <!--<a href="indexl.php"><span>Read More</span></a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- markets-section end -->

        <section class="faq-section sec-pad">
            <div class="auto-container">
                <div class="sec-title centred">
                    <span class="sub-title">Faq’s</span>
                    <h2>Find <span>Answers</span> to Common <br />Questions</h2>
                </div>
                <div class="inner-box">
                    <ul class="accordion-box">
                        <li class="accordion block active-block">
                            <div class="acc-btn active">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>01</span>
                                <h4>What is Copy Trading?</h4>

                            </div>
                            <div class="acc-content current">
                                <div class="text">
                                    <p>Copy trading is a process that allows you to automatically replicate the trades
                                        executed by experienced traders. This service is designed to help you learn from
                                        market experts and gain exposure to various trading strategies.
                                        <br />
                                        <span>Disclaimer: </span> Our copy trading service is provided for educational
                                        purposes. We do not
                                        guarantee any specific trading outcomes.
                                        <br />
                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="accordion block">
                            <div class="acc-btn">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>02</span>
                                <h4>How Do Your Trading Education Services Work?</h4>

                            </div>
                            <div class="acc-content">
                                <div class="text">
                                    <p>Our trading education platform offers a range of resources—including video
                                        tutorials, webinars, and written guides—to help you understand market analysis,
                                        risk management, and trading strategy development.
                                        Note: The educational content is intended to enhance your trading knowledge and
                                        does not constitute professional financial advice.</p>
                                </div>
                            </div>
                        </li>
                        <li class="accordion block">
                            <div class="acc-btn">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>03</span>
                                <h4>Are Your Customised Indicators and Tools Suitable for All Traders?</h4>
                                <p></p>
                            </div>
                            <div class="acc-content">
                                <div class="text">
                                    <p>Our customised indicators are developed to suit a variety of trading styles and
                                        market conditions. We recommend that you test these tools thoroughly (using demo
                                        accounts where possible) to ensure they meet your individual trading needs.
                                        Disclaimer: The effectiveness of any trading tool may vary, and no tool can
                                        guarantee success. Trading inherently involves risk.

                                    </p>
                                </div>
                            </div>
                        </li>
                        <li class="accordion block">
                            <div class="acc-btn">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>04</span>
                                <h4>Is Your Service Compliant with Singapore Laws?</h4>
                                <p></p>
                            </div>
                            <div class="acc-content">
                                <div class="text">
                                    <p>We strive to operate in full compliance with the regulatory requirements in
                                        Singapore. The content, tools, and services provided on this website are
                                        intended solely for educational and informational purposes.
                                        Reminder: This website does not offer professional financial advice, and users
                                        should seek guidance from a licensed financial advisor before making any
                                        investment decisions.</p>
                                </div>
                            </div>
                        </li>

                        <li class="accordion block">
                            <div class="acc-btn">
                                <div class="icon-box"><i class="flaticon-plus"></i></div>
                                <span>05</span>
                                <h4>Who Can I Contact for Support?</h4>
                                <p></p>
                            </div>
                            <div class="acc-content">
                                <div class="text">
                                    <p>Our support team is available to help you with any questions or issues you might
                                        have regarding our services. Please use our contact form or reach out via our
                                        support email (listed on our Contact page) for prompt assistance.p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="link-box centred">
                    <a href="faq.html"><span>Read More</span></a>
                </div>
            </div>
        </section>


        <!-- ebook-section -->
        <!--<section class="ebook-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image-box">
                            <div class="image-shape" style="background-image: url(assets/images/shape/shape-28.png);">
                            </div>
                            <figure class="image"><img src="assets/images/resource/ipad1-1.png" alt=""></figure>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content-box">
                            <div class="sec-title">
                                <span class="sub-title">Ebook</span>
                                <h2>Ebook Series for <br />Forex Trading <span>Beginners</span></h2>
                            </div>
                            <div class="text-box">
                                <p>Minus id quod maxime place at facere possimus, omnis voluptas assu- menda omnis
                                    dolors repellendus tempor.</p>
                            </div>
                            <h6>Ebook Highlights</h6>
                            <ul class="list-item clearfix">
                                <li>
                                    <h4>Ultra fast trade execution <span>01</span></h4>
                                </li>
                                <li>
                                    <h4>Trading from a smartphone or tablet <span>02</span></h4>
                                </li>
                                <li>
                                    <h4>No dealing desk, no requotes <span>03</span></h4>
                                </li>
                            </ul>
                            <div class="btn-box">
                                <button type="button" class="theme-btn"><span>Download</span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>-->
        <!-- ebook-section end -->


        <!-- chooseus-style-two -->
        <!--<section class="chooseus-style-two sec-pad">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-20.png);"></div>
            <figure class="image-layer"><img src="assets/images/resource/chooseus1-1.png" alt=""></figure>
            <div class="auto-container">
                <div class="sec-title centred light">
                    <span class="sub-title">Why Madocks</span>
                    <h2>Reason For <span>Choose Madocks</span></h2>
                </div>
                <div class="inner-box">
                    <div class="left-column">
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-16.png);"></div>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-40.png" alt=""></div>
                            </div>
                            <div class="title-text">
                                <h3>Friendly & Expert<span>01</span></h3>
                            </div>
                            <p>Beatae vitae dicta sun explicabo enim ipsam voluptatem volupta.</p>
                        </div>
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-17.png);"></div>
                            <div class="title-text">
                                <h3>Demo account<span>03</span></h3>
                            </div>
                            <p>Omnis iste natus error sit volup minima accusantium doloremque.</p>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-41.png" alt=""></div>
                            </div>
                        </div>
                    </div>
                    <div class="right-column">
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-18.png);"></div>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-40.png" alt=""></div>
                            </div>
                            <div class="title-text">
                                <h3>24/7 Support<span>02</span></h3>
                            </div>
                            <p>Dolore magnam aliquam quaer autem enim ad minima veniam.</p>
                        </div>
                        <div class="single-item">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-19.png);"></div>
                            <div class="title-text">
                                <h3>Award winner<span>04</span></h3>
                            </div>
                            <p>Beguiled demoralized charms nonsed pleasure of the moment.</p>
                            <div class="icon-box">
                                <div class="icon"><img src="assets/images/icons/icon-41.png" alt=""></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>-->
        <!-- chooseus-style-two end -->


        <!-- platform-style-two -->
        <section class="platform-style-two">
            <div class="auto-container">
                <div class="upper-box">
                    <div class="row clearfix">
                        <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                            <div class="image-box">
                                <div class="image-shape"
                                    style="background-image: url(assets/images/shape/shape-29.png);"></div>
                                <figure class="image"><img src="assets/images/resource/mac1-1.png" alt=""></figure>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                            <div class="content-box">
                                <div class="sec-title">
                                    <span class="sub-title">Platform</span>
                                    <h2>Trade Forex from your <span>Desktop</span></h2>
                                </div>
                                <div class="text-box">
                                    <p>Laborious physical exercise, except to obtain some advantage from it but who has
                                        any right to find fault with a man who chooses to enjoy a pleasure that has no
                                        annoying consequences.</p>
                                </div>
                                <ul class="download-list clearfix">
                                    <li>
                                        <div class="icon-box"><i class="fa-brands fa-apple"></i></div>
                                        <div class="link-box"><a href="https://aimsfx.com/metatrader4/"><span>Download
                                                    App For
                                                    IOS</span></a></div>
                                    </li>
                                    <li>
                                        <div class="icon-box"><i class="fa-brands fa-windows"></i></div>
                                        <div class="link-box"><a href="https://aimsfx.com/metatrader4/"><span>Download
                                                    App For
                                                    Windows</span></a></div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="lower-box">
                    <div class="shape" style="background-image: url(assets/images/shape/shape-30.png);"></div>
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                            <div class="single-item">
                                <div class="static-content">
                                    <h4><img src="assets/images/icons/icon-54.png" alt="">Multiple Order Types
                                        <span>01</span>
                                    </h4>
                                </div>
                                <!--<div class="overlay-content">
                                    <p>Beatae vitae dicta sun explicabo nemo enim ipsam voluptatem volupta.</p>
                                </div>-->
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                            <div class="single-item">
                                <div class="static-content">
                                    <h4><img src="assets/images/icons/icon-54.png" alt="">Multiple Charting
                                        <span>02</span>
                                    </h4>
                                </div>
                                <!--<div class="overlay-content">
                                    <p>Beatae vitae dicta sun explicabo nemo enim ipsam voluptatem volupta.</p>
                                </div>-->
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                            <div class="single-item">
                                <div class="static-content">
                                    <h4><img src="assets/images/icons/icon-54.png" alt="">Newsfeeds <span>03</span></h4>
                                </div>
                                <!--<div class="overlay-content">
                                    <p>Beatae vitae dicta sun explicabo nemo enim ipsam voluptatem volupta.</p>
                                </div>-->
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                            <div class="single-item">
                                <div class="static-content">
                                    <h4><img src="assets/images/icons/icon-54.png" alt="">Technical Indicators
                                        <span>04</span>
                                    </h4>
                                </div>
                                <!--<div class="overlay-content">
                                    <p>Beatae vitae dicta sun explicabo nemo enim ipsam voluptatem volupta.</p>
                                </div>-->
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                            <div class="single-item">
                                <div class="static-content">
                                    <h4><img src="assets/images/icons/icon-54.png" alt="">Stop Loss Facilities
                                        <span>05</span>
                                    </h4>
                                </div>
                                <!--<div class="overlay-content">
                                    <p>Beatae vitae dicta sun explicabo nemo enim ipsam voluptatem volupta.</p>
                                </div>-->
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">
                            <div class="single-item">
                                <div class="static-content">
                                    <h4><img src="assets/images/icons/icon-54.png" alt="">Multilingual Support
                                        <span>06</span>
                                    </h4>
                                </div>
                                <!--<div class="overlay-content">
                                    <p>Beatae vitae dicta sun explicabo nemo enim ipsam voluptatem volupta.</p>
                                </div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- platform-style-two end -->


        <!-- benefits-section -->
        <!--<section class="benefits-section">
            <div class="bg-layer" style="background-image: url(assets/images/background/benefits-bg.jpg);"></div>
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-32.png);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-xl-6 col-lg-12 col-md-12 content-column">
                        <div class="single-item-carousel owl-carousel owl-theme owl-dots-none nav-style-one">
                            <div class="content-box">
                                <div class="shape" style="background-image: url(assets/images/shape/shape-31.png);">
                                </div>
                                <div class="sec-title">
                                    <h2>Open an Account & Get <span>Benefits</span></h2>
                                </div>
                                <h3>Standard Account<span>01</span></h3>
                                <ul class="list-item clearfix">
                                    <li>Maxime placefacere possimus menda omni tempor.</li>
                                    <li>Right to find fault with a man.</li>
                                    <li>Avoids a pain that produces no resultant. </li>
                                </ul>
                                <div class="btn-box">
                                    <a href="register.php" class="theme-btn"><span>Open Your A/c</span></a>
                                </div>
                            </div>
                            <div class="content-box">
                                <div class="shape" style="background-image: url(assets/images/shape/shape-31.png);">
                                </div>
                                <div class="sec-title">
                                    <h2>Open an Account & Get <span>Benefits</span></h2>
                                </div>
                                <h3>Standard Account<span>01</span></h3>
                                <ul class="list-item clearfix">
                                    <li>Maxime placefacere possimus menda omni tempor.</li>
                                    <li>Right to find fault with a man.</li>
                                    <li>Avoids a pain that produces no resultant. </li>
                                </ul>
                                <div class="btn-box">
                                    <a href="register.php" class="theme-btn"><span>Open Your A/c</span></a>
                                </div>
                            </div>
                            <div class="content-box">
                                <div class="shape" style="background-image: url(assets/images/shape/shape-31.png);">
                                </div>
                                <div class="sec-title">
                                    <h2>Open an Account & Get <span>Benefits</span></h2>
                                </div>
                                <h3>Standard Account<span>01</span></h3>
                                <ul class="list-item clearfix">
                                    <li>Maxime placefacere possimus menda omni tempor.</li>
                                    <li>Right to find fault with a man.</li>
                                    <li>Avoids a pain that produces no resultant. </li>
                                </ul>
                                <div class="btn-box">
                                    <a href="register.php" class="theme-btn"><span>Open Your A/c</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>-->
        <!-- benefits-section end -->


        <!-- news-style-three -->
        <!--<section class="news-style-three">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-12 col-sm-12 left-column">
                        <div class="left-content">
                            <div class="sec-title">
                                <span class="sub-title">News & Updates</span>
                                <h2>Read Recent Post From <span>Blog</span></h2>
                                <p>Error sit voluptatem accusantium doloremque quia dolor sit amet, consectetu...</p>
                                <div class="link-box">
                                    <a href="blog-3l.php"><span>More News</span></a>
                                </div>
                            </div>
                            <div class="subscribe-box">
                                <h3>Subscribe Us</h3>
                                <p>Receive news & updates to your inbox.</p>
                                <div class="form-inner">
                                    <form action="contactl.php" method="post">
                                        <div class="form-group">
                                            <div class="icon"><i class="far fa-envelope-open"></i></div>
                                            <input type="email" name="email" placeholder="Email address..." required>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="theme-btn"><span>Subscribe</span></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 right-column">
                        <div class="right-content">
                            <div class="news-block-one">
                                <div class="inner-box">
                                    <div class="image-box">
                                        <figure class="image"><a href="blog-detailsl.php"><img
                                                    src="assets/images/news/news1-8.jpg" alt=""></a></figure>
                                        <span class="post-date">24 Dec</span>
                                    </div>
                                    <div class="lower-content">
                                        <h3><a href="blog-detailsl.php">Best FTSE 250 shares to buy in February 2023</a>
                                        </h3>
                                        <p>Error sit voluptatem accusantium doloremque quia dolor sit amet,
                                            consectetu...</p>
                                        <div class="author-box">
                                            <figure class="author-thumb"><img src="assets/images/news/author-1.jpg"
                                                    alt=""></figure>
                                            <h6>Trade Ideas</h6>
                                            <ul class="post-info clearfix">
                                                <li><span>By</span> <a href="blog-detailsl.php">Justin Langer</a></li>
                                                <li><span class="dots">..</span></li>
                                                <li>2 Mins Read</li>
                                            </ul>
                                        </div>
                                        <div class="link-box">
                                            <a href="blog-detailsl.php"><span>Read More</span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="news-block-one">
                                <div class="inner-box">
                                    <div class="image-box">
                                        <figure class="image"><a href="blog-detailsl.php"><img
                                                    src="assets/images/news/news1-9.jpg" alt=""></a></figure>
                                        <span class="post-date">16 Dec</span>
                                    </div>
                                    <div class="lower-content">
                                        <h3><a href="blog-detailsl.php">Fixed vs floating exchange rates main
                                                differences</a></h3>
                                        <p>Rerum facilis est et expedita distinctio libero magnam aliquam quaerat...</p>
                                        <div class="author-box">
                                            <figure class="author-thumb"><img src="assets/images/news/author-2.jpg"
                                                    alt=""></figure>
                                            <h6>Economic</h6>
                                            <ul class="post-info clearfix">
                                                <li><span>By</span> <a href="blog-detailsl.php">Mylah Sophia</a></li>
                                                <li><span class="dots">..</span></li>
                                                <li>3 Mins Read</li>
                                            </ul>
                                        </div>
                                        <div class="link-box">
                                            <a href="blog-detailsl.php"><span>Read More</span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>--->
        <!-- news-style-three end -->


        <!-- contact-section -->
        <section class="contact-section sec-pad centred">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-33.png);"></div>
            <div class="auto-container">
                <div class="sec-title light">
                    <span class="sub-title">Drop a Line</span>
                    <h2>Send Your <span>Message</span> to us</h2>
                </div>
                <form method="post" action="message.php" id="contact-form">
                    <div class="row clearfix">
                        <div class="col-lg-6 col-md-6 col-sm-12 left-column">
                            <div class="left-content">
                                <div class="form-group">
                                    <input type="text" name="username" placeholder="Your Name" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Email Address" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="phone" placeholder="Phone" required>
                                    <div class="language-picker js-language-picker">
                                        <label for="language-picker-select"></label>
                                        <select id="language-picker-select">
                                            <option lang="de" value="deutsch">de</option>
                                            <option lang="en" value="english" selected>en</option>
                                            <option lang="fr" value="francais">fr</option>
                                            <option lang="it" value="italiano">it</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="subject" placeholder="Subject" required>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 right-column">
                            <div class="right-content">
                                <div class="form-group">
                                    <textarea name="message" placeholder="Write Your Message Here..."></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="check-box">
                        <input class="check" type="checkbox" id="checkbox1">
                        <label for="checkbox1">Agree to our private policies & Conditions.</label>
                    </div>
                    <div class="message-btn">
                        <button type="submit" class="theme-btn" name="submit-form"><span>Send Now</span></button>
                    </div>
                </form>
            </div>
        </section>
        <!-- contact-section end -->


        <!-- footer-style-three -->
        <footer class="footer-style-three">
            <div class="pattern-layer" style="background-image: url(assets/images/shape/shape-34.png);"></div>
            <div class="widget-section">
                <div class="auto-container">
                    <div class="row clearfix">
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget logo-widget">
                                <figure class="footer-logo"><a href="indexl.php"><img src="assets/images/logonew.png"
                                            alt=""></a></figure>
                                <div class="widget-content">
                                    <h3>Have queries?</h3>
                                    <p><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a> <br /> <a
                                            href="https://wa.me/+6593628491" target="_blank"
                                            rel="noopener noreferrer">Contact Here</a></p>
                                    <ul class="social-links clearfix">
                                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                                rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                                        <li><a href="indexl.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                                rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a>
                                        </li>
                                        <li><a href="indexl.php"><i class="fa-brands fa-square-pinterest"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget">
                                <div class="widget-title">
                                    <h3>Company</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="indexl.php">About Us</a></li>
                                        <li><a href="indexl.php">Careers</a></li>
                                        <li><a href="indexl.php">Meet Our Team</a></li>
                                        <li><a href="indexl.php">Process</a></li>
                                        <li><a href="indexl.php">Mission & Vision</a></li>
                                        <li><a href="indexl.php">Faq’s</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget links-widget">
                                <div class="widget-title">
                                    <h3>Useful Links</h3>
                                </div>
                                <div class="widget-content">
                                    <ul class="links-list clearfix">
                                        <li><a href="indexl.php">Trading Tools</a></li>
                                        <li><a href="indexl.php">Pricing List</a></li>
                                        <li><a href="indexl.php">Account Types</a></li>
                                        <li><a href="indexl.php">MT4 Platform</a></li>
                                        <li><a href="indexl.php">Mobile App</a></li>
                                        <li><a href="indexl.php">Policies</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 footer-column">
                            <div class="footer-widget apps-widget">
                                <div class="widget-title">
                                    <h3>Our App</h3>
                                </div>
                                <div class="widget-content">
                                    <p>Download our app & keep track the markets.</p>
                                    <ul class="list-item clearfix">
                                        <li>Smart alert notifications</li>
                                        <li>Instant currency exchange</li>
                                    </ul>
                                    <ul class="download-apps clearfix">
                                        <li><a href="indexl.php"><i class="fa-brands fa-windows"></i></a></li>
                                        <li><a href="indexl.php"><i class="fa-brands fa-apple"></i></a></li>
                                        <li><a href="indexl.php"><i class="fa-brands fa-android"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-three centred">
                <div class="auto-container">
                    <div class="copyright">
                        <p>&copy; 2025 Madocks. All Rights Reserved. <a href="indexl.php">Policies,</a> <a
                                href="indexl.php">Terms & Conditions.</a></p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer-style-three end -->


        <!-- scroll to top -->
        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="flaticon-up-arrow"></i>
        </button>


    </div>
    <script>
        document.getElementById('contact-form').addEventListener('submit', function (e) {
            const checkbox = document.getElementById('checkbox1');
            if (!checkbox.checked) {
                e.preventDefault();
                alert('Please agree to the privacy policy.');
            }
        });
    </script>



    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/language.js"></script>
    <script src="assets/js/jquery-ui.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

</html>