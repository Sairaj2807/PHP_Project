<?php
include 'dbConnect.php';
session_start();
//name 
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];

} else {
    header("Location: index.php");
    exit();
}

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_SESSION['transaction_start']) || time() - $_SESSION['transaction_start'] >= 600) {
    $_SESSION['transaction_start'] = time();
    $_SESSION['new_rates_applied'] = true;
}

if (isset($_GET['reset'])) {
    $_SESSION['transaction_start'] = time();
    echo json_encode(["message" => "Timer reset"]);
    exit;
}

if (isset($_GET['get_time'])) {
    echo json_encode(['transaction_start' => $_SESSION['transaction_start']]);
    exit;
}

if (!isset($_SESSION['user']['id'])) {
    die("Error: User not logged in.");
}

$user_id = $_SESSION['user']['id'];

$query = "SELECT kyc_status, deposit_status, receive_status ,status2 FROM transactions WHERE user_id = :user_id AND transaction_type = 'sell' ORDER BY transaction_time DESC LIMIT 1";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

$kyc_status = $transaction['kyc_status'] ?? 'pending';
$deposit_status = $transaction['deposit_status'] ?? 'pending';
$receive_status = $transaction['receive_status'] ?? 'pending';
$step2_status = $transaction['status2'] ?? 'pending';

function getStatusColor($status)
{
    return match ($status) {
        'completed' => 'green',
        'failed' => 'red',
        default => 'orange',
    };
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';
use Twilio\Rest\Client;

function sendNotification($email, $phone, $statusType, $status, $transaction)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com';
        $mail->Password = 'uexurwwgwuotfcge';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = "Transaction Update Order #{$transaction['id']} - $statusType Changed to $status";
        $mail->Body = "<p>Dear User,</p>
            <p>Your transaction status has been updated:</p>
            <ul>
                <li><strong>Update Type:</strong> $statusType</li>
                <li><strong>Status:</strong> <span style='color:" . ($status == 'completed' ? 'green' : 'red') . ";'>$status</span></li>
                <li><strong>Currency Sent:</strong> {$transaction['currency_send']}</li>
                <li><strong>Amount Sent:</strong> {$transaction['amount_send']}</li>
                <li><strong>Currency Received:</strong> {$transaction['currency_receive']}</li>
                <li><strong>Amount Received:</strong> {$transaction['amount_receive']}</li>
            </ul>
            <p>Please log in to your account for more details.</p>
            <p>Best Regards,<br>Madocks</p>";

        $mail->send();

        sendWhatsAppMessage($statusType, $status, $transaction);
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
    }
}

function sendWhatsAppMessage($statusType, $status, $transaction)
{
    $sid = "AC123ed9e921a2f70fa480229231503368";
    $token = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $body = "Transaction Update:\nOrder #{$transaction['id']}\n$statusType Changed to $status\nAmount Sent: {$transaction['amount_send']} {$transaction['currency_send']}\nAmount Received: {$transaction['amount_receive']} {$transaction['currency_receive']}";

    $message = $twilio->messages->create("whatsapp:+917588345894", [
        "from" => "whatsapp:+14155238886",
        "body" => $body
    ]);
}

$query = "SELECT u.email, u.phone, t.* FROM users u JOIN transactions t ON u.id = t.user_id WHERE t.user_id = :user_id AND t.transaction_type = 'sell' ORDER BY t.transaction_time DESC LIMIT 1";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$transaction = $stmt->fetch(PDO::FETCH_ASSOC);


function sendWhatsAppMessagetoapa_kyc()
{
    $sid = "AC123ed9e921a2f70fa480229231503368";
    $token = "5e8163958ae2e29d3757b261f62b072b";
    $twilio = new Client($sid, $token);

    $body = "User has submited Kyc please check mail ";

    $message = $twilio->messages->create("whatsapp:+917588345894", [
        "from" => "whatsapp:+14155238886",
        "body" => $body
    ]);
}

$query = "SELECT u.email, u.phone, t.* FROM users u JOIN transactions t ON u.id = t.user_id WHERE t.user_id = :user_id AND t.transaction_type = 'sell' ORDER BY t.transaction_time DESC LIMIT 1";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

/*if ($transaction) {
    $user_email = $transaction['email'];
    $user_phone = $transaction['phone'];
    $sentNotifications = [];

    if (($kyc_status == 'completed' || $kyc_status == 'failed') && !isset($sentNotifications['KYC'])) {
        sendNotification($user_email, $user_phone, 'KYC Status', ucfirst($kyc_status), $transaction);
        $sentNotifications['KYC'] = true;
    }
    if (($step2_status == 'completed' || $step2_status == 'failed') && !isset($sentNotifications['Step2'])) {
        sendNotification($user_email, $user_phone, 'Step2 Status', ucfirst($step2_status), $transaction);
        $sentNotifications['Step2'] = true;
    }
    if (($deposit_status == 'completed' || $deposit_status == 'failed') && !isset($sentNotifications['Deposit'])) {
        sendNotification($user_email, $user_phone, 'Deposit Status', ucfirst($deposit_status), $transaction);
        $sentNotifications['Deposit'] = true;
    }
    if (($receive_status == 'completed' || $receive_status == 'failed') && !isset($sentNotifications['Receive'])) {
        sendNotification($user_email, $user_phone, 'Receive Status', ucfirst($receive_status), $transaction);
        $sentNotifications['Receive'] = true;
    }
}*/

//






?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MADOCKS.AI</title>

    <link rel="icon" href="assets/images/favicon-3.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;0,1000;1,300;1,400;1,500;1,600;1,700;1,800;1,900;1,1000&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/owl.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/jquery-ui.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/responsive.css" rel="stylesheet">
    <style>
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            z-index: 1000;
            /* Ensure it's above everything else */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            /* Dark overlay */
            overflow-y: auto;
            /* Allow scrolling within the modal */
        }

        /* Prevent background from scrolling when modal is open */
        body.modal-open {
            overflow: hidden;
        }


        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }

        .close-btn {
            cursor: pointer;
            font-size: 24px;
        }

        .modal-body {
            padding: 20px 0;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            font-weight: bold;
        }

        input,
        select textarea {

            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;

        }






        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .clicked {
            background-color: #28a745 !important;
            /* Green color to indicate success */
            transform: scale(0.95);
        }

        .reference-code {
            font-weight: bold;
            margin-bottom: 10px;
        }

        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .circle {
            width: 200px;
            height: 200px;
            background: white;
            border-radius: 50%;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            text-transform: uppercase;
            position: relative;
        }

        .circle span {
            color: #007bff;
        }

        .options {
            color: black;
            display: flex;
            flex-direction: column;
            gap: 30px;
            margin-left: 80px;
        }

        .option {
            color: black;
            display: flex;
            align-items: center;
            background: white;
            padding: 15px;
            border-radius: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            justify-content: space-between;
            position: relative;
        }

        .icon {
            width: 40px;
            height: 40px;
            background: #f0f8ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
        }

        .text {
            text-align: left;
            flex: 1;
        }

        .text h3 {
            margin: 0;
            font-size: 16px;
            color: #007bff;
        }

        .text p {
            margin: 5px 0 0;
            font-size: 14px;
            color: #555;
        }

        .btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .modaldeposit {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modaldeposit-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modaldeposit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            font-size: 20px;
            cursor: pointer;
            color: red;
        }

        input[type="file"],
        input[type="text"] {
            display: block;
            margin: 10px 0;
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }


        .modal2 {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal2-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            text-align: left;
        }

        .modal2-content {
            background: white;
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            border-radius: 10px;
            text-align: left;
        }

        .modal2-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
    </style>
    <style>
        @media (max-width: 768px) {

            .modal-content,
            .modaldeposit-content,
            .modal2-content {
                width: 90%;
                margin: 20% auto;
                padding: 15px;
            }

            .container {
                flex-direction: column;
                align-items: center;
                padding: 20px;
            }

            .circle {
                width: 150px;
                height: 150px;
                font-size: 16px;
                margin-bottom: 20px;
            }

            .options {
                margin-left: 0;
                gap: 20px;
                width: 100%;
            }

            .option {
                flex-direction: column;
                align-items: flex-start;
                width: 100%;
            }

            .icon {
                margin-bottom: 10px;
                font-size: 16px;
            }

            .text {
                width: 100%;
            }

            .btn {
                align-self: flex-end;
            }

            input,
            select,
            textarea {
                font-size: 16px;
            }

            label {
                font-size: 14px;
            }

            button {
                font-size: 16px;
            }
        }
    </style>
    <style>
        .checkbox {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox input[type="checkbox"] {
            margin-right: 10px;
            margin-left: 0;
            width: 16px;
            height: 16px;
        }

        .checkbox label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }

        .checkbox label p {
            margin: 0;
        }
    </style>

    <style>
        .tooltip-icon {
            display: inline-block;
            margin-left: 8px;
            background-color: #4a90e2;
            color: white;
            font-size: 12px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            text-align: center;
            line-height: 20px;
            position: relative;
            cursor: pointer;
        }

        .tooltip-text {
            visibility: hidden;
            width: 250px;
            background-color: #333;
            color: #fff;
            text-align: left;
            padding: 10px;
            border-radius: 6px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            /* Position above icon */
            left: 50%;
            margin-left: -125px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 13px;
        }

        .tooltip-icon:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }
    </style>

</head>

<body>
    <div class="boxed_wrapper home_3">


        <!-- preloader -->
        <!--<div class="loader-wrap">
    <div class="preloader">
        <div class="preloader-close">x</div>
        <div id="handle-preloader" class="handle-preloader">
            <div class="animation-preloader">
                <div class="spinner"></div>
                <div class="txt-loading">
                    <span data-text-preloader="M" class="letters-loading">
                        M
                    </span>
                    <span data-text-preloader="A" class="letters-loading">
                        A
                    </span>
                    <span data-text-preloader="D" class="letters-loading">
                        D
                    </span>
                    <span data-text-preloader="O" class="letters-loading">
                        O
                    </span>
                    <span data-text-preloader="C" class="letters-loading">
                        C
                    </span>
                    <span data-text-preloader="K" class="letters-loading">
                        K
                    </span>
                    <span data-text-preloader="S" class="letters-loading">
                        S
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>-->
        <!-- preloader end -->


        <!--Search Popup-->
        <!--<div id="search-popup" class="search-popup">
<div class="popup-inner">
<div class="upper-box clearfix">
    <figure class="logo-box pull-left"><a href="new_index.php"><img src="assets/images/logonew.png"
                alt=""></a></figure>
    <div class="close-search pull-right"><i class="fa-solid fa-xmark"></i></div>
</div>
<div class="overlay-layer"></div>
<div class="auto-container">
    <div class="search-form">
        <form method="post" action="new_index.php">
            <div class="form-group">
                <fieldset>
                    <input type="search" class="form-control" name="search-input" value=""
                        placeholder="Type your keyword and hit" required>
                    <button type="submit"><i class="flaticon-loupe"></i></button>
                </fieldset>
            </div>
        </form>
    </div>
</div>
</div>
</div>--->


        <!-- main header -->
        <header class="main-header header-style-three">
            <!-- header-top -->
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><img src="assets/images/icons/icon-47.png" alt=""></div>
                            <p><a href="tel:+6593628491">+6593628491</a>
                                <!---or Request for a <a href="tel:+6593628491"><span>call back</span></a>-->
                            </p>
                        </div>
                        <div class="right-column">
                            <div class="language-box">
                                <div class="icon-box"><img src="assets/images/icons/icon-48.png" alt=""></div>
                                <div class="select-box">
                                    <select class="wide">
                                        <option data-display="English">English</option>
                                        <option value="1">Chinese</option>
                                        <option value="2">Indonesian</option>
                                        <!---<option value="3">Spanish</option>
                        <option value="4">Turky</option>--->
                                    </select>
                                </div>
                            </div>
                            <div class="language-box">
                                <div class="select-box">
                                    <select class="wide" id="language-select" onchange="redirectToPage()">
                                        <option value="new_index.php" selected>
                                            <?php echo '<span>Hi ' . $user['name'] . '</span>'; ?>
                                        </option>
                                        <option value="logout.php">Logout</option>
                                    </select>
                                </div>
                                <script>
                                    function redirectToPage() {
                                        const selectedValue = document.getElementById('language-select').value;
                                        if (selectedValue) {
                                            window.location.href = selectedValue; // Redirect to the selected page
                                        }
                                    }
                                </script>
                            </div>

                            <!---<ul class="registration-box clearfix">
                <li>
                    <div class="icon"><img src="assets/images/icons/icon-49.png" alt=""></div>
                    <a href="logout.php">Logout</a>
                </li>
                <li>
                    <div class="icon"><img src="assets/images/icons/icon-50.png" alt=""></div>
                    <a href="register.php">Signup</a>
                </li>
            </ul>--->
                            <ul class="social-links clearfix">
                                <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="new_index.php"><i class="fa-brands fa-square-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                        rel="noopener noreferrer"><i class="fa-brands fa-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                        alt=""></a>
                            </figure>
                        </div>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="dropdown"><a href="new_index.php">Home</a>
                                            <!---<ul>
                                <li><a href="new_index.php">Home One</a></li>
                                <li><a href="new_index.php">Home Two</a></li>
                                <li><a href="new_index.php">Home Three</a></li>
                            </ul> --->
                                        </li>
                                        <li class="dropdown"><a href="marketsl.php">Markets</a>
                                            <!---<ul>
                                <li><a href="marketsl.php">Markets</a></li>
                                <li><a href="market-details.html">Details Page</a></li>
                            </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="platform.php">Referral Code</a>
                                            <!---<ul>
                                <li><a href="platform.php">Platform</a></li>
                                <li><a href="account.html">Our Accounts</a></li>
                                <li><a href="account-details.html">Standard Account</a></li>
                                <li><a href="account-details-2.html">Commision Account</a></li>
                                <li><a href="account-details-3.html">STP Pro Account</a></li>
                            </ul>--->
                                        </li>
                                        <!---<li class="dropdown"><a href="new_index.php">Education</a>
                            <ul>
                                <li><a href="education.html">Education</a></li>
                                <li><a href="education-details.html">Detail Page</a></li>
                            </ul>
                        </li> --->
                                        <li class="dropdown"><a href="contactl.php">Contact</a>
                                            <!----<ul>
                                <li><a href="about.html">Company</a></li>
                                <li><a href="history.html">History</a></li>
                                <li><a href="team.html">Team</a></li>
                                <li class="dropdown"><a href="new_index.php">Blog</a>
                                    <ul>
                                        <li><a href="blog.html">3 Columns</a></li>
                                        <li><a href="blog-2.html">3 Columns Sidebar</a></li>
                                        <li><a href="blog-3.html">List View 01</a></li>
                                        <li><a href="blog-4.html">List View 02</a></li>
                                        <li><a href="blog-details.html">Single Post</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact</a></li>
                                <li><a href="faq.html">Faq’s</a></li>
                                <li><a href="error.html">404</a></li>
                            </ul>--->
                                        </li>
                                        <li class="dropdown"><a href="calculator.html">Calculator</a> </li>
                                        <li class="current dropdown"><a href="usdt_main_page_change8.php">USDT</a>

                                        </li>
                                    </ul>
                                </div>
                            </nav>
                            <div class="menu-right-content">

                                <div class="search-box-outer search-toggler">
                                    <!--<i class="flaticon-search"></i></div>-->
                                    <!---<div class="btn-box"><a href="" class="theme-btn btn-one">
                        
                    </a></div>--->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--sticky Header-->
                <div class="sticky-header">
                    <div class="auto-container">
                        <div class="outer-box">
                            <div class="logo-box">
                                <figure class="logo"><a href="new_index.php"><img src="assets/images/logonew.png"
                                            alt=""></a>
                                </figure>
                            </div>
                            <div class="menu-area">
                                <nav class="main-menu clearfix">
                                    <!--Keep This Empty / Menu will come through Javascript-->
                                </nav>
                                <div class="menu-right-content">
                                    <div class="search-box-outer search-toggler">
                                        <!--<i class="flaticon-search"></i></div>-->
                                        <!---<div class="btn-box"><a href="register.php" class="theme-btn btn-one">



                        



                    </a></div>--->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>

            <nav class="menu-box">
                <style>
                    .user-greeting span {
                        color: white;
                        font-weight: bold;
                        font-size: 26px;
                        display: block;
                        text-align: center;
                        margin-top: 10px;
                        margin-bottom: 90px;
                    }
                </style>





                <div class="nav-logo"><a href="new_index.php"><img src="assets/images/logo6.png" alt="" title=""></a>
                </div>



                <div class="user-greeting">
                    <?php echo '<li><a href="new_index.php"><span>Hi ' . $user['name'] . '</span></a></li>'; ?>
                </div>




                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>46 EAST COAST ROAD #10-01 EASTGATE SINGAPORE (428766)</li>
                        <li><a href="tel:+6593628491">+65 9362 8491</a></li>
                        <li><a href="mailto:Harveyong.wv@gmail.com">Harveyong.wv@gmail.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="new_index.php"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/share/14bnLRbDnD/" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="https://www.instagram.com/madocks.trading" target="_blank"
                                rel="noopener noreferrer"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="new_index.php"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <!-- existing section -->
        <section class="banner-style-three centred">
            <div class="container">
                <div class="circle">
                    USDT/FIAT <br> <span>conversion steps</span>
                </div>

                <div class="options">
                    <!--<div id="statusTimer">Time left: 10:00</div>
                    <p>
                        <strong>Rate:</strong>
                        <span id="exchangeRate"></span>
                    </p>-->
                    <!---<div class="option">
                        <div class="icon">👤</div>
                        <div class="text">
                            <h3>Step1: KYC submission</h3>
                            <p>Status: <span id="kyc-status" style="color: <?php //echo getStatusColor($kyc_status); ?>;">
                                    <?php //echo ucfirst($kyc_status); ?></span></p>
                        </div>
                        <button class="btn" onclick="openModal()">Select</button>
                    </div>

                    <div class="option">
                        <div class="icon">🎫</div>
                        <div class="text">
                            <h3>Step2: Liquidity agreement
                            </h3>
                            <p>Status: <span id="step2-status"
                                    style="color: <?php //echo getStatusColor($step2_status); ?>;">
                                    <?php //echo ucfirst($step2_status); ?>
                                </span></p>

                        </div>
                        <button class="btn" onclick="openModal2()">Select</button>
                    </div>--->



                    <div class="option">
                        <div class="icon">⚖️</div>
                        <div class="text">
                            <h3>Deposit Money </h3>
                            <p>Status: <span id="deposit-status" style="color: orange;">Pending</span></p>
                        </div>
                        <button class="btn" onclick="openDepositModal()">Select</button>
                    </div>

                    <!--<div class="option">
                        <div class="icon">📊</div>
                        <div class="text">
                            <h3>Step4: Money received</h3>
                            <p>Status:  <span id="receive-status" style="color: orange;">Pending</span></p>
                        </div>
                    </div>--->
                </div>
            </div>



            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    generateReferenceCode();
                });

                function generateReferenceCode() {
                    let refCode = "XYZ" + Math.floor(10000 + Math.random() * 90000);
                    document.getElementById("referenceCodeDisplay").innerText = "Reference Code: " + refCode;
                    document.getElementById("referenceCode").value = refCode; // Ensure value is set correctly
                    console.log("Generated Reference Code:", refCode); // Debugging output
                }

                // Ensure reference code is included before form submission
                document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
                    let refCodeInput = document.getElementById("referenceCode").value;
                    console.log("Reference Code on Submit:", refCodeInput); // Debugging output

                    if (!refCodeInput) {
                        alert("Reference Code is missing. Please reload the page.");
                        event.preventDefault();
                    }
                });
            </script>

            <div id="usdtModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2>USDT Onboarding</h2>
                        <span class="close-btn" onclick="closeModal()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <h3>INDIVIDUAL APPLICATION</h3>
                        <h4>INDIVIDUAL DETAILS</h4>

                        <form id="usdtOnboardingForm">
                            <div class="reference-code"><strong id="referenceCodeDisplay"></strong></div>
                            <input type="hidden" id="referenceCode" name="referenceCode">

                            <label for="apaEmployee">Name of the APA employee spoken to *</label>
                            <input type="text" id="apaEmployee" name="apaEmployee" required>

                            <label for="fullName">Full Name as per Passport/ID *</label>
                            <input type="text" id="fullName" name="fullName" required>

                            <label for="dob">Date of Birth *</label>
                            <input type="text" id="dob" name="dob" placeholder="DDMMYYYY" required>

                            <label for="nationality">Nationality *</label>
                            <select id="nationality" name="nationality" required>
                                <option value="">Select Country</option>
                                <option value="US">United States</option>
                                <option value="IN">India</option>
                                <option value="UK">United Kingdom</option>
                            </select>

                            <label for="address1">Address Line 1 *</label>
                            <input type="text" id="address1" name="address1" required>

                            <label for="address2">Address Line 2</label>
                            <input type="text" id="address2" name="address2">

                            <label for="address3">Address Line 3</label>
                            <input type="text" id="address3" name="address3">

                            <label for="postcode">Postcode *</label>
                            <input type="text" id="postcode" name="postcode" required>

                            <label for="mobile">Mobile Number *</label>
                            <input type="text" id="mobile" name="mobile" required>

                            <label for="passportId">Passport/ID Number *</label>
                            <input type="text" id="passportId" name="passportId" required>

                            <label for="country">Country *</label>
                            <select id="country" name="country" required>
                                <option value="">Select Country</option>
                                <option value="US">United States</option>
                                <option value="IN">India</option>
                                <option value="UK">United Kingdom</option>
                            </select>

                            <label for="occupation">Occupation *</label>
                            <input type="text" id="occupation" name="occupation" required>

                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" required>

                            <label for="currencies">Currencies Required *</label>
                            <input type="text" id="currencies" name="currencies" required>

                            <label for="sourceWealth">Source of Wealth *</label>
                            <input type="file" id="sourceWealth" name="sourceWealth" required>

                            <label for="proofIdentity">Proof of Identity *</label>
                            <input type="file" id="proofIdentity" name="proofIdentity" required>

                            <label for="proofAddress">Proof of Address (issued within 3 months) *</label>
                            <input type="file" id="proofAddress" name="proofAddress" required>

                            <label for="sourceFunds">Source of Funds *</label>
                            <input type="file" id="sourceFunds" name="sourceFunds" required>

                            <label for="annualVolume">Estimated Annual Transaction Volume (USD) *</label>
                            <input type="text" id="annualVolume" name="annualVolume" required>

                            <label for="accountReason">Reason for Account Opening *</label>
                            <textarea id="accountReason" name="accountReason" required></textarea>

                            <button type="submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>


            <div id="Modal2" class="modal2">
                <div class="modal2-content">
                    <div class="modal2-header">
                        <h2>LA</h2>
                        <span class="close-btn" onclick="closeModal2()">×</span>

                    </div>
                    <h2> Please download the agreement and signed it and upload </h2>
                    <br> <br>

                    <form id="modal2Form" enctype="multipart/form-data" method="post">
                        <label>Download Agreement:</label>
                        <a href="/path/to/agreement.pdf" download>Click here to download</a>
                        <br><br>

                        <label>Upload Signed Agreement:</label>
                        <input type="file" name="agreement" required>
                        <br><br>

                        <input type="checkbox" id="terms" name="terms" required>
                        <label for="terms">
                            <p>By submitting, you agree to our Terms and Conditions.</p>
                        </label>


                        <button type="submit">Submit</button>
                    </form>
                </div>
            </div>

            <div id="depositModal" class="modaldeposit">
                <div class="modaldeposit-content">
                    <div class="modaldeposit-header">
                        <h2>Deposit Money</h2>
                        <span class="close-btn" onclick="closeDepositModal()">×</span>
                    </div>



                    <h2>Current Transactions</h2>
                    <div id="transactionData">Loading transactions...</div>

                    <h3>Please deposit the monney at the following bank address:</h3>
                    <p><strong>Bank Address:</strong> 987654321</p>

                    <form id="depositForm" enctype="multipart/form-data">
                        <label>Upload Receipt:</label>
                        <input type="file" name="receipt" required>

                        <label>Enter Bank/USDT Address:</label>
                        <input type="text" name="bank_address" required>

                        <div class="checkbox">
                            <input type="checkbox" id="terms" name="terms" required>
                            <label for="terms">
                                <p>By submitting, you agree to our Terms and Conditions <!--<a href="terms.html" target="_blank"
                                        class="terms-link">Terms and Conditions</a>-->.</p><span class="tooltip-icon">?
                                    <span class="tooltip-text">
                                        By continuing, I acknowledge and agree that:
                                        <br>
                                        • I am voluntarily seeking information about USDT and FX cross-border payment
                                        services and was not solicited in any way.
                                        <br>
                                        • Madocks Pte Ltd acts solely as a referrer to third-party licensed entities and
                                        does not hold, process, or transmit any funds.
                                        <br>
                                        • All transactions are conducted directly with the referred provider, and
                                        Madocks Pte Ltd bears no liability for any outcomes, delays, pricing, or risks
                                        involved.
                                        <br>
                                        • I am solely responsible for my own due diligence and for ensuring that such transactions are legal in my jurisdiction.

                                    </span>
                                </span>
                            </label>
                        </div>

                        <button type="submit" class="btn">Submit</button>

                    </form>



                </div>
            </div>
        </section>
    </div>

    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/language.js"></script>
    <script src="assets/js/jquery-ui.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

    <script>
        document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
            event.preventDefault();

            let formData = new FormData(this);

            fetch("submit_usdt.php", {
                method: "POST",
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                })
                .catch(error => console.error("Error:", error));
        });
        document.getElementById("usdtOnboardingForm").addEventListener("submit", function (event) {
            event.preventDefault();

            // Prevent default submission (if using AJAX)

            // Simulating successful submission (replace with actual AJAX call if needed)
            setTimeout(() => {
                alert("Form submitted successfully!");
                closeModal(); // Close modal after submission
            }, 500); // Simulating slight delay

            setTimeout(() => {
                let statusElement = document.getElementById("kyc-status");
                statusElement.innerText = "Processing";
                statusElement.style.color = "orange";
            }, 500);
        });
    </script>

    <script>
        function openModal() {
            document.getElementById("usdtModal").style.display = "block";
        }

        function closeModal() {
            document.getElementById("usdtModal").style.display = "none";
        }

        function openModal2() {
            document.getElementById("Modal2").style.display = "block";
        }

        function closeModal2() {
            document.getElementById("Modal2").style.display = "none";
        }

        function openDepositModal() {
            document.getElementById("depositModal").style.display = "block";
            fetch('transaction1.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('transactionData').innerHTML = data;
                });
        }

        function closeDepositModal() {
            document.getElementById("depositModal").style.display = "none";
        }
        // uploads 
        document.getElementById("depositForm").addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent the form from submitting normally

            const formData = new FormData(this);

            fetch("save_deposit5.php", {
                method: "POST",
                body: formData,
            })
                .then(response => response.text())
                .then(data => {
                    //alert("Transaction updated successfully!");
                    //closeDepositModal();
                    if (data.trim() === "success") {
                        alert("Transaction updated successfully!");
                        closeDepositModal(); // Close the modal on success
                    } else {
                        alert(data); // Show the error message
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred while submitting the form.");
                });


        });

        document.getElementById("depositForm").addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent default submission (if using AJAX)

            // Simulating successful submission (replace with actual AJAX call if needed)
            setTimeout(() => {
                //alert("Form submitted successfully!");
                closeDepositModal();// Close modal after submission
            }, 500); // Simulating slight delay

            setTimeout(() => {
                let statusElement = document.getElementById("deposit-status");
                statusElement.innerText = "Processing";
                statusElement.style.color = "orange";
            }, 500);
        });

    </script>

    <script>
        document.getElementById("modal2Form").addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent page reload

            let formData = new FormData(this); // Capture form data including file

            fetch("agreement_sell.php", {
                method: "POST",
                body: formData
            })
                .then(response => response.json()) // Expect JSON response

                .catch(error => console.error("Error:", error));

            setTimeout(() => {
                alert("Form submitted successfully!");
                closeModal2(); // Close modal after submission
            }, 500);

            setTimeout(() => {
                let statusElement = document.getElementById("step2-status");
                statusElement.innerText = "Processing";
                statusElement.style.color = "orange";
            }, 500);
        });

    </script>

    <!--<script>
        function startTimer(duration, display) {
            let timer = duration, minutes, seconds;
            let interval = setInterval(function () {
                minutes = Math.floor(timer / 60);
                seconds = timer % 60;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                display.textContent = "Time left: " + minutes + ":" + seconds;

                if (--timer < 0) {
                    clearInterval(interval);
                    display.textContent = "Here are your updated rates for the transaction";
                    document.getElementById("rateMessage").textContent = "New rates have been applied!";

                    // Reset transaction start time on the server and restart timer
                    fetch("status1.php?reset=true")
                        .then(response => response.json())
                        .then(() => {
                            setTimeout(() => {
                                location.reload(); // Restart countdown after showing message
                            }, 5000); // Show the message for 5 seconds before restarting
                        });
                }
            }, 1000);
        }

        window.onload = function () {
            let transactionStart = <?php //echo $_SESSION['transaction_start']; ?>;
            let timeElapsed = Math.floor(Date.now() / 1000) - transactionStart;
            let remainingTime = Math.max(600 - timeElapsed, 0); // 10 minutes = 600 seconds

            let display = document.getElementById("statusTimer");
            startTimer(remainingTime, display);
        };
    </script>-->

    <script>
        function fetchExchangeRate() {
            fetch('exchangerate.php')
                .then(response => response.json())
                .then(data => {
                    if (data.exchangeRate) {
                        //document.getElementById("sellCurrency").innerText = "100 INR";
                        document.getElementById("exchangeRate").innerText = `1 USDT = ${data.exchangeRateEUR} EUR`;
                    }
                })
                .catch(error => console.error("Error fetching exchange rate:", error));
        }

        // Fetch immediately on page load
        fetchExchangeRate();

        // Fetch every 2 minutes (120000 milliseconds)
        setInterval(fetchExchangeRate, 120000);
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            function getStatusColor(status) {
                switch (status) {
                    case 'completed': return 'green';
                    case 'failed': return 'red';
                    case 'processing': return 'orange';
                    default: return 'orange'; // Pending
                }
            }

            function updateTransactionStatus() {
                fetch("know_status.php")
                    .then(response => response.json())
                    .then(data => {
                        if (data.status !== "unauthorized") {
                            // Update deposit status
                            let depositStatus = document.getElementById("deposit-status");
                            depositStatus.textContent = data.deposit_status.charAt(0).toUpperCase() + data.deposit_status.slice(1);
                            depositStatus.style.color = getStatusColor(data.deposit_status);

                            // Update money received status
                            let receiveStatus = document.getElementById("receive-status");
                            receiveStatus.textContent = data.receive_status.charAt(0).toUpperCase() + data.receive_status.slice(1);
                            receiveStatus.style.color = getStatusColor(data.receive_status);
                        }
                    })
                    .catch(error => console.error("Error fetching transaction status:", error));
            }

            // Fetch status every 5 seconds
            setInterval(updateTransactionStatus, 5000);
            updateTransactionStatus(); // Fetch immediately on page load
        });
    </script>

</body>

</html>