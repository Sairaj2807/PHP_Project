<?
require_once('tcpdf/tcpdf.php');

$pdf = new TCPDF();
$pdf->AddPage();
$pdf->Write(0, 'Hello World from TCPDF!');
$pdf->Output('hello_world.pdf', 'I');  // 'I' = Inline browser output


