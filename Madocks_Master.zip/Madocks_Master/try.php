<?php
/*session_start();
include 'dbConnect.php'; // Ensure this file correctly initializes $pdo

if (!isset($_SESSION['user'])) {
    die("User not logged in.");
}

$user_id = $_SESSION['user']['id'];

if (!isset($pdo)) {
    die("Database connection error.");
}

// Debugging: Check if POST data is being received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['transaction_type'], $_POST['currency_send'], $_POST['amount_send'], $_POST['currency_receive'], $_POST['amount_receive'])) {
        echo "Missing required fields.";
        print_r($_POST); // Debug: Print received POST data
        exit;
    }

    $transaction_type = $_POST['transaction_type'];
    $currency_send = $_POST['currency_send'];
    $amount_send = $_POST['amount_send'];
    $currency_receive = $_POST['currency_receive'];
    $amount_receive = $_POST['amount_receive'];

    try {
        // Corrected SQL query to match table structure
        $sql = "INSERT INTO transactions (user_id, transaction_type, amount_send, currency_send, amount_receive, currency_receive, transaction_time) 
                VALUES (:user_id, :transaction_type, :amount_send, :currency_send, :amount_receive, :currency_receive, NOW())";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':transaction_type', $transaction_type, PDO::PARAM_STR);
        $stmt->bindParam(':amount_send', $amount_send, PDO::PARAM_STR);
        $stmt->bindParam(':currency_send', $currency_send, PDO::PARAM_STR);
        $stmt->bindParam(':amount_receive', $amount_receive, PDO::PARAM_STR);
        $stmt->bindParam(':currency_receive', $currency_receive, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "Transaction stored successfully!";
        } else {
            echo "Error storing transaction.";
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
}*/


session_start();
include 'dbConnect.php'; // Ensure this file correctly initializes $pdo

if (!isset($_SESSION['user'])) {
    die("User not logged in.");
}

$user_id = $_SESSION['user']['id'];

if (!isset($pdo)) {
    die("Database connection error.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['transaction_type'], $_POST['currency_send'], $_POST['amount_send'], $_POST['currency_receive'], $_POST['amount_receive'])) {
        exit("Missing required fields.");
    }

    $transaction_type = $_POST['transaction_type'];
    $currency_send = $_POST['currency_send'];
    $amount_send = $_POST['amount_send'];
    $currency_receive = $_POST['currency_receive'];
    $amount_receive = $_POST['amount_receive'];

    try {
        $sql = "INSERT INTO transactions (user_id, transaction_type, amount_send, currency_send, amount_receive, currency_receive, transaction_time) 
                VALUES (:user_id, :transaction_type, :amount_send, :currency_send, :amount_receive, :currency_receive, NOW())";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':transaction_type', $transaction_type, PDO::PARAM_STR);
        $stmt->bindParam(':amount_send', $amount_send, PDO::PARAM_STR);
        $stmt->bindParam(':currency_send', $currency_send, PDO::PARAM_STR);
        $stmt->bindParam(':amount_receive', $amount_receive, PDO::PARAM_STR);
        $stmt->bindParam(':currency_receive', $currency_receive, PDO::PARAM_STR);

        $stmt->execute();
    } catch (PDOException $e) {
        exit("Database error: " . $e->getMessage());
    }
}
?>









<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy & Sell USDT</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f2f2;
            text-align: center;
            margin: 0;
            padding: 40px;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
        }

        .text-section {
            flex: 1;
            max-width: 500px;
            text-align: left;
            padding: 20px;
        }

        .text-section h1 {
            font-size: 30px;
            font-weight: bold;
        }

        .text-section p {
            font-size: 16px;
            color: #444;
            line-height: 1.6;
        }

        .card {
            flex: 1;
            max-width: 400px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: left;
            position: relative;
        }

        .button-group {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        .button-group button {
            background-color: #ccc;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 16px;
            margin-left: 5px;
            border-radius: 5px;
        }

        .button-group button.active {
            background-color: #007bff;
            color: white;
        }

        .exchange-box {
            display: flex;
            flex-direction: column;
            margin-top: 40px;
        }

        .exchange-box label {
            font-weight: bold;
            margin-top: 10px;
        }

        .exchange-box select,
        .exchange-box input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            box-sizing: border-box;
        }

        .buy-button {
            width: 100%;
            background: #007bff;
            color: white;
            font-size: 18px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
        }

        .buy-button:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="text-section">
            <h1>Convert Fiat Into Crypto: Buy USDT with Various Currencies Online</h1>
            <p>USDT is one of the most popular stablecoins, widely used for trading and investments.</p>
        </div>

        <div class="card">
            <div class="button-group">
                <button id="buyBtn" class="active" onclick="toggleMode('buy')">Buy</button>
                <button id="sellBtn" onclick="toggleMode('sell')">Sell</button>
            </div>

            <form method="POST">
                <input type="hidden" id="transaction_type" name="transaction_type" value="buy">

                <div id="exchangeBox" class="exchange-box">
                    <label>You send</label>
                    <select name="currency_send">
                        <!-- <option>EUR</option>
                        <option>AED</option>
                        <option>ARS</option>
                        <option>INR</option>-->
                        <option>EUR (Euro)</option>
                        <option>AED (United Arab Emirates Dirham)</option>
                        <option>ARS (Argentine Peso)</option>
                        <option>AUD (Australian Dollar)</option>
                        <option>INR (Indian Rupee)</option>
                        <option>JPY (Japanese Yen)</option>
                        <option>GBP (Pound Sterling)</option>
                        <option>SGD (Singapore Dollar)</option>
                        <option>VND (Vietnamese Dong)</option>
                        <option>ZAR (South African Rand)</option>
                    </select>
                    <input type="number" name="amount_send" id="amountSend" value="100">

                    <label>You get</label>
                    <select name="currency_receive">
                        <option>USDT</option>
                    </select>
                    <input type="number" name="amount_receive" id="amountReceive" value="0.00096624" readonly>
                </div>

                <button type="submit" class="buy-button" id="actionButton" onclick="redirectToPage()">Buy</button>
            </form>
        </div>
    </div>

    <script>
        function toggleMode(mode) {
            let buyBtn = document.getElementById('buyBtn');
            let sellBtn = document.getElementById('sellBtn');
            let actionButton = document.getElementById('actionButton');
            let transactionType = document.getElementById('transaction_type');

            if (mode === 'sell') {
                sellBtn.classList.add('active');
                buyBtn.classList.remove('active');
                actionButton.innerText = "Sell";
                transactionType.value = "sell";
                exchangeBox.innerHTML = `
                       <label>You send</label>
                    <select name="currency_send">
                    <option>USDT</option>
                    </select>
                    <input type="number" name="amount_send" id="amountSend" value="100">
                    <label>You get</label>
                    <select name="currency_receive">

                    <option>AED</option>
                        <option>ARS</option>
                        <option>INR</option>  
                        <option>EUR (Euro)</option>
                        <option>AED (United Arab Emirates Dirham)</option>
                        <option>ARS (Argentine Peso)</option>
                        <option>AUD (Australian Dollar)</option>
                        <option>INR (Indian Rupee)</option>
                        <option>JPY (Japanese Yen)</option>
                        <option>GBP (Pound Sterling)</option>
                        <option>SGD (Singapore Dollar)</option>
                        <option>VND (Vietnamese Dong)</option>
                        <option>ZAR (South African Rand)</option>
                    </select>
                    <input type="number" name="amount_receive" id="amountReceive" value="0.00096624" readonly>
                    
                `;

            } else {
                buyBtn.classList.add('active');
                sellBtn.classList.remove('active');
                actionButton.innerText = "Buy";
                transactionType.value = "buy";
                currentMode = 'buy';
                exchangeBox.innerHTML = `
                            <label>You send</label>
                    <select name="currency_send">
                       <!-- <option>EUR</option>
                        <option>AED</option>
                        <option>ARS</option>
                        <option>INR</option>-->
                        <option>EUR (Euro)</option>
                        <option>AED (United Arab Emirates Dirham)</option>
                        <option>ARS (Argentine Peso)</option>
                        <option>AUD (Australian Dollar)</option>
                        <option>INR (Indian Rupee)</option>
                        <option>JPY (Japanese Yen)</option>
                        <option>GBP (Pound Sterling)</option>
                        <option>SGD (Singapore Dollar)</option>
                        <option>VND (Vietnamese Dong)</option>
                        <option>ZAR (South African Rand)</option>
                    </select>
                    <input type="number" name="amount_send" id="amountSend" value="100">

                    <label>You get</label>
                    <select name="currency_receive">
                        <option>USDT</option>
                    </select>
                    <input type="number" name="amount_receive" id="amountReceive" value="0.00096624" readonly>
                    
                `;
            }
        }




        document.getElementById('actionButton').addEventListener('click', function (event) {
            event.preventDefault();  // Prevent form submission

            let userId = <?php echo $_SESSION['user']['id'] ?? 'null'; ?>;
            if (userId === null) {
                alert("User not logged in!");
                return;
            }

            let transactionType = document.getElementById('transaction_type').value;
            let currencySend = document.querySelector('select[name="currency_send"]').value;
            let amountSend = document.getElementById('amountSend').value;
            let currencyReceive = document.querySelector('select[name="currency_receive"]').value;
            let amountReceive = document.getElementById('amountReceive').value;

            if (!transactionType || !currencySend || !amountSend || !currencyReceive || !amountReceive) {
                alert("Please fill in all fields.");
                return;
            }

            let data = new FormData();
            data.append("transaction_type", transactionType);
            data.append("currency_send", currencySend);
            data.append("amount_send", amountSend);
            data.append("currency_receive", currencyReceive);
            data.append("amount_receive", amountReceive);

            fetch('try.php', {
                method: 'POST',
                body: data
            })
                .then(response => response.text())
                .then(result => {
                    //console.log("Server Response:", result);
                    //alert(result);
                })
                .catch(error => console.error('Error:', error));
        });

        function redirectToPage() {
            if (currentMode === 'buy') {
                window.location.href = "buy_steps.html";
            } else {
                window.location.href = "sell.html";
            }
        }
        


    </script>

</body>

</html>