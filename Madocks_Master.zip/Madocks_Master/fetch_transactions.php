<?php /*

session_start();
include 'dbConnect.php'; // Ensure this file correctly initializes $pdo
require 'vendor/autoload.php'; // If installed via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['user'])) {
    die("User not logged in.");
}

$user_id = $_SESSION['user']['id'];

if (!isset($pdo)) {
    die("Database connection error.");
}

try {
    // Fetch user email
    $stmtUser = $pdo->prepare("SELECT email FROM users WHERE id = :user_id");
    $stmtUser->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmtUser->execute();
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("User email not found.");
    }
    $user_email = $user['email'];

    // Fetch transactions
    $stmt = $pdo->prepare("SELECT id, currency_send, amount_send, currency_receive, amount_receive, status FROM transactions WHERE user_id = :user_id AND transaction_type = 'buy'");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($transactions)) {
        echo "<p>No buy transactions found.</p>";
    } else {
        echo "<table border='1' width='100%'>
                <tr>
                    <th>Currency Sent</th>
                    <th>Amount Sent</th>
                    <th>Currency Received</th>
                    <th>Amount Received</th>
                    <th>Status</th>
                </tr>";
        foreach ($transactions as $transaction) {
            $statusColor = ($transaction['status'] === 'completed') ? 'green' :
                           (($transaction['status'] === 'failed') ? 'red' : 'orange');

            echo "<tr>
                    <td>{$transaction['currency_send']}</td>
                    <td>{$transaction['amount_send']}</td>
                    <td>{$transaction['currency_receive']}</td>
                    <td>{$transaction['amount_receive']}</td>
                    <td style='color: $statusColor; font-weight: bold;'>{$transaction['status']}</td>
                  </tr>";

            // Send email only if transaction is completed
            if ($transaction['status'] === 'completed'  ) {
                sendTransactionEmail($user_email, $transaction);
            }
        }
        echo "</table>";
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}

// Function to send email using PHPMailer
 
function sendTransactionEmail($email, $transaction) {
    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // SMTP server (Gmail)
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com'; // Your SMTP email
        $mail->Password = 'uexurwwgwuotfcge'; // Your SMTP password or App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS encryption
        $mail->Port = 587; // SMTP port for TLS

        // Sender & Recipient
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email); // Send to user

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = "Transaction Successful - Order #{$transaction['id']}";
        $mail->Body = "
            <p>Dear User,</p>
            <p>Your transaction has been successfully completed.</p>
            <p><strong>Transaction Details:</strong></p>
            <ul>
                <li><strong>Currency Sent:</strong> {$transaction['currency_send']}</li>
                <li><strong>Amount Sent:</strong> {$transaction['amount_send']}</li>
                <li><strong>Currency Received:</strong> {$transaction['currency_receive']}</li>
                <li><strong>Amount Received:</strong> {$transaction['amount_receive']}</li>
            </ul>
            <p>Thank you for using our service.</p>
            <p>Best Regards,<br>Madocks</p>
        ";

        // Send email
        $mail->send();
        //echo "Transaction email sent successfully.";
    } catch (Exception $e) {
        echo "Email sending failed: {$mail->ErrorInfo}";
    }
}*/
  

session_start();
include 'dbConnect.php'; // Ensure this file correctly initializes $pdo
require 'vendor/autoload.php'; // If installed via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['user'])) {
    die("User not logged in.");
}

$user_id = $_SESSION['user']['id'];

if (!isset($pdo)) {
    die("Database connection error.");
}

try {
    // Fetch user email
    $stmtUser = $pdo->prepare("SELECT email FROM users WHERE id = :user_id");
    $stmtUser->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmtUser->execute();
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("User email not found.");
    }
    $user_email = $user['email'];

    // Fetch the latest transaction only
    $stmt = $pdo->prepare("SELECT id, currency_send, amount_send, currency_receive, amount_receive, status 
                           FROM transactions 
                           WHERE user_id = :user_id AND transaction_type = 'buy' 
                           ORDER BY id DESC LIMIT 1");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        echo "<p>No buy transactions found.</p>";
    } else {
        echo "<table border='1' width='100%'>
                <tr>
                    <th>Currency Sent</th>
                    <th>Amount Sent</th>
                    <th>Currency Received</th>
                    <th>Amount Received</th>
                    <th>Status</th>
                </tr>";

        $statusColor = ($transaction['status'] === 'completed') ? 'green' :
                       (($transaction['status'] === 'failed') ? 'red' : 'orange');

        echo "<tr>
                <td>{$transaction['currency_send']}</td>
                <td>{$transaction['amount_send']}</td>
                <td>{$transaction['currency_receive']}</td>
                <td>{$transaction['amount_receive']}</td>
                <td style='color: $statusColor; font-weight: bold;'>{$transaction['status']}</td>
              </tr>";

        echo "</table>";

        // Send email only if the latest transaction is completed
        if ($transaction['status'] === 'completed') {
            sendTransactionEmail($user_email, $transaction);
        }
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}

/**
 * Function to send email using PHPMailer
 */
function sendTransactionEmail($email, $transaction) {
    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // SMTP server (Gmail)
        $mail->SMTPAuth = true;
        $mail->Username = 'madocks.ai@gmail.com'; // Your SMTP email
        $mail->Password = 'uexurwwgwuotfcge'; // Your SMTP password or App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS encryption
        $mail->Port = 587; // SMTP port for TLS

        // Sender & Recipient
        $mail->setFrom('madocks.ai@gmail.com', 'Madocks');
        $mail->addAddress($email); // Send to user

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = "Transaction Successful - Order #{$transaction['id']}";
        $mail->Body = "
            <p>Dear User,</p>
            <p>Your transaction has been successfully completed.</p>
            <p><strong>Transaction Details:</strong></p>
            <ul>
                <li><strong>Currency Sent:</strong> {$transaction['currency_send']}</li>
                <li><strong>Amount Sent:</strong> {$transaction['amount_send']}</li>
                <li><strong>Currency Received:</strong> {$transaction['currency_receive']}</li>
                <li><strong>Amount Received:</strong> {$transaction['amount_receive']}</li>
            </ul>
            <p>Thank you for using our service.</p>
            <p>Best Regards,<br>Madocks</p>
        ";

        // Send email
        $mail->send();
        //echo "Transaction email sent successfully.";
    } catch (Exception $e) {
        echo "Email sending failed: {$mail->ErrorInfo}";
    }
}





?>



