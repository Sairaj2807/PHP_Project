<?php
require_once __DIR__ . '/vendor/autoload.php';

use Twilio\Rest\Client;
use Twilio\Exceptions\RestException;

sendWhatsAppMessagetoapa_kyc();

function sendWhatsAppMessagetoapa_kyc()
{
    $sid = "AC9190bc9fbd44a7714951db78b5e902f8";
    $token = "fef74e8a8617e37530a3891c47800e30";
    $twilio = new Client($sid, $token);

    $body = "User has submitted a New Liquidity Agreement";

    try {
        $message = $twilio->messages->create("whatsapp:+639398014213", [
            "from" => "whatsapp:+14155238886", // Replace with the correct sandbox number
            "body" => $body
        ]);

        echo "Message sent successfully!";
    } catch (RestException $e) {
        echo "Error: " . $e->getMessage();
    }
}
